-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2023 at 06:00 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `isrp2`
--

-- --------------------------------------------------------

--
-- Table structure for table `actor`
--

CREATE TABLE `actor` (
  `ID` int(11) NOT NULL,
  `name` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '-',
  `skin` int(11) NOT NULL DEFAULT 0,
  `anim` int(11) NOT NULL DEFAULT 0,
  `posx` float NOT NULL DEFAULT 0,
  `posy` float NOT NULL DEFAULT 0,
  `posz` float NOT NULL DEFAULT 0,
  `posr` float NOT NULL DEFAULT 0,
  `interior` int(11) NOT NULL DEFAULT 0,
  `world` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `actor`
--

INSERT INTO `actor` (`ID`, `name`, `skin`, `anim`, `posx`, `posy`, `posz`, `posr`, `interior`, `world`) VALUES
(0, '/prosesborax', 291, 0, -347.93, -1045.66, 59.8125, 168.924, 0, 1),
(1, '/jualborax', 115, 0, 1514.2, 22.0824, 24.1406, 281.221, 0, 1),
(2, '/prosesborax', 114, 0, -348.062, -1045.66, 59.8125, 170.153, 0, 1),
(3, '/jualborax', 114, 0, 1515.68, 22.3396, 24.1406, 278.536, 0, 1),
(4, '/prosesborax', 115, 0, -347.838, -1045.66, 59.8125, 182.229, 0, 1),
(5, 'Pak Dokter', 275, 17, 1172.83, -1322.13, 15.3987, 272.583, 0, 1),
(6, 'Pak Mamat', 27, 19, 318.913, 873.511, 20.4062, 230.591, 0, 1),
(7, 'Mamat', 167, 17, 920.371, -1287.55, 14.2803, 176.519, 0, 1),
(8, 'Jordi', 261, 19, 1692.76, -1515.21, 13.5469, 259.92, 0, 1),
(9, 'Mamad', 27, 19, 318.861, 873.392, 20.4062, 228.525, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `atms`
--

CREATE TABLE `atms` (
  `id` int(11) NOT NULL,
  `posx` float NOT NULL,
  `posy` float NOT NULL,
  `posz` float NOT NULL,
  `posrx` float NOT NULL,
  `posry` float NOT NULL,
  `posrz` float NOT NULL,
  `interior` int(11) NOT NULL DEFAULT 0,
  `world` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `atms`
--

INSERT INTO `atms` (`id`, `posx`, `posy`, `posz`, `posrx`, `posry`, `posrz`, `interior`, `world`) VALUES
(0, 2248.51, -1759.95, 1014.38, 0, 0, -176.5, 1, 0),
(1, 1491.64, -1011.53, 26.5137, 0, 0, -86.7, 0, 0),
(2, 1432.35, -1012, 26.4837, 0, 0, 88.7, 0, 0),
(3, 1172.09, -1319.17, 14.9891, 0, 0, 89, 0, 0),
(5, 1758.83, -1750.74, 13.235, 0, 0, 0, 0, 0),
(6, 391.069, -1805.93, 7.53812, 0, 0, 180, 0, 0),
(7, -83.2758, -1183.58, 1.42701, 0, 0, -20.3, 0, 0),
(4, 1833.23, -1850.19, 13.1897, 0, 0, -90.8, 0, 0),
(13, -1980.64, 134.372, 27.3275, 0, 0, -90.8, 0, 0),
(14, 1382.74, 262.982, 19.5669, 0, 0, 0, 0, 0),
(16, 1498.52, -1749.88, 15.0725, 0, 0, 179.9, 0, 0),
(12, -2160.13, -2458.91, 30.2628, 0, 0, -38.6, 0, 0),
(8, 1553.84, -1663.48, 13.2122, 0, 0, -90.1, 0, 0),
(11, 269.915, -202.243, 1.22812, 0, 0, 0, 0, 0),
(9, 1235.75, 209.285, 19.1947, 0, 0, -22.1, 0, 0),
(20, 690.882, -576.502, 15.9659, 0, 0, -89.0999, 0, 0),
(10, 565.791, -1293.96, 16.8582, 0, 0, -178.2, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `banneds`
--

CREATE TABLE `banneds` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(24) DEFAULT 'None',
  `ip` varchar(24) DEFAULT 'None',
  `longip` int(11) DEFAULT 0,
  `ban_expire` bigint(20) DEFAULT 0,
  `ban_date` bigint(20) DEFAULT 0,
  `last_activity_timestamp` bigint(20) DEFAULT 0,
  `admin` varchar(40) DEFAULT 'Server',
  `reason` varchar(128) DEFAULT 'None'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bisnis`
--

CREATE TABLE `bisnis` (
  `ID` int(11) NOT NULL,
  `owner` varchar(40) NOT NULL DEFAULT '-',
  `ownerid` int(11) NOT NULL,
  `name` varchar(40) NOT NULL DEFAULT 'Bisnis',
  `price` int(11) NOT NULL DEFAULT 500000,
  `type` int(11) NOT NULL DEFAULT 1,
  `locked` int(11) NOT NULL DEFAULT 1,
  `money` int(11) NOT NULL DEFAULT 0,
  `prod` int(11) NOT NULL DEFAULT 50,
  `bprice0` int(11) NOT NULL DEFAULT 500,
  `bprice1` int(11) NOT NULL DEFAULT 500,
  `bprice2` int(11) NOT NULL DEFAULT 500,
  `bprice3` int(11) NOT NULL DEFAULT 500,
  `bprice4` int(11) NOT NULL DEFAULT 500,
  `bprice5` int(11) NOT NULL DEFAULT 500,
  `bprice6` int(11) NOT NULL DEFAULT 500,
  `bprice7` int(11) NOT NULL DEFAULT 500,
  `bprice8` int(11) NOT NULL DEFAULT 500,
  `bprice9` int(11) NOT NULL DEFAULT 500,
  `bint` int(11) NOT NULL DEFAULT 0,
  `extposx` float NOT NULL DEFAULT 0,
  `extposy` float NOT NULL DEFAULT 0,
  `extposz` float NOT NULL DEFAULT 0,
  `extposa` float NOT NULL DEFAULT 0,
  `intposx` float NOT NULL DEFAULT 0,
  `intposy` float NOT NULL DEFAULT 0,
  `intposz` float NOT NULL DEFAULT 0,
  `intposa` float NOT NULL DEFAULT 0,
  `pointx` float DEFAULT 0,
  `pointy` float DEFAULT 0,
  `pointz` float DEFAULT 0,
  `visit` bigint(20) NOT NULL DEFAULT 0,
  `restock` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `bisnis`
--

INSERT INTO `bisnis` (`ID`, `owner`, `ownerid`, `name`, `price`, `type`, `locked`, `money`, `prod`, `bprice0`, `bprice1`, `bprice2`, `bprice3`, `bprice4`, `bprice5`, `bprice6`, `bprice7`, `bprice8`, `bprice9`, `bint`, `extposx`, `extposy`, `extposz`, `extposa`, `intposx`, `intposy`, `intposz`, `intposa`, `pointx`, `pointy`, `pointz`, `visit`, `restock`) VALUES
(1, 'Rihito', 8, 'Toko Peratalan Kerja', 1000, 2, 0, 1496, 100, 100, 210, 300, 200, 520, 520, 1000, 100, 0, 0, 6, -224.245, -2263.55, 29.3, 296.321, -26.68, -57.92, 1003.54, 357.58, -23.3037, -55.5642, 1003.55, 1652812593, 1),
(0, 'Lovic_Hug', 5, 'Ganton', 100000, 3, 0, 2291, 65, 100, 10, 100, 100, 0, 0, 0, 0, 0, 0, 15, 2244.34, -1665.55, 15.4766, 159.472, 207.55, -110.67, 1005.13, 0.159999, 207.575, -100.327, 1005.26, 1652816550, 0),
(2, 'Clairo_Stevano', 2, 'Idlewood', 30000, 5, 0, 2717, 4815, 15, 20, 10, 15, 30, 15, 0, 0, 0, 0, 1, 1833.78, -1842.43, 13.5781, 262.611, 1421.95, -1180.97, 26, 176.57, 1422.28, -1185.31, 26.0029, 1653424797, 0),
(3, 'Jhono_Yoo', 3, 'El Corona', 2000000, 4, 0, 7225, 86, 500, 500, 500, 500, 500, 500, 1000, 500, 500, 500, 6, 1848.33, -1871.75, 13.5781, 276.548, 316.34, -169.6, 999.6, 357.73, 312.789, -166.141, 999.594, 0, 0),
(4, 'Clairo_Stevano', 2, 'Rodeo', 30000, 5, 0, 104, 993, 15, 20, 15, 10, 30, 15, 0, 0, 0, 0, 2, 478.096, -1534.4, 19.6701, 111.084, 1421.95, -1180.97, 26, 176.57, 1422.24, -1185.31, 26.0029, 1653424312, 0),
(5, 'Clairo_Stevano', 2, 'Palomino Creek', 30000, 5, 0, 81, 996, 20, 25, 15, 10, 35, 15, 0, 0, 0, 0, 2, 2277.79, 51.175, 26.4844, 352.385, 1421.95, -1180.97, 26, 176.57, 1422.39, -1185.31, 26.0029, 1653628082, 0),
(6, 'Yamaguchi_Valdis', 13, 'Mulholland', 25000, 2, 0, 17425, 9, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 6, 1000.59, -919.93, 42.3281, 307.33, -26.68, -57.92, 1003.54, 357.58, -30.0186, -55.653, 1003.55, 1679270330, 0),
(7, 'Clairo_Stevano', 2, 'CLAIRO CELL', 40000, 5, 0, 116, 994, 25, 30, 20, 10, 35, 15, 0, 0, 0, 0, 2, 1784.49, -1295.26, 13.4371, 170.266, 1421.95, -1180.97, 26, 176.57, 1422.54, -1185.31, 26.0029, 1653812681, 0),
(8, '-', 0, 'Temple', 25000, 1, 1, 0, 10, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 10, 1199.26, -918.142, 43.1313, 21.656, 363.22, -74.86, 1001.5, 319.72, 376.39, -67.4352, 1001.51, 0, 0),
(9, 'Razzel', 15, 'Market', 25000, 4, 1, 10000, 0, 10, 10, 10, 10, 10, 10, 10, 10, 0, 0, 6, 1368.88, -1279.69, 13.5469, 272.486, 316.34, -169.6, 999.6, 357.73, 0, 0, 0, 1679235570, 0);

-- --------------------------------------------------------

--
-- Table structure for table `booster`
--

CREATE TABLE `booster` (
  `booster` tinyint(3) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `callvoice`
--

CREATE TABLE `callvoice` (
  `posx` float NOT NULL DEFAULT 0,
  `posy` float NOT NULL DEFAULT 0,
  `posz` float NOT NULL DEFAULT 0,
  `posa` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `ID` int(11) DEFAULT 0,
  `contactID` int(11) NOT NULL,
  `contactName` varchar(32) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `contactNumber` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`ID`, `contactID`, `contactName`, `contactNumber`) VALUES
(14, 1, 'Dario', 3093),
(43, 2, '9539', 9539);

-- --------------------------------------------------------

--
-- Table structure for table `dealership`
--

CREATE TABLE `dealership` (
  `ID` int(11) NOT NULL,
  `owner` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '-',
  `name` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'Dealership',
  `price` int(11) NOT NULL DEFAULT 1,
  `type` int(11) NOT NULL DEFAULT 1,
  `locked` int(11) NOT NULL DEFAULT 1,
  `money` int(11) NOT NULL DEFAULT 0,
  `stock` int(11) NOT NULL DEFAULT 100,
  `posx` float NOT NULL DEFAULT 0,
  `posy` float NOT NULL DEFAULT 0,
  `posz` float NOT NULL DEFAULT 0,
  `posa` float NOT NULL DEFAULT 0,
  `pointx` float DEFAULT 0,
  `pointy` float DEFAULT 0,
  `pointz` float DEFAULT 0,
  `restock` tinyint(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doors`
--

CREATE TABLE `doors` (
  `ID` int(11) NOT NULL,
  `name` varchar(50) DEFAULT 'None',
  `password` varchar(50) DEFAULT '',
  `icon` int(11) DEFAULT 19130,
  `mapicon` tinyint(4) NOT NULL DEFAULT 0,
  `locked` int(11) NOT NULL DEFAULT 0,
  `admin` int(11) NOT NULL DEFAULT 0,
  `vip` int(11) NOT NULL DEFAULT 0,
  `faction` int(11) NOT NULL DEFAULT 0,
  `family` int(11) NOT NULL DEFAULT -1,
  `garage` tinyint(4) NOT NULL DEFAULT 0,
  `custom` int(11) NOT NULL DEFAULT 0,
  `extvw` int(11) DEFAULT 0,
  `extint` int(11) DEFAULT 0,
  `extposx` float DEFAULT 0,
  `extposy` float DEFAULT 0,
  `extposz` float DEFAULT 0,
  `extposa` float DEFAULT 0,
  `intvw` int(11) DEFAULT 0,
  `intint` int(11) NOT NULL DEFAULT 0,
  `intposx` float DEFAULT 0,
  `intposy` float DEFAULT 0,
  `intposz` float DEFAULT 0,
  `intposa` float DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `doors`
--

INSERT INTO `doors` (`ID`, `name`, `password`, `icon`, `mapicon`, `locked`, `admin`, `vip`, `faction`, `family`, `garage`, `custom`, `extvw`, `extint`, `extposx`, `extposy`, `extposz`, `extposa`, `intvw`, `intint`, `intposx`, `intposy`, `intposz`, `intposa`) VALUES
(0, 'San Andreas Police Departement', '', 19130, 30, 0, 0, 0, 0, -1, 0, 1, 0, 0, 1555.3, -1675.69, 16.1953, 87.1144, 5, 5, 101.813, 1073.54, -48.9141, 173.595),
(1, '[ Heli Pad ]', '', 19130, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1565.02, -1666.76, 28.3956, 3.67237, 5, 5, 115.213, 1064.65, -48.9141, 242.519),
(2, '[ Basement ]', '', 19130, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 1568.62, -1689.98, 6.21875, 3.82408, 5, 5, 86.2733, 1063.16, -48.9141, 354.993),
(3, 'City Hall', '', 19130, 12, 0, 0, 0, 0, -1, 0, 1, 0, 0, 1481.09, -1772.31, 18.7958, 179.409, 0, 5, -2063.23, 2659.37, 1498.78, 358.826),
(4, 'San Andreas Goverment Service', '', 19130, 0, 0, 0, 0, 2, -1, 0, 1, 0, 0, 1485.14, -1824.97, 13.5469, 183.735, 0, 5, -2064.97, 2709.98, 1500.98, 186.444),
(5, 'San Andreas Medical Departement', '', 19130, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 2034.35, -1401.86, 17.2965, 182.651, 0, 1, -2035.83, -58.028, 1060.99, 273.832),
(6, 'San Andreas Medical Departement', '', 19130, 0, 0, 0, 0, 0, -1, 0, 0, 0, 1, -2007.88, -73.2096, 1060.99, 6.41084, 0, 0, 0, 0, 0, 0),
(7, 'San Andreas Medical Departement', '', 19130, 0, 0, 0, 0, 0, -1, 0, 0, 0, 1, -2013.29, -73.1903, 1060.99, 2.65063, 0, 0, 0, 0, 0, 0),
(8, 'ASGH Medical Departement', '', 19130, 22, 0, 0, 0, 0, -1, 0, 1, 0, 0, 1172.08, -1325.34, 15.4074, 93.035, 5, 5, -1772.38, -2019.09, 1500.79, 1.91612),
(9, 'ASGH Medical Departement', '', 19130, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 1144.88, -1324.18, 13.5853, 78.0049, 5, 5, -1762.8, -1995.84, 1500.79, 187.654),
(10, 'ASGH Medical Departement', '', 19130, 0, 0, 0, 0, 3, -1, 0, 1, 0, 0, 1163.41, -1329.97, 31.4847, 12.2057, 5, 5, -1768.33, -1992.17, 1500.79, 101.174),
(11, 'San Andreas News Agency', '', 19130, 19, 0, 0, 0, 0, -1, 0, 1, 0, 0, 649.092, -1360.59, 14.0034, 96.0664, 5, 5, -192.46, 1345.33, 1500.98, 172.375),
(12, 'San Andreas News Agency Studio', '', 19130, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 740.15, -1351.26, 14.7142, 265.1, 5, 5, -204.038, 1314.5, 1500.98, 358.955),
(13, 'Bank Los Santos', '', 19130, 52, 0, 0, 0, 0, -1, 0, 1, 0, 0, 1461.24, -1020.52, 24.3051, 350.906, 5, 5, -2693.79, 796.65, 1500.97, 268.851),
(14, 'Taxi Longue', '', 19130, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 1752.63, -1894.08, 13.5574, 276.873, 0, 1, -2158.5, 642.905, 1052.38, 184.752),
(15, 'VIP Longue', '', 19130, 0, 0, 0, 1, 0, -1, 0, 1, 0, 0, 1797.65, -1578.89, 14.0861, 280.855, 0, 1, -4107.23, 906.906, 3.10072, 176.818),
(16, 'SANEWS', '', 19130, 0, 0, 0, 0, 4, -1, 0, 0, 0, 1, 2473.41, 2278.42, 91.6868, 178.715, 5, 5, -212.877, 1310.36, 1507.66, 272.933),
(17, 'SANews Base', '', 19130, 0, 0, 0, 0, 0, -1, 0, 0, 5, 5, -212.263, 1326.9, 1500.99, 274.5, 0, 1, 2467.58, 2253.87, 91.6868, 89.1242),
(19, 'Alhambra', '', 19130, 48, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1837.03, -1682.21, 13.323, 87.4758, 0, 3, -2636.87, 1402.56, 906.461, 12.1067),
(20, 'VIP Car Garage', '', 19130, 0, 0, 0, 1, 0, -1, 1, 1, 0, 0, 1827.26, -1538.06, 13.5469, 165.884, 0, 0, 1818.76, -1537.02, 13.3813, 84.7065),
(21, 'VIP Bike Garage', '', 19130, 0, 0, 0, 1, 0, -1, 1, 1, 0, 0, 1754.34, -1594.77, 13.537, 79.0899, 0, 0, 1753.36, -1587.71, 13.3052, 357.622),
(22, 'Pengadilan San Andreas', '', 19130, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 1411.69, -1699.7, 13.5395, 56.7037, 0, 1, 1356.01, 717.951, -15.7573, 260.304),
(23, 'Willowfield Gym', '', 19130, 54, 0, 0, 0, 0, -1, 0, 0, 0, 0, 2493.03, -1958.55, 13.5827, 3.07504, 0, 6, 774.372, -50.2732, 1000.59, 2.59314),
(24, 'SAN TOWER', '', 19130, 0, 0, 1, 0, 0, -1, 0, 1, 0, 0, 1415.48, -1300.22, 13.5449, 0.765661, 0, 0, 1548.83, -1363.87, 326.218, 12.036),
(25, 'Newbie School [ OOZ ZONE ]', '', 19130, 36, 1, 0, 0, 0, -1, 0, 0, 0, 0, 1286.6, -1329.32, 13.554, 262.649, 0, 1, 2177.65, -1010.05, 1021.69, 178.971),
(26, 'Production (Perbaikan)', '', 19130, 0, 1, 0, 0, 0, -1, 0, 0, 0, 0, 694.907, -500.133, 16.3359, 178.709, 0, 1, 770.935, -1108, -43.26, 179.937),
(27, 'San Fierro Police Department', '', 19130, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, -1605.76, 710.886, 13.8672, 179.148, 1, 10, 246.593, 107.298, 1003.22, 2.36836),
(28, 'San Fierro Police Department ( Garage )', '', 19130, 0, 0, 0, 0, 1, -1, 0, 0, 0, 0, -1606.13, 672.063, -4.90625, 167.803, 1, 10, 227.231, 117.499, 999.029, 265.716),
(29, 'Police Departement [ Dillimore ]', '', 19130, 30, 0, 0, 0, 0, -1, 0, 0, 0, 0, 626.965, -571.794, 17.9207, 89.5109, 29, 29, -1464.99, 2609.88, 19.631, 178.087),
(30, 'Rooftop', '', 19130, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 621.289, -568.999, 26.1432, 179.897, 29, 29, -1479.84, 2605.28, 19.781, 187.487),
(31, 'Parkiran', '', 19130, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 611.09, -583.501, 18.2109, 181.44, 29, 29, -1475.76, 2593.04, 15.9518, 184.353),
(35, 'Department of Motor Vehicles', '', 19130, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 2062.83, -1897.38, 13.5538, 187.697, 5, 5, -2572.28, -1376.14, 1500.76, 83.6231),
(36, 'Las Venturas Schematic Factory', '', 19130, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1590.81, 688.192, 10.8203, 89.1129, 0, 0, 1062.31, 2077.53, 10.8203, 357.764),
(37, 'Palomino Bank', '', 19130, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 2303.82, -16.1489, 26.4844, 271.276, 0, 1, -1156.25, -1018.12, 3001.09, 93.0091),
(38, 'Insurance Center', '', 19130, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1333.02, -1266.15, 13.5469, 90.4743, 0, 0, 1285.88, -1270.08, 13.5939, 8.86195),
(39, 'Lantai 2', '', 19130, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1287.24, -1262.04, 13.5939, 358.209, 0, 0, 1287.43, -1261.74, 20.6199, 182.932),
(32, 'BlackMarket', '', 19130, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, -939.483, 1425.28, 30.434, 83.737, 666, 6, 296.907, -112.07, 1001.52, 345.349),
(18, 'Balai Desa', '', 19130, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 2246.42, -61.8975, 27.242, 90.138, 0, 1, -1164.19, -190.287, 721.199, 267.13);

-- --------------------------------------------------------

--
-- Table structure for table `familys`
--

CREATE TABLE `familys` (
  `ID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT 'None',
  `leader` varchar(50) NOT NULL DEFAULT 'None',
  `motd` varchar(100) NOT NULL DEFAULT 'None',
  `color` int(11) DEFAULT 0,
  `extposx` float DEFAULT 0,
  `extposy` float DEFAULT 0,
  `extposz` float DEFAULT 0,
  `extposa` float DEFAULT 0,
  `intposx` float DEFAULT 0,
  `intposy` float DEFAULT 0,
  `intposz` float DEFAULT 0,
  `intposa` float DEFAULT 0,
  `fint` int(11) NOT NULL DEFAULT 0,
  `Weapon1` int(11) NOT NULL DEFAULT 0,
  `Ammo1` int(11) NOT NULL DEFAULT 0,
  `Weapon2` int(11) NOT NULL DEFAULT 0,
  `Ammo2` int(11) NOT NULL DEFAULT 0,
  `Weapon3` int(11) NOT NULL DEFAULT 0,
  `Ammo3` int(11) NOT NULL DEFAULT 0,
  `Weapon4` int(11) NOT NULL DEFAULT 0,
  `Ammo4` int(11) NOT NULL DEFAULT 0,
  `Weapon5` int(11) NOT NULL DEFAULT 0,
  `Ammo5` int(11) NOT NULL DEFAULT 0,
  `Weapon6` int(11) NOT NULL DEFAULT 0,
  `Ammo6` int(11) NOT NULL DEFAULT 0,
  `Weapon7` int(11) NOT NULL DEFAULT 0,
  `Ammo7` int(11) NOT NULL DEFAULT 0,
  `Weapon8` int(11) NOT NULL DEFAULT 0,
  `Ammo8` int(11) NOT NULL DEFAULT 0,
  `Weapon9` int(11) NOT NULL DEFAULT 0,
  `Ammo9` int(11) NOT NULL DEFAULT 0,
  `Weapon10` int(11) NOT NULL DEFAULT 0,
  `Ammo10` int(11) NOT NULL DEFAULT 0,
  `safex` float DEFAULT 0,
  `safey` float DEFAULT 0,
  `safez` float DEFAULT 0,
  `money` int(11) NOT NULL DEFAULT 0,
  `marijuana` int(11) NOT NULL DEFAULT 0,
  `component` int(11) NOT NULL DEFAULT 0,
  `material` int(11) NOT NULL DEFAULT 0,
  `Weapon11` int(11) NOT NULL DEFAULT 0,
  `Ammo11` int(11) NOT NULL DEFAULT 0,
  `Weapon12` int(11) NOT NULL DEFAULT 0,
  `Ammo12` int(11) NOT NULL DEFAULT 0,
  `Weapon13` int(11) NOT NULL DEFAULT 0,
  `Ammo13` int(11) NOT NULL DEFAULT 0,
  `Weapon14` int(11) NOT NULL DEFAULT 0,
  `Ammo14` int(11) NOT NULL DEFAULT 0,
  `Weapon15` int(11) NOT NULL DEFAULT 0,
  `Ammo15` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `familys`
--

INSERT INTO `familys` (`ID`, `name`, `leader`, `motd`, `color`, `extposx`, `extposy`, `extposz`, `extposa`, `intposx`, `intposy`, `intposz`, `intposa`, `fint`, `Weapon1`, `Ammo1`, `Weapon2`, `Ammo2`, `Weapon3`, `Ammo3`, `Weapon4`, `Ammo4`, `Weapon5`, `Ammo5`, `Weapon6`, `Ammo6`, `Weapon7`, `Ammo7`, `Weapon8`, `Ammo8`, `Weapon9`, `Ammo9`, `Weapon10`, `Ammo10`, `safex`, `safey`, `safez`, `money`, `marijuana`, `component`, `material`, `Weapon11`, `Ammo11`, `Weapon12`, `Ammo12`, `Weapon13`, `Ammo13`, `Weapon14`, `Ammo14`, `Weapon15`, `Ammo15`) VALUES
(0, 'CapellaFamilys', 'Clairo_Stevano', 'None', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -760.373, 1637.44, 27.5172, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(0, 'CapellaFamilys', 'Clairo_Stevano', 'None', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -760.373, 1637.44, 27.5172, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `gates`
--

CREATE TABLE `gates` (
  `ID` int(11) NOT NULL,
  `model` int(11) NOT NULL DEFAULT 0,
  `password` varchar(36) NOT NULL DEFAULT '',
  `admin` tinyint(4) NOT NULL DEFAULT 0,
  `vip` tinyint(4) NOT NULL DEFAULT 0,
  `faction` tinyint(4) NOT NULL DEFAULT 0,
  `family` int(11) NOT NULL DEFAULT -1,
  `speed` float NOT NULL DEFAULT 2,
  `cX` float NOT NULL,
  `cY` float NOT NULL,
  `cZ` float NOT NULL,
  `cRX` float NOT NULL,
  `cRY` float NOT NULL,
  `cRZ` float NOT NULL,
  `oX` float NOT NULL,
  `oY` float NOT NULL,
  `oZ` float NOT NULL,
  `oRX` float NOT NULL,
  `oRY` float NOT NULL,
  `oRZ` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `gates`
--

INSERT INTO `gates` (`ID`, `model`, `password`, `admin`, `vip`, `faction`, `family`, `speed`, `cX`, `cY`, `cZ`, `cRX`, `cRY`, `cRZ`, `oX`, `oY`, `oZ`, `oRX`, `oRY`, `oRZ`) VALUES
(0, 980, '', 0, 0, 1, -1, 2, 1539.41, -1627.56, 15.0128, 0, 0, 90.2, 1539.41, -1627.56, 9.51278, 0, 0, 90.2),
(1, 986, '', 0, 0, 4, -1, 2, 777.918, -1385.11, 13.6232, 0, 0, 0, 769.928, -1385.11, 13.6232, 0, 0, 0),
(2, 986, '', 0, 0, 3, -1, 2, 1147.43, -1290.87, 13.6388, 0, 0, 1.1, 1153.97, -1290.74, 13.6388, 0, 0, 1.1),
(3, 968, '', 0, 0, 0, -1, 2, 907.214, -1681.77, 13.5469, 0, 89.3, 88.3, 907.214, -1681.77, 13.5469, 0, -0.200005, 88.3),
(4, 968, '', 0, 0, 0, -1, 2, -1701.43, 687.603, 24.7006, -2.4, -90.6, 90, -1701.43, 687.603, 24.7006, 0, 0, 91.6),
(5, 968, '', 0, 0, 0, -1, 2, 907.235, -1654.92, 13.5469, 0, -90.5, 92.8, 907.235, -1654.92, 13.5469, 0, 0, 92.8),
(7, 986, '', 0, 0, 1, -1, 2, 1588.66, -1637.79, 13.3828, 0, 0, 179.7, 1596.41, -1637.83, 13.3828, 0, 0, 179.7),
(6, 19859, '', 0, 0, 1, -1, 2, 1539.68, -1620.17, 13.6946, 0, 0, 87.6, 1539.74, -1621.51, 13.6946, 0, 0, 87.6),
(8, 1498, '', 0, 0, 0, -1, 2, 1556.47, -1684.54, 6.21875, 0, 0, 0, 1556.47, -1684.54, 6.21875, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `gstations`
--

CREATE TABLE `gstations` (
  `id` int(11) NOT NULL DEFAULT 0,
  `stock` int(11) NOT NULL DEFAULT 10000,
  `posx` float DEFAULT 0,
  `posy` float DEFAULT 0,
  `posz` float DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `gstations`
--

INSERT INTO `gstations` (`id`, `stock`, `posx`, `posy`, `posz`) VALUES
(0, 44490, 1944.41, -1772.95, 13.3906),
(2, 49940, -92.051, -1170.65, 2.40334),
(3, 12930, 1004.45, -939.424, 42.1797),
(4, 65800, 652.534, -564.914, 16.3359),
(5, 99940, -2406.81, 975.719, 45.2969),
(6, 9840, -2243.63, -2560.31, 31.9219),
(1, 8270, -1605.74, -2714.33, 48.5335);

-- --------------------------------------------------------

--
-- Table structure for table `houses`
--

CREATE TABLE `houses` (
  `ID` int(11) NOT NULL,
  `owner` varchar(50) NOT NULL DEFAULT '-',
  `ownerid` int(11) NOT NULL,
  `address` varchar(50) DEFAULT 'None',
  `price` int(11) NOT NULL DEFAULT 500000,
  `type` int(11) NOT NULL DEFAULT 1,
  `locked` int(11) NOT NULL DEFAULT 1,
  `money` int(11) NOT NULL DEFAULT 0,
  `redmoney` int(11) NOT NULL DEFAULT 0,
  `houseint` int(11) NOT NULL DEFAULT 0,
  `extposx` float NOT NULL DEFAULT 0,
  `extposy` float NOT NULL DEFAULT 0,
  `extposz` float NOT NULL DEFAULT 0,
  `extposa` float NOT NULL DEFAULT 0,
  `intposx` float NOT NULL DEFAULT 0,
  `intposy` float NOT NULL DEFAULT 0,
  `intposz` float NOT NULL DEFAULT 0,
  `intposa` float NOT NULL DEFAULT 0,
  `visit` bigint(20) DEFAULT 0,
  `snack` int(11) NOT NULL DEFAULT 0,
  `sprunk` int(11) NOT NULL DEFAULT 0,
  `medicine` int(11) NOT NULL DEFAULT 0,
  `medkit` int(11) NOT NULL DEFAULT 0,
  `bandage` int(11) NOT NULL DEFAULT 0,
  `seed` int(11) NOT NULL DEFAULT 0,
  `material` int(11) NOT NULL DEFAULT 0,
  `marijuana` int(11) NOT NULL DEFAULT 0,
  `component` int(11) NOT NULL DEFAULT 0,
  `houseWeapon1` int(11) DEFAULT 0,
  `houseAmmo1` int(11) DEFAULT 0,
  `houseWeapon2` int(11) DEFAULT 0,
  `houseAmmo2` int(11) DEFAULT 0,
  `houseWeapon3` int(11) DEFAULT 0,
  `houseAmmo3` int(11) DEFAULT 0,
  `houseWeapon4` int(11) DEFAULT 0,
  `houseAmmo4` int(11) DEFAULT 0,
  `houseWeapon5` int(11) DEFAULT 0,
  `houseAmmo5` int(11) DEFAULT 0,
  `houseWeapon6` int(11) DEFAULT 0,
  `houseAmmo6` int(11) DEFAULT 0,
  `houseWeapon7` int(11) DEFAULT 0,
  `houseAmmo7` int(11) DEFAULT 0,
  `houseWeapon8` int(11) DEFAULT 0,
  `houseAmmo8` int(11) DEFAULT 0,
  `houseWeapon9` int(11) DEFAULT 0,
  `houseAmmo9` int(11) DEFAULT 0,
  `houseWeapon10` int(11) DEFAULT 0,
  `houseAmmo10` int(11) DEFAULT 0,
  `crack` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `houses`
--

INSERT INTO `houses` (`ID`, `owner`, `ownerid`, `address`, `price`, `type`, `locked`, `money`, `redmoney`, `houseint`, `extposx`, `extposy`, `extposz`, `extposa`, `intposx`, `intposy`, `intposz`, `intposa`, `visit`, `snack`, `sprunk`, `medicine`, `medkit`, `bandage`, `seed`, `material`, `marijuana`, `component`, `houseWeapon1`, `houseAmmo1`, `houseWeapon2`, `houseAmmo2`, `houseWeapon3`, `houseAmmo3`, `houseWeapon4`, `houseAmmo4`, `houseWeapon5`, `houseAmmo5`, `houseWeapon6`, `houseAmmo6`, `houseWeapon7`, `houseAmmo7`, `houseWeapon8`, `houseAmmo8`, `houseWeapon9`, `houseAmmo9`, `houseWeapon10`, `houseAmmo10`, `crack`) VALUES
(0, 'Clairo_Stevano', 2, 'Verdant Bluffs', 999999, 3, 0, 0, 0, 1, 995.274, -2115.25, 17.3381, 161.607, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1, 'Asep_Sumadi', 6, 'Idlewood', 25000, 2, 0, 0, 0, 1, 2165.96, -1671.17, 15.0787, 41.1906, 2180.81, -567.402, 1502.01, 179.241, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 'Clairo_Stevano', 2, 'Tierra Robada', 300000, 3, 0, 100000, 30000, 1, -757.419, 1638.03, 28.3031, 340.236, -407.29, -2086.18, 1501.1, 1.5718, 1653572844, 0, 0, 0, 0, 0, 0, 450, 0, 450, 15, 1, 24, 181, 25, 100, 7, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, '-', 0, 'Mulholland', 25000, 2, 1, 0, 0, 1, 989.762, -828.675, 95.4686, 209.824, -1498.78, -1824.89, 1501.1, 95.5258, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(4, '-', 0, 'Mulholland', 15000, 1, 1, 0, 0, 1, 937.586, -848.105, 93.6785, 209.454, -2169.94, -2135.54, 1501.1, 355.066, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(5, '-', 0, 'Mulholland', 15000, 1, 1, 0, 0, 1, 923.873, -853.309, 93.4565, 132.979, -2169.94, -2135.54, 1501.1, 355.066, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(6, '-', 0, 'Mulholland', 25000, 2, 1, 0, 0, 1, 910.561, -817.441, 103.126, 196.356, 2180.81, -567.402, 1502.01, 179.241, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(7, '-', 0, 'Mulholland', 25000, 2, 1, 0, 0, 1, 852.105, -831.707, 89.5017, 186.044, -1412.72, -232.986, 1501.02, 4.4778, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(8, '-', 0, 'Mulholland', 25000, 2, 1, 0, 0, 1, 827.732, -858.02, 70.3308, 14.9414, 2180.81, -567.402, 1502.01, 179.241, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(9, '-', 0, 'Mulholland', 35000, 3, 1, 0, 0, 1, 836.004, -894.892, 68.7734, 139.856, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(10, '-', 0, 'Mulholland', 45000, 2, 1, 0, 0, 1, 786.026, -828.572, 70.2896, 186.325, 2195.61, -738.623, 1502, 90.5592, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(11, '-', 0, 'Mulholland', 25000, 2, 1, 0, 0, 1, 808.254, -759.334, 76.5314, 75.9601, 2180.81, -567.402, 1502.01, 179.241, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(12, '-', 0, 'Mulholland', 25000, 2, 1, 0, 0, 1, 848.094, -745.62, 94.9693, 107.001, 2195.61, -738.623, 1502, 90.5592, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(13, '-', 0, 'Mulholland', 45000, 2, 1, 0, 0, 1, 867.655, -717.657, 105.68, 161.744, -1498.78, -1824.89, 1501.1, 95.5258, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(14, '-', 0, 'Red County', 45000, 2, 1, 0, 0, 1, 897.967, -677.06, 116.89, 50.4794, -1412.72, -232.986, 1501.02, 4.4778, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15, '-', 0, 'Red County', 15000, 1, 1, 0, 0, 1, 946.358, -710.668, 122.62, 216.408, -1562.02, -253.188, 1501.02, 99.1287, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(16, '-', 0, 'Red County', 30000, 3, 1, 0, 0, 1, 980.535, -677.232, 121.976, 199.07, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(17, '-', 0, 'Red County', 30000, 3, 1, 0, 0, 1, 231.234, -647.91, 120.117, 264.776, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(18, '-', 0, 'Red County', 30000, 3, 1, 0, 0, 1, 1045.37, -642.902, 120.117, 192.629, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(19, '-', 0, 'Mulholland', 30000, 3, 1, 0, 0, 1, 1332.11, -633.496, 109.135, 209.032, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(20, '-', 0, 'Mulholland', 25000, 2, 1, 0, 0, 1, 1442.71, -628.837, 95.7186, 350.088, -1498.78, -1824.89, 1501.1, 95.5258, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(21, '-', 0, 'Mulholland', 40000, 3, 1, 0, 0, 1, 1497.04, -687.892, 95.5633, 357.676, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(22, '-', 0, 'Mulholland Intersection', 40000, 2, 1, 0, 0, 1, 1527.81, -772.57, 80.5781, 308.766, 2195.61, -738.623, 1502, 90.5592, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(23, '-', 0, 'Mulholland Intersection', 25000, 2, 1, 0, 0, 1, 1535.03, -800.23, 72.8495, 262.223, -1498.78, -1824.89, 1501.1, 95.5258, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(24, '-', 0, 'Mulholland Intersection', 25000, 2, 1, 0, 0, 1, 1540.47, -851.425, 64.3361, 272.361, -1412.72, -232.986, 1501.02, 4.4778, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(25, '-', 0, 'Mulholland Intersection', 25000, 2, 1, 0, 0, 1, 1535.71, -885.244, 57.6575, 167.217, -1412.72, -232.986, 1501.02, 4.4778, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(26, '-', 0, 'Mulholland Intersection', 25000, 2, 1, 0, 0, 1, 1468.51, -906.184, 54.8359, 178.689, -1412.72, -232.986, 1501.02, 4.4778, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(27, '-', 0, 'Mulholland', 25000, 2, 1, 0, 0, 1, 1421.93, -886.231, 50.6809, 177.452, -1498.78, -1824.89, 1501.1, 95.5258, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(28, '-', 0, 'Mulholland', 40000, 3, 1, 0, 0, 1, 1410.84, -920.824, 38.4219, 339.487, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(29, '-', 0, 'Mulholland', 40000, 3, 1, 0, 0, 1, 1440.24, -926.081, 39.6406, 340.364, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(30, '-', 0, 'Temple', 35000, 3, 1, 0, 0, 1, 1241.95, -1076.28, 31.5547, 86.3404, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(31, '-', 0, 'Temple', 35000, 3, 1, 0, 0, 1, 1242.26, -1099.62, 27.9766, 76.2581, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(32, '-', 0, 'Temple', 35000, 3, 1, 0, 0, 1, 1285.26, -1090.33, 28.2578, 275.565, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(33, '-', 0, 'Temple', 35000, 3, 1, 0, 0, 1, 1285.25, -1067.06, 31.6719, 254.533, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(34, '-', 0, 'Temple', 35000, 3, 1, 0, 0, 1, 1325.95, -1067.43, 31.5547, 108.425, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(35, 'Valconic_Luxury', 26, 'Temple', 35000, 3, 1, 0, 0, 1, 1326.26, -1090.48, 27.9766, 84.7878, -407.29, -2086.18, 1501.1, 1.5718, 1679232933, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(36, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1227.25, -1017.17, 32.6016, 138.516, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(37, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1226.44, -1010.99, 32.6016, 97.049, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(38, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1233.92, -1009.97, 32.6016, 274.819, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(39, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1234.74, -1016.21, 32.6016, 278.635, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(40, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1227.25, -1017.13, 36.3359, 65.4854, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(41, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1234.74, -1016.21, 36.3359, 287.171, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(42, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1233.92, -1009.94, 36.3359, 259.335, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(43, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1226.45, -1011.09, 36.3359, 82.8534, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(44, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1188.18, -1011.81, 32.5469, 105.469, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(45, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1195.68, -1010.87, 36.2344, 255.364, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(46, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1188.31, -1011.67, 36.2344, 80.3322, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(47, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1188.99, -1017.9, 36.2344, 102.815, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(48, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1196.5, -1017.17, 36.2344, 280.283, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(49, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1196.48, -1017.01, 32.5469, 320.291, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(50, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1189.02, -1018.1, 32.5469, 88.9323, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(51, '-', 0, 'Temple', 10000, 4, 1, 0, 0, 2, 1195.53, -1010.88, 32.5502, 288.331, 266.49, 305.02, 999.14, 272.65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(52, '-', 0, 'Temple', 35000, 3, 1, 0, 0, 1, 1183.46, -1076.29, 31.6719, 272.203, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(53, '-', 0, 'Temple', 35000, 3, 1, 0, 0, 1, 1183.33, -1099.06, 28.2578, 285.873, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(54, '-', 0, 'Temple', 35000, 3, 1, 0, 0, 1, 1142.25, -1093, 28.1875, 71.6143, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(55, '-', 0, 'Temple', 35000, 3, 1, 0, 0, 1, 1141.81, -1069.74, 31.7656, 105.557, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(56, '-', 0, 'Temple', 35000, 3, 1, 0, 0, 1, 1103.4, -1092.5, 28.4688, 295.387, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(57, '-', 0, 'Temple', 35000, 3, 1, 0, 0, 1, 1103.39, -1069.41, 31.8828, 255.023, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(58, '-', 0, 'Temple', 40000, 3, 1, 0, 0, 1, 1068.42, -1081.41, 27.5314, 87.1339, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(59, '-', 0, 'Temple', 40000, 3, 1, 0, 0, 1, 1118.16, -1022.16, 34.9922, 4.82329, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(60, '-', 0, 'Temple', 40000, 3, 1, 0, 0, 1, 1128.19, -1021.17, 34.9922, 354.886, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(61, '-', 0, 'Rodeo', 15000, 1, 1, 0, 0, 1, 142.882, -1470.35, 24.7507, 326.521, -2169.94, -2135.54, 1501.1, 355.066, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(62, '-', 0, 'Rodeo', 15000, 1, 1, 0, 0, 1, 161.524, -1455.86, 32.845, 37.7987, -2169.94, -2135.54, 1501.1, 355.066, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(63, '-', 0, 'Rodeo', 25000, 2, 1, 0, 0, 1, 228.367, -1405.66, 51.1491, 237.149, 2195.61, -738.623, 1502, 90.5592, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(64, '-', 0, 'Richman', 35000, 3, 1, 0, 0, 1, 254.344, -1367.08, 53.1094, 116.506, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(65, '-', 0, 'Richman', 35000, 3, 1, 0, 0, 1, 298.865, -1338.49, 53.4405, 220.962, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(66, '-', 0, 'Rodeo', 25000, 2, 1, 0, 0, 1, 345.156, -1298.22, 50.759, 95.2767, -1498.78, -1824.89, 1501.1, 95.5258, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(67, '-', 0, 'Richman', 25000, 2, 1, 0, 0, 1, 355.209, -1281.12, 53.7036, 194.394, -675.012, -2166.27, 1501.1, 183.527, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(68, '-', 0, 'Richman', 25000, 2, 1, 0, 0, 1, 398.136, -1271.38, 50.0198, 214.599, 2180.81, -567.402, 1502.01, 179.241, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(69, '-', 0, 'Richman', 25000, 2, 1, 0, 0, 1, 432.189, -1253.9, 51.5809, 194.041, 2195.61, -738.623, 1502, 90.5592, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(70, '-', 0, 'Richman', 40000, 3, 1, 0, 0, 1, 265.634, -1287.84, 74.6325, 20.4386, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(71, '-', 0, 'Richman', 40000, 3, 1, 0, 0, 1, 189.638, -1308.29, 70.2554, 96.3397, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(72, '-', 0, 'Richman', 40000, 3, 1, 0, 0, 1, 31.9485, -1249.82, 77.8754, 358.773, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(73, '-', 0, 'Richman', 40000, 3, 1, 0, 0, 1, 251.441, -1220.21, 76.1024, 32.7536, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(74, '-', 0, 'Richman', 40000, 3, 1, 0, 0, 1, 300.167, -1154.38, 81.3953, 313.135, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(75, '-', 0, 'Richman', 25000, 2, 1, 0, 0, 1, 352.379, -1197.95, 76.5156, 208.855, 2180.81, -567.402, 1502.01, 179.241, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(76, '-', 0, 'Richman', 25000, 2, 1, 0, 0, 1, 416.741, -1154.1, 76.6876, 334.635, 2195.61, -738.623, 1502, 90.5592, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(77, '-', 0, 'Richman', 25000, 2, 1, 0, 0, 1, 559.165, -1076.38, 72.922, 187.647, 2180.81, -567.402, 1502.01, 179.241, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(78, '-', 0, 'Richman', 30000, 2, 1, 0, 0, 1, 497.416, -1095.07, 82.3592, 175.836, -1412.72, -232.986, 1501.02, 4.4778, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(79, 'Hanz_Einer', 18, 'Mulholland', 40000, 3, 1, 0, 0, 1, 1093.86, -807.144, 107.427, 193.377, -1036.63, -2205.94, 1501.09, 358.705, 1679235049, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(80, 'Xeno_Oconner', 20, 'Mulholland', 50000, 3, 0, 0, 0, 1, 1298.42, -797.986, 84.1406, 1.73427, -407.29, -2086.18, 1501.1, 1.5718, 1679214744, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(81, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2367.43, -49.1273, 28.1535, 173.214, 2195.61, -738.623, 1502, 90.5592, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(82, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2392.46, -54.9605, 28.1536, 145.749, -675.012, -2166.27, 1501.1, 183.527, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(83, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2415.44, -52.2836, 28.1535, 167.034, -675.012, -2166.27, 1501.1, 183.527, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(84, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2438.91, -54.9624, 28.1535, 200.976, -1412.72, -232.986, 1501.02, 4.4778, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(85, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2484.35, -28.4033, 28.4416, 162.86, 2180.81, -567.402, 1502.01, 179.241, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(86, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2513.36, -28.4031, 28.4416, 167.48, 2195.61, -738.623, 1502, 90.5592, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(87, '-', 0, 'Palomino Creek', 15000, 1, 1, 0, 0, 1, 2551.22, -5.43927, 27.6756, 257.609, -2169.94, -2135.54, 1501.1, 355.066, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(88, '-', 0, 'Palomino Creek', 20000, 1, 1, 0, 0, 1, 2549.23, 25.0127, 27.6756, 263.894, -2169.94, -2135.54, 1501.1, 355.066, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(89, '-', 0, 'Palomino Creek', 15000, 1, 1, 0, 0, 1, 2551.22, 57.2873, 27.6756, 271.835, -2169.94, -2135.54, 1501.1, 355.066, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(90, '-', 0, 'Palomino Creek', 20000, 1, 1, 0, 0, 1, 2518.63, 58.3698, 27.6835, 83.2911, 2206.93, -402.681, 1502.01, 187.121, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(91, '-', 0, 'Palomino Creek', 15000, 1, 1, 0, 0, 1, 2551.22, 91.7184, 27.6756, 288.426, 2206.93, -402.681, 1502.01, 187.121, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(92, '-', 0, 'Palomino Creek', 15000, 1, 1, 0, 0, 1, 2514.12, 94.3949, 27.6835, 177.045, -1562.02, -253.188, 1501.02, 99.1287, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(93, '-', 0, 'Palomino Creek', 15000, 1, 1, 0, 0, 1, 2536.21, 128.987, 27.6835, 13.5859, -2169.94, -2135.54, 1501.1, 355.066, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(94, '-', 0, 'Palomino Creek', 15000, 1, 1, 0, 0, 1, 2518.38, 128.977, 27.6756, 21.996, -1562.02, -253.188, 1501.02, 99.1287, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(95, '-', 0, 'Palomino Creek', 20000, 1, 1, 0, 0, 1, 2480.53, 126.995, 27.6756, 339.756, -2169.94, -2135.54, 1501.1, 355.066, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(96, '-', 0, 'Palomino Creek', 15000, 1, 1, 0, 0, 1, 2458.89, 128.987, 27.6756, 334.457, -2169.94, -2135.54, 1501.1, 355.066, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(97, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2443.85, 92.1717, 28.4416, 76.361, -1412.72, -232.986, 1501.02, 4.4778, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(98, '-', 0, 'Palomino Creek', 15000, 1, 1, 0, 0, 1, 2481.22, 64.4798, 27.6835, 271.461, -1562.02, -253.188, 1501.02, 99.1287, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(99, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2443.35, 61.7584, 28.4416, 35.9028, -675.012, -2166.27, 1501.1, 183.527, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(100, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2413.68, 61.7616, 28.4416, 341.388, -1498.78, -1824.89, 1501.1, 95.5258, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(101, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2374.2, 42.1876, 28.4416, 93.9712, -1498.78, -1824.89, 1501.1, 95.5258, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(102, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2373.85, 71.245, 28.4416, 82.8625, -1498.78, -1824.89, 1501.1, 95.5258, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(103, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2398.45, 111.763, 28.4416, 34.4743, 2195.61, -738.623, 1502, 90.5592, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(104, '-', 0, 'Palomino Creek', 35000, 3, 1, 0, 0, 1, 2270.34, -7.57953, 28.1536, 2.7262, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(105, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2245.54, -1.66294, 28.1536, 353.26, -675.012, -2166.27, 1501.1, 183.527, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(106, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2199.96, -37.3463, 28.1535, 85.7412, -675.012, -2166.27, 1501.1, 183.527, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(107, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2197.27, -60.7517, 28.1535, 104.826, 2195.61, -738.623, 1502, 90.5592, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(108, '-', 0, 'Palomino Creek', 25000, 2, 1, 0, 0, 1, 2203.11, -89.1832, 28.1535, 106.782, -1412.72, -232.986, 1501.02, 4.4778, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(109, '-', 0, 'Jefferson', 45000, 2, 1, 0, 0, 1, 2100.94, -1321.89, 25.9531, 160.761, -1412.72, -232.986, 1501.02, 4.4778, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(110, '-', 0, 'Ganton', 50000, 3, 1, 0, 0, 1, 2413.94, -1646.79, 14.0119, 347.084, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(111, '-', 0, 'East Beach', 45000, 3, 1, 0, 0, 1, 2822.92, -1166.68, 25.4133, 70.4355, -407.29, -2086.18, 1501.1, 1.5718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(112, '-', 0, 'Tierra Robada', 40000, 3, 1, 0, 0, 1, -686.339, 966.203, 14.6981, 19.7104, -1036.63, -2205.94, 1501.09, 358.705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `lockers`
--

CREATE TABLE `lockers` (
  `id` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT 0,
  `posx` float NOT NULL DEFAULT 0,
  `posy` float NOT NULL DEFAULT 0,
  `posz` float NOT NULL DEFAULT 0,
  `interior` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `lockers`
--

INSERT INTO `lockers` (`id`, `type`, `posx`, `posy`, `posz`, `interior`) VALUES
(4, 4, -172.482, 1314.94, 1500.99, 5),
(3, 2, -2055.47, 2709.41, 1500.98, 5),
(2, 1, 88.582, 1053.07, -48.9141, 5),
(1, 3, -1772.63, -1989.81, 1500.79, 5),
(0, 5, 1231.66, -1427.09, 13.5588, 0),
(5, 2, -2071.53, 2708.98, 1500.98, 5),
(6, 1, 113.976, 1061.35, -48.9141, 5),
(7, 3, -1770.25, -2007.83, 1500.79, 5),
(8, 4, -208.581, 1297.06, 1507.67, 5);

-- --------------------------------------------------------

--
-- Table structure for table `loglogin`
--

CREATE TABLE `loglogin` (
  `no` int(11) NOT NULL,
  `username` varchar(40) NOT NULL DEFAULT 'None',
  `reg_id` int(11) NOT NULL DEFAULT 0,
  `password` varchar(40) NOT NULL DEFAULT 'None',
  `time` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `loglogin`
--

INSERT INTO `loglogin` (`no`, `username`, `reg_id`, `password`, `time`) VALUES
(1, 'Jhono', 0, 'Jancok123', '2022-05-17 11:51:07'),
(2, 'Jhono', 0, 'Jancok123', '2022-05-17 12:06:52'),
(3, 'Jhono', 0, 'Jancok123', '2022-05-17 12:18:06'),
(4, 'Vail', 1, 'ulum123', '2022-05-17 12:24:34'),
(5, 'Jhono', 0, 'Jancok123', '2022-05-17 12:26:02'),
(6, 'Vail', 1, 'ulum123', '2022-05-17 12:27:50'),
(7, 'clairo', 1, 'yopicoy123', '2022-05-17 12:37:08'),
(8, 'Jhono', 2, 'Jancok123', '2022-05-17 12:37:24'),
(9, 'Vail', 3, 'ulum123', '2022-05-17 12:39:23'),
(10, 'Andi', 0, 'andiaja', '2022-05-17 12:40:43'),
(11, 'clairo', 0, 'yopicoy123', '2022-05-17 12:43:51'),
(12, 'Jhono', 0, 'Jancok123', '2022-05-17 12:44:41'),
(13, 'clairo', 1, 'yopicoy123', '2022-05-17 12:44:50'),
(14, 'Jhono', 0, 'Jancok123', '2022-05-17 12:45:57'),
(15, 'Jhono', 1, 'Jancok123', '2022-05-17 12:49:30'),
(16, 'Vail', 0, 'ulum123', '2022-05-17 12:49:42'),
(17, 'Buyan', 2, 'buyan123', '2022-05-17 12:50:20'),
(18, 'ubed', 0, 'riotoejhen', '2022-05-17 12:51:01'),
(19, 'Vail', 1, 'ulum123', '2022-05-17 12:51:10'),
(20, 'Jhono', 4, 'Jancok123', '2022-05-17 12:51:33'),
(21, 'Buyan', 2, 'buyan123', '2022-05-17 12:54:26'),
(22, 'clairo', 1, 'yopicoy123', '2022-05-17 12:58:11'),
(23, 'clairo', 1, 'yopicoy123', '2022-05-17 13:00:06'),
(24, 'clairo', 0, 'yopicoy123', '2022-05-17 13:17:26'),
(25, 'Jhono', 0, 'Jancok123', '2022-05-17 13:30:46'),
(26, 'Jhono', 0, 'Jancok123', '2022-05-17 13:48:49'),
(27, 'Jhono', 0, 'Jancok123', '2022-05-17 17:06:30'),
(28, 'Jhono', 0, 'Jancok123', '2022-05-17 18:04:25'),
(29, 'Jhono', 0, 'Jancok123', '2022-05-17 18:07:34'),
(30, 'ubed', 1, 'riotoejhen', '2022-05-17 18:10:19'),
(31, 'Buyan', 2, 'buyan123', '2022-05-17 18:11:30'),
(32, 'Buyan', 3, 'buyan123', '2022-05-17 18:12:51'),
(33, 'Licht', 2, 'RikoGanz', '2022-05-17 18:14:59'),
(34, 'Licht', 2, 'RikoGanz', '2022-05-17 18:24:35'),
(35, 'ubed', 1, 'riotoejhen', '2022-05-17 18:31:24'),
(36, 'ubed', 1, 'riotoejhen', '2022-05-17 18:42:09'),
(37, 'Jhono', 0, 'Jancok123', '2022-05-17 18:45:17'),
(38, 'ubed', 1, 'riotoejhen', '2022-05-17 18:51:31'),
(39, 'ubed', 1, 'riotoejhen', '2022-05-17 18:58:57'),
(40, 'ubed', 1, 'riotoejhen', '2022-05-17 18:59:26'),
(41, 'ubed', 1, 'riotoejhen', '2022-05-17 19:00:25'),
(42, 'ubed', 1, 'riotoejhen', '2022-05-17 19:01:21'),
(43, 'ubed', 1, 'riotoejhen', '2022-05-17 19:02:10'),
(44, 'ubed', 1, 'riotoejhen', '2022-05-17 19:02:55'),
(45, 'ubed', 1, 'riotoejhen', '2022-05-17 19:03:29'),
(46, 'Buyan', 3, 'buyan123', '2022-05-17 19:08:41'),
(47, 'ubed', 1, 'riotoejhen', '2022-05-17 19:08:43'),
(48, 'ubed', 1, 'riotoejhen', '2022-05-17 19:09:25'),
(49, 'ubed', 1, 'riotoejhen', '2022-05-17 19:10:00'),
(50, 'ubed', 1, 'riotoejhen', '2022-05-17 19:11:03'),
(51, 'Licht', 1, 'RikoGanz', '2022-05-17 19:14:01'),
(52, 'ubed', 2, 'riotoejhen', '2022-05-17 19:15:11'),
(53, 'Jhono', 0, 'Jancok123', '2022-05-17 19:16:37'),
(54, 'ubed', 2, 'riotoejhen', '2022-05-17 19:17:02'),
(55, 'ubed', 2, 'riotoejhen', '2022-05-17 19:18:24'),
(56, 'Buyan', 3, 'buyan123', '2022-05-17 19:19:15'),
(57, 'ubed', 2, 'riotoejhen', '2022-05-17 19:19:37'),
(58, 'ubed', 2, 'riotoejhen', '2022-05-17 19:20:30'),
(59, 'ubed', 2, 'riotoejhen', '2022-05-17 19:21:52'),
(60, 'Licht', 1, 'RikoGanz', '2022-05-17 19:28:06'),
(61, 'ubed', 0, 'riotoejhen', '2022-05-17 19:40:32'),
(62, 'clairo', 0, 'yopicoy123', '2022-05-17 23:15:14'),
(63, 'Buyan', 1, 'buyan123', '2022-05-17 23:22:13'),
(64, 'Buyan', 1, 'buyan123', '2022-05-17 23:46:49'),
(65, 'Buyan', 0, 'buyan123', '2022-05-18 00:00:38'),
(66, 'clairo', 0, 'yopicoy123', '2022-05-24 05:23:54'),
(67, 'clairo', 0, 'yopicoy123', '2022-05-24 05:51:18'),
(68, 'clairo', 0, 'yopicoy123', '2022-05-24 06:49:39'),
(69, 'Clairo', 0, 'yopicoy123', '2022-05-24 07:05:22'),
(70, 'clairo', 0, 'yopicoy123', '2022-05-24 07:12:38'),
(71, 'clairo', 0, 'yopicoy123', '2022-05-24 07:15:35'),
(72, 'clairo', 0, 'yopicoy123', '2022-05-24 07:34:38'),
(73, 'clairo', 0, 'yopicoy123', '2022-05-24 07:42:18'),
(74, 'clairo', 0, 'yopicoy123', '2022-05-24 07:49:47'),
(75, 'clairo', 0, 'yopicoy123', '2022-05-24 08:15:45'),
(76, 'clairo', 0, 'yopicoy123', '2022-05-24 08:24:20'),
(77, 'clairo', 0, 'yopicoy123', '2022-05-24 08:31:01'),
(78, 'clairo', 0, 'yopicoy123', '2022-05-24 12:06:28'),
(79, 'clairo', 0, 'yopicoy123', '2022-05-24 12:07:06'),
(80, 'clairo', 0, 'yopicoy123', '2022-05-24 20:10:35'),
(81, 'clairo', 0, 'yopicoy123', '2022-05-24 20:26:02'),
(82, 'clairo', 0, 'yopicoy123', '2022-05-24 20:38:46'),
(83, 'clairo', 0, 'yopicoy123', '2022-05-26 13:46:03'),
(84, 'clairo', 0, 'yopicoy123', '2022-05-26 14:11:09'),
(85, 'clairo', 0, 'yopicoy123', '2022-05-26 14:15:15'),
(86, 'clairo', 0, 'yopicoy123', '2022-05-26 14:21:41'),
(87, 'clairo', 0, 'yopicoy123', '2022-05-26 15:47:52'),
(88, 'clairo', 0, 'yopicoy123', '2022-05-26 22:37:25'),
(89, 'clairo', 0, 'yopicoy123', '2022-05-27 03:27:31'),
(90, 'clairo', 0, 'yopicoy123', '2022-05-27 03:55:43'),
(91, 'clairo', 0, 'yopicoy123', '2022-05-27 04:04:50'),
(92, 'clairo', 0, 'yopicoy123', '2022-05-27 06:32:47'),
(93, 'Jhono', 1, 'Jancok123', '2022-05-27 06:34:34'),
(94, 'clairo', 0, 'yopicoy123', '2022-05-27 06:36:09'),
(95, 'Dubaii', 2, 'super123', '2022-05-27 06:40:26'),
(96, 'clairo', 0, 'yopicoy123', '2022-05-27 06:43:01'),
(97, 'clairo', 0, 'yopicoy123', '2022-05-27 07:29:57'),
(98, 'clairo', 0, 'yopicoy123', '2022-05-27 08:25:38'),
(99, 'Clairo', 0, 'yopicoy123', '2022-05-27 08:30:17'),
(100, 'clairo', 0, 'yopicoy123', '2022-05-27 09:55:46'),
(101, 'clairo', 0, 'yopicoy123', '2022-05-27 10:14:16'),
(102, 'clairo', 0, 'yopicoy123', '2022-05-27 10:23:29'),
(103, 'clairo', 0, 'yopicoy123', '2022-05-27 10:40:30'),
(104, 'clairo', 0, 'yopicoy123', '2022-05-27 10:41:27'),
(105, 'clairo', 0, 'yopicoy123', '2022-05-27 10:43:09'),
(106, 'clairo', 0, 'yopicoy123', '2022-05-27 10:48:43'),
(107, 'clairo', 0, 'yopicoy123', '2022-05-27 10:54:02'),
(108, 'Clairo', 0, 'yopicoy123', '2022-05-27 10:58:21'),
(109, 'Clairo', 0, 'yopicoy123', '2022-05-27 11:24:21'),
(110, 'clairo', 0, 'yopicoy123', '2022-05-27 12:12:56'),
(111, 'clairo', 0, 'yopicoy123', '2022-05-27 12:16:21'),
(112, 'Clairo', 0, 'yopicoy123', '2022-05-27 12:29:23'),
(113, 'clairo', 0, 'yopicoy123', '2022-05-28 02:04:44'),
(114, 'clairo', 0, 'yopicoy123', '2022-05-28 02:09:19'),
(115, 'clairo', 0, 'yopicoy123', '2022-05-28 02:21:34'),
(116, 'clairo', 0, 'yopicoy123', '2022-05-28 02:28:19'),
(117, 'clairo', 0, 'yopicoy123', '2022-05-28 02:29:17'),
(118, 'clairo', 0, 'yopicoy123', '2022-05-28 02:42:26'),
(119, 'clairo', 0, 'yopicoy123', '2022-05-28 02:48:18'),
(120, 'clairo', 0, 'yopicoy123', '2022-05-28 02:50:18'),
(121, 'clairo', 0, 'yopicoy123', '2022-05-28 02:59:28'),
(122, 'clairo', 0, 'yopicoy123', '2022-05-28 03:04:21'),
(123, 'clairo', 0, 'yopicoy123', '2022-05-28 03:32:44'),
(124, 'clairo', 0, 'yopicoy123', '2022-05-28 03:57:32'),
(125, 'clairo', 0, 'yopicoy123', '2022-05-28 03:59:25'),
(126, 'clairo', 0, 'yopicoy123', '2022-05-28 04:21:40'),
(127, 'clairo', 0, 'yopicoy123', '2022-05-28 04:55:20'),
(128, 'clairo', 0, 'yopicoy123', '2022-05-28 05:03:30'),
(129, 'clairo', 0, 'yopicoy123', '2022-05-28 05:21:30'),
(130, 'clairo', 0, 'yopicoy123', '2022-05-28 05:57:17'),
(131, 'clairo', 0, 'yopicoy123', '2022-05-28 06:31:17'),
(132, 'clairo', 0, 'yopicoy123', '2022-05-28 06:36:23'),
(133, 'clairo', 0, 'yopicoy123', '2022-05-28 07:07:11'),
(134, 'clairo', 0, 'yopicoy123', '2022-05-28 07:09:25'),
(135, 'clairo', 0, 'yopicoy123', '2022-05-28 07:18:19'),
(136, 'clairo', 0, 'yopicoy123', '2022-05-28 07:21:08'),
(137, 'clairo', 0, 'yopicoy123', '2022-05-28 07:22:14'),
(138, 'clairo', 0, 'yopicoy123', '2022-05-28 07:34:07'),
(139, 'clairo', 0, 'yopicoy123', '2022-05-28 07:44:48'),
(140, 'clairo', 0, 'yopicoy123', '2022-05-28 10:15:45'),
(141, 'Clairo', 0, 'yopicoy123', '2022-05-28 12:36:20'),
(142, 'Clairo', 0, 'yopicoy123', '2022-05-28 12:38:29'),
(143, 'Clairo', 0, 'yopicoy123', '2022-05-28 12:40:21'),
(144, 'Clairo', 0, 'yopicoy123', '2022-05-28 13:31:51'),
(145, 'Clairo', 0, 'yopicoy123', '2022-05-28 13:41:04'),
(146, 'Clairo', 0, 'yopicoy123', '2022-05-28 13:43:39'),
(147, 'Clairo', 0, 'yopicoy123', '2022-05-28 13:57:49'),
(148, 'Clairo', 0, 'yopicoy123', '2022-05-28 14:01:54'),
(149, 'Clairo', 0, 'yopicoy123', '2022-05-28 14:05:17'),
(150, 'Clairo', 0, 'yopicoy123', '2022-05-28 14:16:21'),
(151, 'Clairo', 0, 'yopicoy123', '2022-05-28 14:23:33'),
(152, 'Clairo', 0, 'yopicoy123', '2022-05-28 14:32:56'),
(153, 'Clairo', 0, 'yopicoy123', '2022-05-28 14:54:40'),
(154, 'Clairo', 0, 'yopicoy123', '2022-05-28 14:58:56'),
(155, 'Clairo', 0, 'yopicoy123', '2022-05-28 15:22:19'),
(156, 'Clairo', 0, 'yopicoy123', '2022-05-28 15:59:51'),
(157, 'Clairo', 0, 'yopicoy123', '2022-05-28 17:36:26'),
(158, 'Clairo', 0, 'yopicoy123', '2022-05-28 17:43:47'),
(159, 'Clairo', 0, 'yopicoy123', '2022-05-28 17:46:41'),
(160, 'Clairo', 0, 'yopicoy123', '2022-05-28 17:51:09'),
(161, 'Clairo', 0, 'yopicoy123', '2022-05-29 01:30:34'),
(162, 'Clairo', 0, 'yopicoy123', '2022-05-29 08:21:30'),
(163, 'Clairo', 0, 'yopicoy123', '2022-05-29 09:55:52'),
(164, 'Clairo', 0, 'yopicoy123', '2022-05-29 09:57:29'),
(165, 'Clairo', 0, 'yopicoy123', '2022-05-29 10:02:07'),
(166, 'Clairo', 0, 'yopicoy123', '2022-05-29 10:02:56'),
(167, 'Clairo', 0, 'yopicoy123', '2022-05-29 10:13:50'),
(168, 'Clairo', 0, 'yopicoy123', '2022-05-29 12:08:57'),
(169, 'Clairo', 0, 'yopicoy123', '2022-05-29 12:41:09'),
(170, 'Clairo', 0, 'yopicoy123', '2022-05-29 13:15:52'),
(171, 'Clairo', 0, 'yopicoy123', '2022-05-29 13:17:51'),
(172, 'Clairo', 0, 'yopicoy123', '2022-05-29 13:19:46'),
(173, 'Clairo', 0, 'yopicoy123', '2022-05-29 13:20:23'),
(174, 'Clairo', 0, 'yopicoy123', '2022-05-29 13:23:26'),
(175, 'Clairo', 0, 'yopicoy123', '2022-05-29 13:41:22'),
(176, 'Clairo', 0, 'yopicoy123', '2022-05-29 13:43:09'),
(177, 'Clairo', 0, 'yopicoy123', '2022-05-29 13:44:01'),
(178, 'Clairo', 0, 'yopicoy123', '2022-05-29 13:44:42'),
(179, 'Clairo', 0, 'yopicoy123', '2022-05-29 13:45:36'),
(180, 'Clairo', 0, 'yopicoy123', '2022-05-29 13:46:07'),
(181, 'Clairo', 0, 'yopicoy123', '2022-05-29 13:49:43'),
(182, 'Clairo', 0, 'yopicoy123', '2022-05-29 15:39:27'),
(183, 'Arch', 0, 'goblok1301', '2022-06-03 04:14:36'),
(184, 'Arch', 0, 'goblok1301', '2022-06-03 04:17:35'),
(185, 'Arch', 0, 'goblok1301', '2022-06-03 04:19:26'),
(186, 'Arch', 0, 'goblok1301', '2022-06-03 04:22:17'),
(187, 'Arch', 0, 'goblok1301', '2022-06-03 04:32:07'),
(188, 'Arch', 0, 'goblok1301', '2022-06-03 04:38:26'),
(189, 'Arch', 0, 'goblok1301', '2022-06-03 04:46:01'),
(190, 'Arch', 0, 'goblok1301', '2022-06-03 04:50:54'),
(191, 'Arch', 0, 'goblok1301', '2022-06-03 04:53:06'),
(192, 'Arch', 0, 'goblok1301', '2022-06-03 04:58:45'),
(193, 'Arch', 1, 'goblok1301', '2022-06-03 05:40:04'),
(194, 'Arch', 0, 'goblok1301', '2022-06-03 05:48:15'),
(195, 'Arch', 0, 'goblok1301', '2022-06-03 05:49:58'),
(196, 'Arch', 0, 'goblok1301', '2022-06-03 06:25:40'),
(197, 'Isac', 1, '123456', '2022-06-03 06:35:23'),
(198, 'Jhono', 2, 'Jancok123', '2022-06-03 06:35:24'),
(199, 'Arch', 0, 'goblok1301', '2022-06-03 06:50:53'),
(200, 'Jhono', 0, 'Jancok123', '2022-06-06 03:53:03'),
(201, 'Arch', 1, 'goblok1301', '2022-06-06 03:54:02'),
(202, 'Jhono', 0, 'Jancok123', '2022-06-06 03:57:20'),
(203, 'Arch', 1, 'goblok1301', '2022-06-06 03:57:27'),
(204, 'Arch', 0, 'goblok1301', '2022-06-06 04:03:34'),
(205, 'Jhono', 1, 'Jancok123', '2022-06-06 04:03:52'),
(206, 'Isac', 2, '123456', '2022-06-06 04:12:22'),
(207, 'Arch', 0, 'goblok1301', '2022-06-06 04:22:43'),
(208, 'Arch', 0, 'goblok1301', '2022-06-06 05:06:46'),
(209, 'Arch', 0, 'goblok1301', '2022-06-06 05:09:07'),
(210, 'Arch', 0, 'goblok1301', '2022-06-06 05:30:08'),
(211, 'Arch', 0, 'goblok1301', '2022-06-06 05:37:38'),
(212, 'Arch', 0, 'goblok1301', '2022-06-06 05:40:11'),
(213, 'Arch', 0, 'goblok1301', '2022-06-06 06:59:48'),
(214, 'Jhono', 0, 'Jancok123', '2022-06-08 02:34:02'),
(215, 'Arch', 1, 'goblok1301', '2022-06-08 02:34:16'),
(216, 'Arch', 0, 'goblok1301', '2022-06-08 02:39:02'),
(217, 'Jhono', 1, 'Jancok123', '2022-06-08 02:39:06'),
(218, 'Jhono', 0, 'Jancok123', '2022-06-08 02:40:16'),
(219, 'Arch', 1, 'goblok1301', '2022-06-08 02:40:30'),
(220, 'Arch', 0, 'goblok1301', '2022-06-08 03:06:34'),
(221, 'Jhono', 1, 'Jancok123', '2022-06-08 03:06:44'),
(222, 'Arch', 0, 'goblok1301', '2022-06-08 03:14:20'),
(223, 'Arch', 0, 'goblok1301', '2022-06-08 03:16:47'),
(224, 'Arch', 0, 'goblok1301', '2022-06-08 03:24:15'),
(225, 'Arch', 0, 'goblok1301', '2022-06-08 03:26:29'),
(226, 'Arch', 0, 'goblok1301', '2022-06-08 03:29:56'),
(227, 'Arch', 0, 'goblok1301', '2022-06-08 04:34:06'),
(228, 'Jhono', 0, 'Jancok123', '2022-06-11 04:06:54'),
(229, 'Arch', 1, 'goblok1301', '2022-06-11 04:08:45'),
(230, 'Arch', 1, 'goblok1301', '2022-06-11 04:15:52'),
(231, 'Jhono', 0, 'Jancok123', '2022-06-11 04:16:00'),
(232, 'Jhono', 0, 'Jancok123', '2022-06-11 04:44:52'),
(233, 'Arch', 1, 'goblok1301', '2022-06-11 04:44:56'),
(234, 'Arch', 0, 'Farhan05', '2022-06-20 04:40:17'),
(235, 'Arch', 0, 'Farhan05', '2022-06-20 04:43:57'),
(236, 'Arch', 0, 'Farhan05', '2022-06-20 04:46:01'),
(237, 'Arch', 0, 'Farhan05', '2022-06-20 04:49:07'),
(238, 'Arch', 0, 'Farhan05', '2022-06-20 04:54:32'),
(239, 'Arch', 0, 'Farhan05', '2022-06-20 05:02:16'),
(240, 'Arch', 0, 'Farhan05', '2022-06-20 05:05:11'),
(241, 'Arch', 0, 'Farhan05', '2022-06-20 05:37:21'),
(242, 'Arch', 0, 'Farhan05', '2022-06-20 05:42:48'),
(243, 'Arch', 0, 'Farhan05', '2022-06-20 05:43:58'),
(244, 'Arch', 0, 'Farhan05', '2022-06-20 05:44:44'),
(245, 'Arch', 0, 'Farhan05', '2022-06-20 07:21:22'),
(246, 'Arch', 0, 'Farhan05', '2022-06-20 07:23:21'),
(247, 'Arch', 0, 'Farhan05', '2022-06-20 07:34:06'),
(248, 'Arch', 0, 'Farhan05', '2022-06-20 07:35:11'),
(249, 'Andre', 1, 'gameburik', '2022-07-07 14:35:47'),
(250, 'Andre', 0, 'gameburik', '2022-07-07 15:44:53'),
(251, 'Andre', 0, 'gameburik', '2022-07-07 15:45:54'),
(252, 'Andre', 0, 'gameburik', '2022-07-07 15:52:59'),
(253, 'Andre', 0, 'gameburik', '2022-07-10 12:42:37'),
(254, 'Andre', 0, 'gameburik', '2022-07-16 15:31:48'),
(255, 'Andre', 0, 'gameburik', '2022-07-16 15:37:00'),
(256, 'Andre', 0, 'gameburik', '2022-07-16 15:45:35'),
(257, 'Andre', 0, 'gameburik', '2022-07-16 15:52:39'),
(258, 'Andre', 0, 'gameburik', '2022-07-16 15:58:54'),
(259, 'Andre', 0, 'gameburik', '2022-07-16 16:03:08'),
(260, 'Andre', 0, 'gameburik', '2022-07-16 16:04:15'),
(261, 'Andre', 0, 'gameburik', '2022-07-16 16:14:58'),
(262, 'Andre', 0, 'gameburik', '2022-07-16 16:19:06'),
(263, 'Andre', 0, 'gameburik', '2022-07-16 16:41:17'),
(264, 'Andre', 0, 'gameburik', '2022-07-16 16:46:39'),
(265, 'Andre', 0, 'gameburik', '2022-07-16 16:56:07'),
(266, 'Andre', 0, 'gameburik', '2022-07-16 17:05:30'),
(267, 'Andre', 0, 'gameburik', '2022-07-16 21:09:23'),
(268, 'Andre', 0, 'gameburik', '2022-07-16 21:17:32'),
(269, 'ken', 0, 'hajiihya', '2022-09-23 00:21:56'),
(270, 'ken', 0, 'hajiihya', '2022-09-23 00:31:10'),
(271, 'Aldi147', 1, 'aldi147', '2022-09-23 00:35:38'),
(272, 'Nuel', 2, 'ende4you', '2022-09-23 00:37:22'),
(273, 'Aldi147', 1, 'aldi147', '2022-09-23 00:43:05'),
(274, 'Aldi147', 0, 'aldi147', '2022-09-23 01:15:57'),
(275, 'ken', 2, 'hajiihya', '2022-09-23 01:16:32'),
(276, 'Nuel', 1, 'ende4you', '2022-09-23 01:16:34'),
(277, 'heleh', 0, '111111', '2023-03-19 03:04:23'),
(278, 'heleh', 0, '111111', '2023-03-19 03:07:55'),
(279, 'heleh', 0, '111111', '2023-03-19 03:14:50'),
(280, 'heleh', 0, '111111', '2023-03-19 03:25:36'),
(281, 'heleh', 0, '111111', '2023-03-19 03:34:51'),
(282, 'Dhann', 1, 'dhani90900', '2023-03-19 03:40:03'),
(283, 'heleh', 0, '111111', '2023-03-19 03:40:35'),
(284, 'Dhann', 0, 'dhani90900', '2023-03-19 03:46:39'),
(285, 'heleh', 1, '111111', '2023-03-19 03:47:42'),
(286, 'Dhann', 0, 'dhani90900', '2023-03-19 04:12:26'),
(287, 'Razzel', 0, 'zaky2007', '2023-03-19 05:32:55'),
(288, 'Ozann', 1, 'salahsattu', '2023-03-19 05:41:27'),
(289, 'Hanz', 0, '311208', '2023-03-19 05:45:06'),
(290, 'Deriss', 1, 'deris1212', '2023-03-19 05:46:39'),
(291, 'Alex', 1, 'Zawarudo123', '2023-03-19 06:11:05'),
(292, 'Metthew', 0, 'Anjing231', '2023-03-19 06:17:33'),
(293, 'Dhann', 1, 'dhani90900', '2023-03-19 06:21:09'),
(294, 'Dhann', 1, 'dhani90900', '2023-03-19 06:21:51'),
(295, 'Hanz', 2, '311208', '2023-03-19 06:22:21'),
(296, 'Dhann', 1, 'dhani90900', '2023-03-19 06:22:52'),
(297, 'Dhann', 1, 'dhani90900', '2023-03-19 06:23:30'),
(298, 'Dhann', 1, 'dhani90900', '2023-03-19 06:24:03'),
(299, 'Dhann', 1, 'dhani90900', '2023-03-19 06:24:40'),
(300, 'Xeno', 3, 'desta.op', '2023-03-19 06:24:49'),
(301, 'Dhann', 1, 'dhani90900', '2023-03-19 06:25:14'),
(302, 'Dhann', 1, 'dhani90900', '2023-03-19 06:29:43'),
(303, 'Dhann', 0, 'dhani90900', '2023-03-19 06:30:19'),
(304, 'Razzel', 1, 'zaky2007', '2023-03-19 06:30:30'),
(305, 'Metthew', 0, 'Anjing231', '2023-03-19 06:32:56'),
(306, 'Dhann', 3, 'dhani90900', '2023-03-19 06:34:25'),
(307, 'Dhann', 3, 'dhani90900', '2023-03-19 06:35:10'),
(308, 'Dhann', 3, 'dhani90900', '2023-03-19 06:35:47'),
(309, 'Dhann', 3, 'dhani90900', '2023-03-19 06:36:25'),
(310, 'Dhann', 3, 'dhani90900', '2023-03-19 06:37:04'),
(311, 'Dhann', 3, 'dhani90900', '2023-03-19 06:37:57'),
(312, 'Dhann', 0, 'dhani90900', '2023-03-19 06:38:41'),
(313, 'Dhann', 0, 'dhani90900', '2023-03-19 06:39:52'),
(314, 'Deriss', 0, 'deris1212', '2023-03-19 06:40:53'),
(315, 'Firman', 1, 'gtasamp', '2023-03-19 06:43:17'),
(316, 'Ozann', 3, 'salahsattu', '2023-03-19 06:45:08'),
(317, 'Dhann', 2, 'dhani90900', '2023-03-19 06:48:43'),
(318, 'Dhann', 2, 'dhani90900', '2023-03-19 06:49:20'),
(319, 'Dhann', 2, 'dhani90900', '2023-03-19 06:50:01'),
(320, 'Dhann', 2, 'dhani90900', '2023-03-19 06:50:58'),
(321, 'Dhann', 2, 'dhani90900', '2023-03-19 06:51:37'),
(322, 'Deriss', 0, 'deris1212', '2023-03-19 06:52:09'),
(323, 'Dhann', 2, 'dhani90900', '2023-03-19 06:52:38'),
(324, 'Dhann', 2, 'dhani90900', '2023-03-19 06:53:12'),
(325, 'Dhann', 2, 'dhani90900', '2023-03-19 06:53:48'),
(326, 'Deriss', 0, 'deris1212', '2023-03-19 06:55:22'),
(327, 'Ozann', 1, 'salahsattu', '2023-03-19 07:19:19'),
(328, 'Dhann', 2, 'dhani90900', '2023-03-19 07:19:22'),
(329, 'Dhann', 0, 'dhani90900', '2023-03-19 07:21:31'),
(330, 'Metthew', 0, 'Anjing231', '2023-03-19 07:44:25'),
(331, 'Xeno', 1, 'desta.op', '2023-03-19 07:45:43'),
(332, 'Kucingmeow', 2, 'Anjing', '2023-03-19 07:47:38'),
(333, 'Xeno', 1, 'desta.op', '2023-03-19 08:01:22'),
(334, 'Xeno', 0, 'desta.op', '2023-03-19 08:04:55'),
(335, 'Razzel', 1, 'zaky2007', '2023-03-19 08:06:04'),
(336, 'deden', 3, 'rio123', '2023-03-19 08:06:28'),
(337, 'Kucingmeow', 2, 'Anjing', '2023-03-19 08:06:34'),
(338, 'heleh', 4, '111111', '2023-03-19 08:08:11'),
(339, 'Valconic', 5, 'Ari123', '2023-03-19 08:11:46'),
(340, 'Razzel', 1, 'zaky2007', '2023-03-19 08:12:56'),
(341, 'Xeno', 0, 'desta.op', '2023-03-19 08:16:53'),
(342, 'Valconic', 2, 'Ari123', '2023-03-19 08:20:04'),
(343, 'Kucingmeow', 4, 'Anjing', '2023-03-19 08:20:26'),
(344, 'Xeno', 0, 'desta.op', '2023-03-19 08:21:31'),
(345, 'Kucingmeow', 4, 'Anjing', '2023-03-19 08:22:36'),
(346, 'Deriss', 5, 'deris1212', '2023-03-19 08:24:10'),
(347, 'Steven', 6, 'azil74sddz', '2023-03-19 08:24:41'),
(348, 'Metthew', 7, 'Anjing231', '2023-03-19 08:25:56'),
(349, 'Razzel', 1, 'zaky2007', '2023-03-19 08:27:05'),
(350, 'Dhann', 3, 'dhani90900', '2023-03-19 08:35:51'),
(351, 'heleh', 3, '111111', '2023-03-19 08:37:15'),
(352, 'Xeno', 0, 'desta.op', '2023-03-19 08:43:15'),
(353, 'Steven', 8, 'azil74sddz', '2023-03-19 08:45:33'),
(354, 'Steven', 3, 'azil74sddz', '2023-03-19 08:47:34'),
(355, 'dhann', 8, 'dhani90900', '2023-03-19 08:47:50'),
(356, 'Nixon', 1, 'Hasa123', '2023-03-19 08:49:35'),
(357, 'Dhann', 3, 'dhani90900', '2023-03-19 08:52:36'),
(358, 'Valconic', 1, 'Ari123', '2023-03-19 08:54:37'),
(359, 'Dhann', 2, 'dhani90900', '2023-03-19 08:54:47'),
(360, 'Dhann', 2, 'dhani90900', '2023-03-19 08:56:33'),
(361, 'Dhann', 2, 'dhani90900', '2023-03-19 08:57:31'),
(362, 'Nixon', 2, 'Hasa123', '2023-03-19 08:58:25'),
(363, 'Alex', 4, 'Zawarudo123', '2023-03-19 09:01:08'),
(364, 'Ozann', 0, 'salahsattu', '2023-03-19 09:03:23'),
(365, 'Homage', 0, 'kepingg', '2023-03-19 09:05:49'),
(366, 'Deriss', 3, 'deris1212', '2023-03-19 09:06:44'),
(367, 'Hanz', 4, '311208', '2023-03-19 09:07:17'),
(368, 'Homage', 0, 'kepingg', '2023-03-19 09:27:01'),
(369, 'Revaldo', 5, 'REVALDO02', '2023-03-19 09:30:42'),
(370, 'ItsMeGabxAya', 0, 'labasotampan', '2023-03-19 09:31:44'),
(371, 'Homage', 2, 'kepingg', '2023-03-19 09:32:05'),
(372, 'Razzel', 6, 'zaky2007', '2023-03-19 09:33:16'),
(373, 'heleh', 8, '111111', '2023-03-19 09:34:51'),
(374, 'EgoHCRI', 6, 'EgoHCRI1701', '2023-03-19 09:39:02'),
(375, 'ItsMeGabxAya', 0, 'labasotampan', '2023-03-19 09:43:53'),
(376, 'Valconic', 1, 'Ari123', '2023-03-19 09:49:17'),
(377, 'Hanz', 2, '311208', '2023-03-19 09:52:40'),
(378, 'Ozann', 2, 'salahsattu', '2023-03-19 09:54:08'),
(379, 'Razzel', 3, 'zaky2007', '2023-03-19 09:54:22'),
(380, 'Mochyi', 4, 'kontol22', '2023-03-19 10:00:00'),
(381, 'Razzel', 3, 'zaky2007', '2023-03-19 10:01:36'),
(382, 'Valconic', 1, 'Ari123', '2023-03-19 10:02:55'),
(383, 'Zeee', 6, 'raflizeroz', '2023-03-19 10:04:47'),
(384, 'Revaldo', 5, 'REVALDO02', '2023-03-19 10:06:50'),
(385, 'Revaldo', 3, 'REVALDO02', '2023-03-19 10:08:02'),
(386, 'Vano', 5, '6693761', '2023-03-19 10:08:31'),
(387, 'Razzel', 7, 'zaky2007', '2023-03-19 10:09:58'),
(388, 'Valconic', 0, 'Ari123', '2023-03-19 10:12:01'),
(389, 'Razzel', 1, 'zaky2007', '2023-03-19 10:14:23'),
(390, 'Mochyi', 4, 'kontol22', '2023-03-19 10:16:49'),
(391, 'ItsMeGabxAya', 6, 'labasotampan', '2023-03-19 10:16:49'),
(392, 'EgoHCRI', 4, 'EgoHCRI1701', '2023-03-19 10:17:41'),
(393, 'Razzel', 1, 'zaky2007', '2023-03-19 10:19:28'),
(394, 'Razzel', 1, 'zaky2007', '2023-03-19 10:23:05'),
(395, 'Razzel', 1, 'zaky2007', '2023-03-19 10:33:20'),
(396, 'Homage', 3, 'kepingg', '2023-03-19 10:49:08'),
(397, 'Vano', 5, '6693761', '2023-03-19 10:49:27'),
(398, 'Opeet', 1, 'MangIscoUhuy', '2023-03-19 10:51:58'),
(399, 'Valconic', 0, 'Ari123', '2023-03-19 10:53:06'),
(400, 'Dhann', 0, 'dhani90900', '2023-03-19 10:53:55'),
(401, 'Opeet', 1, 'MangIscoUhuy', '2023-03-19 10:57:48'),
(402, 'Metthew', 5, 'Anjing231', '2023-03-19 10:59:00'),
(403, 'Valconic', 6, 'Ari123', '2023-03-19 10:59:34'),
(404, 'Opeet', 1, 'MangIscoUhuy', '2023-03-19 11:01:31'),
(405, 'Franklin', 2, 'Andikasetiawan', '2023-03-19 11:01:55'),
(406, 'Opeet', 0, 'MangIscoUhuy', '2023-03-19 11:37:09'),
(407, 'Valconic', 1, 'Ari123', '2023-03-19 11:37:23'),
(408, 'Metthew', 1, 'Anjing231', '2023-03-19 11:49:06'),
(409, 'Xeno', 1, 'desta.op', '2023-03-19 11:57:49'),
(410, 'Deriss', 0, 'deris1212', '2023-03-19 12:08:37'),
(411, 'Opeet', 1, 'MangIscoUhuy', '2023-03-19 12:09:15'),
(412, 'Valconic', 2, 'Ari123', '2023-03-19 12:14:20'),
(413, 'aluker', 3, 'ratachi', '2023-03-19 12:14:25'),
(414, 'heleh', 0, '111111', '2023-03-19 12:30:44'),
(415, 'Deriss', 1, 'deris1212', '2023-03-19 12:31:58'),
(416, 'Valconic', 2, 'Ari123', '2023-03-19 12:41:36'),
(417, 'heleh', 0, '111111', '2023-03-19 12:41:48'),
(418, 'Razzel', 3, 'zaky2007', '2023-03-19 12:42:23'),
(419, 'Reyhan', 4, 'Cahya12345', '2023-03-19 12:43:39'),
(420, 'Opeet', 1, 'MangIscoUhuy', '2023-03-19 12:44:08'),
(421, 'Metthew', 5, 'Anjing231', '2023-03-19 12:44:32'),
(422, 'Reyhan', 4, 'Cahya12345', '2023-03-19 12:45:18'),
(423, 'Dhann', 6, 'dhani90900', '2023-03-19 12:50:05'),
(424, 'ItsMeGabxAya', 7, 'labasotampan', '2023-03-19 12:51:07'),
(425, 'ItsMeGabxAya', 8, 'labasotampan', '2023-03-19 12:52:03'),
(426, 'Rabbty', 7, 'ugiganz', '2023-03-19 12:52:03'),
(427, 'EgoHCRI', 0, 'EgoHCRI1701', '2023-03-19 12:57:18'),
(428, 'Razzel', 3, 'zaky2007', '2023-03-19 12:59:56'),
(429, 'Deriss', 4, 'deris1212', '2023-03-19 13:07:53'),
(430, 'Revaldo', 9, 'REVALDO02', '2023-03-19 13:08:27'),
(431, 'Opeet', 1, 'MangIscoUhuy', '2023-03-19 13:08:40'),
(432, 'Hanz', 10, '311208', '2023-03-19 13:12:50'),
(433, 'Rabbty', 7, 'ugiganz', '2023-03-19 13:15:50'),
(434, 'Deriss', 4, 'deris1212', '2023-03-19 13:17:38'),
(435, 'DikZz', 11, 'Dikssrr4', '2023-03-19 13:18:31'),
(436, 'Dhann', 6, 'dhani90900', '2023-03-19 13:20:51'),
(437, 'Alex', 0, 'Zawarudo123', '2023-03-19 13:24:29'),
(438, 'EgoHCRI', 3, 'EgoHCRI1701', '2023-03-19 13:25:26'),
(439, 'Opeet', 0, 'MangIscoUhuy', '2023-03-19 13:31:01'),
(440, 'Opeet', 0, 'MangIscoUhuy', '2023-03-19 13:31:42'),
(441, 'Metthew', 4, 'Anjing231', '2023-03-19 13:32:36'),
(442, 'Razzel', 5, 'zaky2007', '2023-03-19 13:33:12'),
(443, 'Deriss', 1, 'deris1212', '2023-03-19 13:40:17'),
(444, 'Matheww', 3, 'julio1928', '2023-03-19 13:44:48'),
(445, 'Opeet', 1, 'MangIscoUhuy', '2023-03-19 13:46:18'),
(446, 'Rahmat', 6, 'Jangan', '2023-03-19 13:47:59'),
(447, 'Morgan', 0, 'ERWINN', '2023-03-19 13:49:17'),
(448, 'Alex', 7, 'Zawarudo123', '2023-03-19 13:51:55'),
(449, 'Dhann', 8, 'dhani90900', '2023-03-19 13:55:25'),
(450, 'Alex', 0, 'Zawarudo123', '2023-03-19 13:59:53'),
(451, 'Deriss', 7, 'deris1212', '2023-03-19 14:00:13'),
(452, 'Alex', 0, 'Zawarudo123', '2023-03-19 14:01:41'),
(453, 'Metthew', 4, 'Anjing231', '2023-03-19 14:07:17'),
(454, 'EgoHCRI', 1, 'EgoHCRI1701', '2023-03-19 14:10:51'),
(455, 'Alex', 0, 'Zawarudo123', '2023-03-19 14:14:58'),
(456, 'Razzel', 6, 'zaky2007', '2023-03-19 14:16:35'),
(457, 'Deriss', 2, 'deris1212', '2023-03-19 14:16:38'),
(458, 'Valconic', 7, 'Ari123', '2023-03-19 14:17:32'),
(459, 'Opeet', 0, 'MangIscoUhuy', '2023-03-19 14:18:17'),
(460, 'Rahmat', 8, 'Jangan', '2023-03-19 14:18:58'),
(461, 'Alex', 5, 'Zawarudo123', '2023-03-19 14:19:53'),
(462, 'Dhann', 9, 'dhani90900', '2023-03-19 14:19:56'),
(463, 'Arif', 0, 'jaenal', '2023-03-19 14:24:06'),
(464, 'ibet', 0, 'ibet16', '2023-03-19 14:32:04'),
(465, 'EgoHCRI', 1, 'EgoHCRI1701', '2023-03-19 14:33:47'),
(466, 'Deriss', 3, 'deris1212', '2023-03-19 14:36:27'),
(467, 'Nico', 9, 'asu.kabeh', '2023-03-19 14:39:00'),
(468, 'Revaldo', 6, 'REVALDO02', '2023-03-19 14:39:17'),
(469, 'Alex', 5, 'Zawarudo123', '2023-03-19 14:41:02'),
(470, 'Xieee', 11, 'INDONESIA', '2023-03-19 14:41:16'),
(471, 'Xeno', 2, 'desta.op', '2023-03-19 14:42:33'),
(472, 'Rabbty', 10, 'ugiganz', '2023-03-19 14:43:01'),
(473, 'EgoHCRI', 1, 'EgoHCRI1701', '2023-03-19 14:43:28'),
(474, 'Arif', 9, 'jaenal', '2023-03-19 14:44:41'),
(475, 'EgoHCRI', 1, 'EgoHCRI1701', '2023-03-19 14:45:59'),
(476, 'Kucingmeow', 12, 'Anjing', '2023-03-19 14:46:31'),
(477, 'Nico', 3, 'asu.kabeh', '2023-03-19 14:47:28'),
(478, 'Deriss', 12, 'deris1212', '2023-03-19 14:48:11'),
(479, 'Kucingmeow', 5, 'Anjing', '2023-03-19 14:49:33'),
(480, 'Nico', 3, 'asu.kabeh', '2023-03-19 14:52:23'),
(481, 'Revaldo', 6, 'REVALDO02', '2023-03-19 14:54:39'),
(482, 'Metthew', 4, 'Anjing231', '2023-03-19 14:55:32'),
(483, 'Arif', 1, 'jaenal', '2023-03-19 14:57:02'),
(484, 'Revaldo', 6, 'REVALDO02', '2023-03-19 14:57:25'),
(485, 'Alex', 13, 'Zawarudo123', '2023-03-19 14:59:13'),
(486, 'Valconic', 7, 'Ari123', '2023-03-19 15:01:41'),
(487, 'Padil', 9, '110706', '2023-03-19 15:01:57'),
(488, 'DikZz', 0, 'Dikssrr4', '2023-03-19 15:03:43'),
(489, 'Revaldo', 3, 'REVALDO02', '2023-03-19 15:03:56'),
(490, 'Alex', 11, 'Zawarudo123', '2023-03-19 15:04:08'),
(491, 'ibet', 0, 'ibet16', '2023-03-19 15:05:02'),
(492, 'Rabbty', 10, 'ugiganz', '2023-03-19 15:05:54'),
(493, 'Revaldo', 3, 'REVALDO02', '2023-03-19 15:08:35'),
(494, 'Baby', 0, 'onepiece', '2023-03-19 15:09:30'),
(495, 'Rabbty', 5, 'ugiganz', '2023-03-19 15:10:40'),
(496, 'Dhann', 6, 'dhani90900', '2023-03-19 15:11:14'),
(497, 'heleh', 10, '111111', '2023-03-19 15:13:53'),
(498, 'Alex', 0, 'Zawarudo123', '2023-03-19 15:16:34'),
(499, 'Opeet', 7, 'MangIscoUhuy', '2023-03-19 15:16:39'),
(500, 'Alex', 0, 'Zawarudo123', '2023-03-19 15:25:00'),
(501, 'Arif', 0, 'jaenal', '2023-03-19 15:29:26'),
(502, 'Alex', 1, 'Zawarudo123', '2023-03-19 15:34:26'),
(503, 'Rahmat', 7, 'Jangan', '2023-03-19 15:36:53'),
(504, 'Kucingmeow', 8, 'Anjing', '2023-03-19 15:37:19'),
(505, 'Valconic', 6, 'Ari123', '2023-03-19 15:39:29'),
(506, 'Valconic', 6, 'Ari123', '2023-03-19 15:41:25'),
(507, 'Rahmat', 7, 'Jangan', '2023-03-19 15:42:05'),
(508, 'Rahmat', 0, 'Jangan', '2023-03-19 15:56:47'),
(509, 'Xieee', 1, 'INDONESIA', '2023-03-19 16:03:03'),
(510, 'Valconic', 3, 'Ari123', '2023-03-19 16:03:30'),
(511, 'Valconic', 3, 'Ari123', '2023-03-19 16:04:28'),
(512, 'Reyhan', 4, 'Cahya12345', '2023-03-19 16:05:46'),
(513, 'Valconic', 3, 'Ari123', '2023-03-19 16:06:08'),
(514, 'Valconic', 3, 'Ari123', '2023-03-19 16:08:48'),
(515, 'Rahmat', 5, 'Jangan', '2023-03-19 16:13:26'),
(516, 'Rabbty', 0, 'ugiganz', '2023-03-19 16:13:40'),
(517, 'John', 6, 'YANUFARHAN', '2023-03-19 16:14:05'),
(518, 'Padil', 7, '110706', '2023-03-19 16:14:16'),
(519, 'Deriss', 4, 'deris1212', '2023-03-19 16:17:07'),
(520, 'Deriss', 4, 'deris1212', '2023-03-19 16:18:55'),
(521, 'Alex', 1, 'Zawarudo123', '2023-03-19 16:19:47'),
(522, 'Valconic', 5, 'Ari123', '2023-03-19 16:23:04'),
(523, 'Adit', 3, 'setankredit321', '2023-03-19 16:26:25'),
(524, 'Revaldo', 8, 'REVALDO02', '2023-03-19 16:28:15'),
(525, 'Adit', 3, 'setankredit321', '2023-03-19 16:28:29'),
(526, 'Adit', 0, 'setankredit321', '2023-03-19 16:36:30'),
(527, 'Adit', 0, 'setankredit321', '2023-03-19 16:38:15'),
(528, 'heleh', 3, '111111', '2023-03-19 16:40:12'),
(529, 'Abah', 1, 'Gioo1607', '2023-03-19 16:42:24'),
(530, 'Deriss', 3, 'deris1212', '2023-03-19 16:54:22'),
(531, 'Padil', 4, '110706', '2023-03-19 17:00:47'),
(532, 'Ipannn', 1, 'Makan123', '2023-03-19 17:03:06'),
(533, 'Deriss', 7, 'deris1212', '2023-03-19 17:03:12'),
(534, 'PrasPatron', 3, 'Prassetya', '2023-03-19 17:07:35'),
(535, 'Deriss', 7, 'deris1212', '2023-03-19 17:08:35'),
(536, 'John', 3, 'YANUFARHAN', '2023-03-19 17:15:20'),
(537, 'Deriss', 6, 'deris1212', '2023-03-19 17:22:18'),
(538, 'bumbles', 1, 'kaka1231558', '2023-03-19 17:37:26'),
(539, 'PrasPatron', 1, 'Prassetya', '2023-03-19 17:42:48'),
(540, 'Alex', 6, 'Zawarudo123', '2023-03-19 17:48:47'),
(541, 'Ipannn', 7, 'Makan123', '2023-03-19 17:50:18'),
(542, 'Franklin', 8, 'Andikasetiawan', '2023-03-19 17:52:29'),
(543, 'Ipannn', 7, 'Makan123', '2023-03-19 17:54:30'),
(544, 'Monely', 6, 'angga6666', '2023-03-19 17:58:32'),
(545, 'Deriss', 1, 'deris1212', '2023-03-19 18:11:26'),
(546, 'Dom', 1, 'andra908', '2023-03-19 18:24:49'),
(547, 'Channn', 6, 'chan14', '2023-03-19 18:30:18'),
(548, 'Rabbty', 7, 'ugiganz', '2023-03-19 18:32:54'),
(549, 'Rabbty', 7, 'ugiganz', '2023-03-19 18:34:02'),
(550, 'Rabbty', 7, 'ugiganz', '2023-03-19 18:38:25'),
(551, 'BobAustin', 8, 'rifky25', '2023-03-19 18:39:48'),
(552, 'John', 3, 'YANUFARHAN', '2023-03-19 18:41:59'),
(553, 'Channn', 3, 'chan14', '2023-03-19 18:46:57'),
(554, 'Rabbty', 1, 'ugiganz', '2023-03-19 18:52:23'),
(555, 'Channn', 3, 'chan14', '2023-03-19 18:59:54'),
(556, 'Aril', 0, 'Riyan12345', '2023-03-19 20:12:42'),
(557, 'Aril', 0, 'Riyan12345', '2023-03-19 20:16:57'),
(558, 'John', 1, 'YANUFARHAN', '2023-03-19 20:18:51'),
(559, 'Dennn', 0, '19022003', '2023-03-19 21:21:06'),
(560, 'Albet', 1, 'hutapea9', '2023-03-19 21:22:25'),
(561, 'Albet', 1, 'hutapea9', '2023-03-19 21:35:55'),
(562, 'Dennn', 0, '19022003', '2023-03-19 22:01:28'),
(563, 'Ozann', 1, 'salahsattu', '2023-03-19 22:09:18'),
(564, 'Dhann', 1, 'dhani90900', '2023-03-19 22:32:30'),
(565, 'Dhann', 1, 'dhani90900', '2023-03-19 22:36:25'),
(566, 'EgoHCRI', 2, 'EgoHCRI1701', '2023-03-19 22:38:20'),
(567, 'Dennn', 0, '19022003', '2023-03-19 22:43:47'),
(568, 'Rabbty', 2, 'ugiganz', '2023-03-19 22:57:41'),
(569, 'Dhann', 1, 'dhani90900', '2023-03-19 23:01:11'),
(570, 'Dhann', 0, 'dhani90900', '2023-03-19 23:07:25'),
(571, 'Dennn', 1, '19022003', '2023-03-19 23:07:57'),
(572, 'Dhann', 0, 'dhani90900', '2023-03-19 23:09:14'),
(573, 'Dhann', 0, 'dhani90900', '2023-03-19 23:13:26'),
(574, 'Alex', 2, 'Zawarudo123', '2023-03-19 23:24:11'),
(575, 'Dhann', 0, 'dhani90900', '2023-03-19 23:24:18'),
(576, 'Dhann', 0, 'dhani90900', '2023-03-19 23:26:14'),
(577, 'Hanz', 0, '311208', '2023-03-19 23:31:52'),
(578, 'ibet', 0, 'ibet16', '2023-03-19 23:48:48'),
(579, 'Forte', 2, 'bandung77', '2023-03-19 23:52:40'),
(580, 'Dhann', 3, 'dhani90900', '2023-03-19 23:56:06'),
(581, 'Forte', 0, 'bandung77', '2023-03-20 00:03:38'),
(582, 'Dhann', 2, 'dhani90900', '2023-03-20 00:04:00'),
(583, 'Alex', 0, 'Zawarudo123', '2023-03-20 00:09:35'),
(584, 'ibet', 0, 'ibet16', '2023-03-20 00:21:24'),
(585, 'Dhann', 0, 'dhani90900', '2023-03-20 01:57:21'),
(586, 'Dennn', 1, '19022003', '2023-03-20 02:35:50'),
(587, 'Deriss', 2, 'deris1212', '2023-03-20 02:36:03'),
(588, 'Rahmat', 2, 'Jangan', '2023-03-20 02:39:39'),
(589, 'bumbles', 3, 'kaka1231558', '2023-03-20 02:42:53'),
(590, 'Xeno', 4, 'desta.op', '2023-03-20 02:44:05'),
(591, 'Deriss', 5, 'deris1212', '2023-03-20 02:47:30'),
(592, 'Dhann', 0, 'dhani90900', '2023-03-20 02:48:39'),
(593, 'Andrew', 2, 'badung980', '2023-03-20 03:04:07'),
(594, 'Alex', 3, 'Zawarudo123', '2023-03-20 03:07:32'),
(595, 'Dennn', 1, '19022003', '2023-03-20 03:10:14'),
(596, 'ibet', 3, 'ibet16', '2023-03-20 03:12:10'),
(597, 'heleh', 4, '111111', '2023-03-20 03:14:16'),
(598, 'ibet', 5, 'ibet16', '2023-03-20 03:16:45'),
(599, 'heleh', 0, '111111', '2023-03-20 03:40:47'),
(600, 'heleh', 0, '111111', '2023-03-20 04:06:31'),
(601, 'ibet', 1, 'ibet16', '2023-03-20 04:07:28'),
(602, 'Alex', 2, 'Zawarudo123', '2023-03-20 04:09:15'),
(603, 'Andrew', 3, 'badung980', '2023-03-20 04:09:48'),
(604, 'Dhann', 4, 'dhani90900', '2023-03-20 04:11:42'),
(605, 'Xeno', 5, 'desta.op', '2023-03-20 04:13:27'),
(606, 'Dhann', 4, 'dhani90900', '2023-03-20 04:13:37'),
(607, 'EgoHCRI', 6, 'EgoHCRI1701', '2023-03-20 04:13:55'),
(608, 'ibet', 0, 'ibet16', '2023-03-20 04:28:12'),
(609, 'Deriss', 1, 'deris1212', '2023-03-20 04:30:06'),
(610, 'ibet', 0, 'ibet16', '2023-03-20 04:31:46'),
(611, 'ibet', 0, 'ibet16', '2023-03-20 04:33:15'),
(612, 'heleh', 1, '111111', '2023-03-20 04:43:26'),
(613, 'Xeno', 2, 'desta.op', '2023-03-20 04:44:58'),
(614, 'heleh', 0, '111111', '2023-03-20 04:53:12'),
(615, 'heleh', 0, '111111', '2023-03-20 04:54:19');

-- --------------------------------------------------------

--
-- Table structure for table `logpay`
--

CREATE TABLE `logpay` (
  `player` varchar(40) NOT NULL DEFAULT 'None',
  `playerid` int(11) NOT NULL DEFAULT 0,
  `toplayer` varchar(40) NOT NULL DEFAULT 'None',
  `toplayerid` int(11) NOT NULL DEFAULT 0,
  `ammount` int(11) NOT NULL DEFAULT 0,
  `time` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `logpay`
--

INSERT INTO `logpay` (`player`, `playerid`, `toplayer`, `toplayerid`, `ammount`, `time`) VALUES
('Andika_Toretto', 32, 'Matthew_Zan', 23, 500, 1679231061),
('Yamaguchi_Valdis', 13, 'Valconic_Luxury', 26, 100, 1679231109),
('Yamaguchi_Valdis', 13, 'Matthew_Zan', 23, 100, 1679231117),
('Yamaguchi_Valdis', 13, 'Hanz_Einer', 18, 500000, 1679234748),
('Dominic_Eduardo', 25, 'Matthew_Zan', 23, 1000, 1679238221),
('Revaldo_Adnan', 14, 'Arif_Houston', 49, 50, 1679240385),
('Ipan_Hendry', 59, 'Fadhil_Ramadhan', 55, 2000, 1679246802);

-- --------------------------------------------------------

--
-- Table structure for table `logstaff`
--

CREATE TABLE `logstaff` (
  `command` varchar(50) NOT NULL,
  `admin` varchar(50) NOT NULL,
  `adminid` int(11) NOT NULL,
  `player` varchar(50) NOT NULL DEFAULT '*',
  `playerid` int(11) NOT NULL DEFAULT -1,
  `str` varchar(50) NOT NULL DEFAULT '*',
  `time` bigint(20) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `logstaff`
--

INSERT INTO `logstaff` (`command`, `admin`, `adminid`, `player`, `playerid`, `str`, `time`) VALUES
('SETMONEY', 'Jhono_Sujhono(RIINNKUNTIID)', 1, 'Jhono_Sujhono', 1, '9999999', 1652788603),
('SETMONEY', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1000000', 1652789444),
('SETADMINLEVEL', 'Jhono_Sujhono(None)', 1, 'Todoki_Karuzawa', 4, '3', 1652791141),
('SETMONEY', 'Jhono_Sujhono(Jhono)', 1, 'Jhono_Sujhono', 1, '99999', 1652791373),
('SETMONEY', 'Jhono_Sujhono(None)', 1, 'Jhono_Sujhono', 1, '100000', 1652791790),
('SETADMINLEVEL', 'Jhono_Sujhono(None)', 1, 'Lovic_Hug', 5, '4', 1652791921),
('SETADMINLEVEL', 'Jhono_Sujhono(None)', 1, 'Asep_Sumadi', 6, '4', 1652791941),
('SETADMINLEVEL', 'Jhono_Sujhono(None)', 1, 'Kanjut_Badag', 7, '4', 1652791952),
('SETADMINLEVEL', 'Jhono_Sujhono(JHONO)', 1, 'Licht_Dvat', 8, '3', 1652811350),
('SETMONEY', 'Asep_Sumadi(None)', 6, 'Asep_Sumadi', 6, '10000', 1652811807),
('SETMONEY', 'Asep_Sumadi(None)', 6, 'Asep_Sumadi', 6, '10000', 1652811835),
('SETMONEY', 'Asep_Sumadi(None)', 6, 'Asep_Sumadi', 6, '100000', 1652811841),
('SETADMINLEVEL', 'Jhono_Sujhono(JHONO)', 1, 'Asep_Sumadi', 6, '4', 1652811908),
('SETADMINLEVEL', 'Jhono_Sujhono(JHONO)', 1, 'Asep_Sumadi', 6, '5', 1652811969),
('SETADMINLEVEL', 'Jhono_Sujhono(JHONO)', 1, 'Licht_Dvat', 8, '5', 1652811985),
('SETMONEY', 'Jhono_Sujhono(JHONO)', 1, 'Lovic_Hug', 5, '1000000', 1652812110),
('SETMONEY', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '100000', 1652812127),
('SETADMINLEVEL', 'Jhono_Sujhono(JHONO)', 1, 'Lovic_Hug', 5, '5', 1652812935),
('SETADMINLEVEL', 'Jhono_Sujhono(JHONO)', 1, 'Lovic_Hug', 5, '6', 1652812943),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(13 rank)', 1652815171),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(1 rank)', 1652815209),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(2 rank)', 1652815229),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(3 rank)', 1652815242),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(4 rank)', 1652815260),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(5 rank)', 1652815281),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(6 rank)', 1652815294),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(7 rank)', 1652815307),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(1 rank)', 1652815380),
('SETFACTION', 'Asep_Sumadi(None)', 6, 'Asep_Sumadi', 6, '1(13 rank)', 1652815392),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(2 rank)', 1652815412),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(3 rank)', 1652815420),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(4 rank)', 1652815427),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(4 rank)', 1652815436),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(5 rank)', 1652815439),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '2(1 rank)', 1652815440),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(6 rank)', 1652815446),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(7 rank)', 1652815454),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(9 rank)', 1652815465),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '2(2 rank)', 1652815469),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(8 rank)', 1652815472),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '2(3 rank)', 1652815477),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(10 rank)', 1652815479),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(11 rank)', 1652815489),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '2(4 rank)', 1652815492),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(12 rank)', 1652815497),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(13 rank)', 1652815507),
('SETLEADER', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3', 1652816744),
('SETMONEY', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '1000', 1652829599),
('SETBOOSTER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '(1 days)', 1652829643),
('SETBOOSTER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '(0 days)', 1652829648),
('SETVIP', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '3(0 days)', 1652829655),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '2', 1652830017),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '1', 1653376795),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '0', 1653378615),
('SETVIP', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '3(0 days)', 1653424768),
('SETGOLD', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '1000', 1653648472),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '1', 1653717527),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '2', 1653717574),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '3', 1653717577),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '2', 1653723301),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '5', 1653744722),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '3', 1653746553),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '2', 1653746561),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '1', 1653746742),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '2', 1653746779),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '3', 1653746786),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '4', 1653746826),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '5', 1653746876),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '5', 1653747482),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '5', 1653747823),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '0', 1653759863),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '5', 1653788031),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '2', 1653812664),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '3', 1653826266),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '2', 1653826437),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '0', 1653838965),
('SETMONEY', 'Jhono_Sujhono(RIINNKUNTIID)', 1, 'Jhono_Sujhono', 1, '9999999', 1652788603),
('SETMONEY', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1000000', 1652789444),
('SETADMINLEVEL', 'Jhono_Sujhono(None)', 1, 'Todoki_Karuzawa', 4, '3', 1652791141),
('SETMONEY', 'Jhono_Sujhono(Jhono)', 1, 'Jhono_Sujhono', 1, '99999', 1652791373),
('SETMONEY', 'Jhono_Sujhono(None)', 1, 'Jhono_Sujhono', 1, '100000', 1652791790),
('SETADMINLEVEL', 'Jhono_Sujhono(None)', 1, 'Lovic_Hug', 5, '4', 1652791921),
('SETADMINLEVEL', 'Jhono_Sujhono(None)', 1, 'Asep_Sumadi', 6, '4', 1652791941),
('SETADMINLEVEL', 'Jhono_Sujhono(None)', 1, 'Kanjut_Badag', 7, '4', 1652791952),
('SETADMINLEVEL', 'Jhono_Sujhono(JHONO)', 1, 'Licht_Dvat', 8, '3', 1652811350),
('SETMONEY', 'Asep_Sumadi(None)', 6, 'Asep_Sumadi', 6, '10000', 1652811807),
('SETMONEY', 'Asep_Sumadi(None)', 6, 'Asep_Sumadi', 6, '10000', 1652811835),
('SETMONEY', 'Asep_Sumadi(None)', 6, 'Asep_Sumadi', 6, '100000', 1652811841),
('SETADMINLEVEL', 'Jhono_Sujhono(JHONO)', 1, 'Asep_Sumadi', 6, '4', 1652811908),
('SETADMINLEVEL', 'Jhono_Sujhono(JHONO)', 1, 'Asep_Sumadi', 6, '5', 1652811969),
('SETADMINLEVEL', 'Jhono_Sujhono(JHONO)', 1, 'Licht_Dvat', 8, '5', 1652811985),
('SETMONEY', 'Jhono_Sujhono(JHONO)', 1, 'Lovic_Hug', 5, '1000000', 1652812110),
('SETMONEY', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '100000', 1652812127),
('SETADMINLEVEL', 'Jhono_Sujhono(JHONO)', 1, 'Lovic_Hug', 5, '5', 1652812935),
('SETADMINLEVEL', 'Jhono_Sujhono(JHONO)', 1, 'Lovic_Hug', 5, '6', 1652812943),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(13 rank)', 1652815171),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(1 rank)', 1652815209),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(2 rank)', 1652815229),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(3 rank)', 1652815242),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(4 rank)', 1652815260),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(5 rank)', 1652815281),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(6 rank)', 1652815294),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '1(7 rank)', 1652815307),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(1 rank)', 1652815380),
('SETFACTION', 'Asep_Sumadi(None)', 6, 'Asep_Sumadi', 6, '1(13 rank)', 1652815392),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(2 rank)', 1652815412),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(3 rank)', 1652815420),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(4 rank)', 1652815427),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(4 rank)', 1652815436),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(5 rank)', 1652815439),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '2(1 rank)', 1652815440),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(6 rank)', 1652815446),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(7 rank)', 1652815454),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(9 rank)', 1652815465),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '2(2 rank)', 1652815469),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(8 rank)', 1652815472),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '2(3 rank)', 1652815477),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(10 rank)', 1652815479),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(11 rank)', 1652815489),
('SETFACTION', 'Jhono_Sujhono(JHONO)', 1, 'Jhono_Sujhono', 1, '2(4 rank)', 1652815492),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(12 rank)', 1652815497),
('SETFACTION', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3(13 rank)', 1652815507),
('SETLEADER', 'Licht_Dvat(Rihito)', 8, 'Licht_Dvat', 8, '3', 1652816744),
('SETMONEY', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '1000', 1652829599),
('SETBOOSTER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '(1 days)', 1652829643),
('SETBOOSTER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '(0 days)', 1652829648),
('SETVIP', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '3(0 days)', 1652829655),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '2', 1652830017),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '1', 1653376795),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '0', 1653378615),
('SETVIP', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '3(0 days)', 1653424768),
('SETGOLD', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '1000', 1653648472),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '1', 1653717527),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '2', 1653717574),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '3', 1653717577),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '2', 1653723301),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '5', 1653744722),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '3', 1653746553),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '2', 1653746561),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '1', 1653746742),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '2', 1653746779),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '3', 1653746786),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '4', 1653746826),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '5', 1653746876),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '5', 1653747482),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '5', 1653747823),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '0', 1653759863),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '5', 1653788031),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '2', 1653812664),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '3', 1653826266),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '2', 1653826437),
('SETLEADER', 'Clairo_Stevano(clairo)', 2, 'Clairo_Stevano', 2, '0', 1653838965),
('SETLEADER', 'Emmilia_Charlotte(Knt)', 1, 'Emmilia_Charlotte', 1, '1', 1654212369),
('SETADMINLEVEL', 'Emmilia_Charlotte(Knt)', 1, 'Jhono_Yoo', 3, '6', 1654212713),
('SETADMINLEVEL', 'Emmilia_Charlotte(Knt)', 1, 'Jhono_Yoo', 3, '6', 1654213041),
('GIVEMONEY', 'Emmilia_Charlotte(Knt)', 1, 'Emmilia_Charlotte', 1, '1000', 1654466841),
('SETMONEY', 'Emmilia_Charlotte(Knt)', 1, 'Emmilia_Charlotte', 1, '100000', 1654469028),
('SETADMINLEVEL', 'Emmilia_Charlotte(Knt)', 1, 'Emmilia_Charlotte', 1, '7', 1654473625),
('SETADMINLEVEL', 'Emmilia_Charlotte(Knt)', 1, 'Emmilia_Charlotte', 1, '8', 1654473648),
('SETLEADER', 'Emmilia_Charlotte(Knt)', 1, 'Jhono_Yoo', 3, '1', 1654630870),
('SETADMINLEVEL', 'Emmilia_Charlotte(Knt)', 1, 'Jhono_Yoo', 3, '8', 1654630890),
('SETADMINLEVEL', 'Emmilia_Charlotte(Knt)', 1, 'Jhono_Yoo', 3, '7', 1654630904),
('SETMONEY', 'Jhono_Yoo(None)', 3, 'Jhono_Yoo', 3, '100000', 1654896358),
('SETLEADER', 'Jhono_Yoo(None)', 3, 'Jhono_Yoo', 3, '5', 1654896481),
('SETLEADER', 'Emmilia_Charlotte(Knt)', 1, 'Emmilia_Charlotte', 1, '5', 1654897129),
('SETADMINLEVEL', 'Kiyux_Saja(HELEH)', 12, 'Yamaguchi_Valdis', 13, '5', 1679197070),
('SETADMINLEVEL', 'Kiyux_Saja(HELEH)', 12, 'Yamaguchi_Valdis', 13, '7', 1679197693),
('SETMONEY', 'Yamaguchi_Valdis(None)', 13, 'Yamaguchi_Valdis', 13, '1000000000', 1679197892),
('SETMONEY', 'Yamaguchi_Valdis(None)', 13, 'Yamaguchi_Valdis', 13, '1410065408', 1679199403),
('SETADMINLEVEL', 'Kiyux_Saja(HELEH)', 12, 'Xeno_Oconner', 20, '7', 1679213319),
('SETMONEY', 'Xeno_Oconner(None)', 20, 'Dominic_Eduardo', 25, '1000000', 1679213585),
('SETMONEY', 'Xeno_Oconner(None)', 20, 'Xeno_Oconner', 20, '100000', 1679214741),
('SETVIP', 'Kiyux_Saja(HELEH)', 12, 'Kiyux_Saja', 12, '3(1 days)', 1679215337),
('SETADMINLEVEL', 'Kiyux_Saja(HELEH)', 12, 'Andika_Toretto', 32, '5', 1679218904),
('GIVEMONEY', 'Kiyux_Saja(HELEH)', 12, 'Andika_Toretto', 32, '100000', 1679219876),
('SETADMINLEVEL', 'Kiyux_Saja(HELEH)', 12, 'Elcapano_Salvadore', 15, '7', 1679219952),
('SETMONEY', 'Elcapano_Salvadore(Razzel)', 15, 'Elcapano_Salvadore', 15, '500000', 1679219985),
('SETLEADER', 'Andika_Toretto(ItsMeGabxAya)', 32, 'Andika_Toretto', 32, '2', 1679221142),
('SETADMINLEVEL', 'Yamaguchi_Valdis(Valdis)', 13, 'Franklin_Roosevelt', 39, '5', 1679223812),
('SETADMINLEVEL', 'Yamaguchi_Valdis(Valdis)', 13, 'Franklin_Roosevelt', 39, '4', 1679223818),
('SETLEADER', 'Xeno_Oconner(None)', 20, 'Xeno_Oconner', 20, '2', 1679227651),
('SETLEADER', 'Xeno_Oconner(None)', 20, 'Xeno_Oconner', 20, '3', 1679227654),
('SETLEADER', 'Xeno_Oconner(None)', 20, 'Xeno_Oconner', 20, '2', 1679227661),
('SETLEADER', 'Andika_Toretto(ItsMeGabxAya)', 32, 'Andika_Toretto', 32, '5', 1679230362),
('SETFACTION', 'Yamaguchi_Valdis(Valdis)', 13, 'Matthew_Zan', 23, '1(1 rank)', 1679230484),
('SETFACTION', 'Yamaguchi_Valdis(Valdis)', 13, 'Andika_Toretto', 32, '4(13 rank)', 1679230557),
('SETLEADER', 'Andika_Toretto(ItsMeGabxAya)', 32, 'Andika_Toretto', 32, '5', 1679230601),
('SETLEADER', 'Yamaguchi_Valdis(Valdis)', 13, 'Andika_Toretto', 32, '4', 1679230616),
('SETFACTION', 'Yamaguchi_Valdis(Valdis)', 13, 'Andika_Toretto', 32, '4(13 rank)', 1679230641),
('SETFACTION', 'Yamaguchi_Valdis(Valdis)', 13, 'Andika_Toretto', 32, '5(13 rank)', 1679230672),
('SETLEADER', 'Yamaguchi_Valdis(Valdis)', 13, 'Andika_Toretto', 32, '5', 1679230684),
('SETFACTION', 'Yamaguchi_Valdis(Valdis)', 13, 'Andika_Toretto', 32, '5(13 rank)', 1679230706),
('SETLEADER', 'Yamaguchi_Valdis(Valdis)', 13, 'Andika_Toretto', 32, '5', 1679230710),
('SETFACTION', 'Yamaguchi_Valdis(Valdis)', 13, 'Andika_Toretto', 32, '5(13 rank)', 1679230719),
('SETMONEY', 'Yamaguchi_Valdis(Valdis)', 13, 'Andika_Toretto', 32, '1000000', 1679231084),
('SETLEADER', 'Andika_Toretto(ItsMeGabxAya)', 32, 'Andika_Toretto', 32, '2', 1679231204),
('SETFACTION', 'Yamaguchi_Valdis(Valdis)', 13, 'Andika_Toretto', 32, '2(13 rank)', 1679231216),
('SETLEADER', 'Yamaguchi_Valdis(Valdis)', 13, 'Andika_Toretto', 32, '2', 1679231240),
('SETLEADER', 'Yamaguchi_Valdis(Valdis)', 13, 'Hanz_Einer', 18, '1', 1679231662),
('SETFACTION', 'Yamaguchi_Valdis(Valdis)', 13, 'Matthew_Zan', 23, '1(4 rank)', 1679232400),
('SETLEADER', 'Yamaguchi_Valdis(Valdis)', 13, 'Alex_Toretto', 21, '4', 1679234206),
('SETLEADER', 'Elcapano_Salvadore(Razzel)', 15, 'Elcapano_Salvadore', 15, '2', 1679235528),
('SETMONEY', 'Elcapano_Salvadore(Razzel)', 15, 'Elcapano_Salvadore', 15, '10000000', 1679235721),
('SETLEADER', 'Kiyux_Saja(HELEH)', 12, 'Kiyux_Saja', 12, '1', 1679244053),
('SETLEADER', 'Kiyux_Saja(HELEH)', 12, 'Kiyux_Saja', 12, '3', 1679244293),
('SETLEADER', 'Yamaguchi_Valdis(Valdis)', 13, 'Yamaguchi_Valdis', 13, '2', 1679265471),
('SETLEADER', 'Yamaguchi_Valdis(Valdis)', 13, 'Yamaguchi_Valdis', 13, '0', 1679266631),
('SETLEADER', 'Yamaguchi_Valdis(Valdis)', 13, 'Yamaguchi_Valdis', 13, '5', 1679267772),
('SETLEADER', 'Yamaguchi_Valdis(Valdis)', 13, 'Yamaguchi_Valdis', 13, '0', 1679267850),
('SETFACTION', 'Yamaguchi_Valdis(Valdis)', 13, 'Yamaguchi_Valdis', 13, '4(13 rank)', 1679268472),
('SETLEADER', 'Yamaguchi_Valdis(Valdis)', 13, 'Yamaguchi_Valdis', 13, '2', 1679270228),
('SETLEADER', 'Yamaguchi_Valdis(Valdis)', 13, 'Yamaguchi_Valdis', 13, '0', 1679270276),
('SETADMINLEVEL', 'Xeno_Oconner(None)', 20, 'Gabriel_Zelensky', 62, '7', 1679280309),
('SETMONEY', 'Yamaguchi_Valdis(Valdis)', 13, 'Yamaguchi_Valdis', 13, '10000000', 1679281404),
('SETMONEY', 'Yamaguchi_Valdis(Valdis)', 13, 'Yamaguchi_Valdis', 13, '10000000', 1679281435);

-- --------------------------------------------------------

--
-- Table structure for table `object`
--

CREATE TABLE `object` (
  `id` int(11) NOT NULL,
  `posx` float NOT NULL,
  `posy` float NOT NULL,
  `posz` float NOT NULL,
  `posrx` float NOT NULL,
  `posry` float NOT NULL,
  `posrz` float NOT NULL,
  `interior` int(11) NOT NULL DEFAULT 0,
  `world` int(11) NOT NULL DEFAULT 0,
  `object` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ores`
--

CREATE TABLE `ores` (
  `id` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT 0,
  `posx` float DEFAULT 0,
  `posy` float DEFAULT 0,
  `posz` float DEFAULT 0,
  `posrx` float DEFAULT 0,
  `posry` float DEFAULT 0,
  `posrz` float DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ores`
--

INSERT INTO `ores` (`id`, `type`, `posx`, `posy`, `posz`, `posrx`, `posry`, `posrz`) VALUES
(0, 0, 464.381, 866.534, -28.387, 0, 0, 0),
(1, 1, 555.939, 928.367, -43.5709, 0, 0, 0),
(2, 0, 613.141, 865.3, -43.5509, 0, 0, 0),
(3, 1, 637.747, 831.97, -43.6309, 0, 0, 0),
(4, 0, 671.772, 927.05, -41.4543, 0, 0, 0),
(5, 0, 652.36, 738.067, -11.904, 0, 0, 0),
(6, 1, 640.83, 731.161, -2.64683, 0, 0, 0),
(7, 1, 500.121, 781.126, -21.9991, 0, 0, 0),
(8, 0, 488.845, 785.109, -22.3256, 0, 0, 0),
(9, 1, 685.946, 820.716, -28.3049, 0, 0, 0),
(10, 0, 562.108, 982.26, -7.96277, 0, 0, 0),
(11, 0, 535.467, 909.043, -43.4109, 0, 0, 0),
(12, 0, 539.144, 882.115, -36.6565, 0, 0, 0),
(13, 1, 461.884, 884.778, -28.8179, 0, 0, 0),
(14, 1, 698.502, 841.609, -28.2711, 0, 0, 0),
(15, 1, 487.904, 800.007, -22.22, 0, 0, 0),
(16, 0, 546.501, 824.598, -29.9684, 0, 0, 0),
(17, 1, 576.64, 805.685, -29.4404, 0, 0, 0),
(18, 1, 554.326, 786.207, -19.1056, 0, 0, 0),
(19, 1, 709.745, 921.678, -19.4611, 0, 0, 0),
(20, 0, 714.078, 913.618, -19.2864, 0, 0, 0),
(21, 1, 744.818, 776.606, -8.06283, 0, 0, 0),
(22, 0, 600.437, 932.102, -41.5237, 0, 0, 0),
(23, 0, 597.532, 829.781, -43.959, 0, 0, 0),
(24, 1, 540.974, 842.47, -42.1793, 0, 0, 0),
(25, 1, 696.797, 844.561, -28.9438, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `parks`
--

CREATE TABLE `parks` (
  `id` int(11) DEFAULT 0,
  `posx` float DEFAULT 0,
  `posy` float DEFAULT 0,
  `posz` float DEFAULT 0,
  `interior` int(11) DEFAULT 0,
  `world` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `parks`
--

INSERT INTO `parks` (`id`, `posx`, `posy`, `posz`, `interior`, `world`) VALUES
(0, 2115.4, -1776.52, 13.3912, 0, 0),
(1, 1320.01, -863.615, 39.5781, 0, 0),
(2, 1090.48, -1237.86, 15.8203, 0, 0),
(4, 1365.84, -1648.96, 13.3828, 0, 0),
(3, 1019.95, -1438.36, 13.5546, 0, 0),
(6, 1213.47, -1102.48, 24.6954, 0, 0),
(5, 2249.87, 28.194, 26.1204, 0, 0),
(0, 2115.4, -1776.52, 13.3912, 0, 0),
(1, 1320.01, -863.615, 39.5781, 0, 0),
(2, 1090.48, -1237.86, 15.8203, 0, 0),
(4, 1365.84, -1648.96, 13.3828, 0, 0),
(3, 1019.95, -1438.36, 13.5546, 0, 0),
(6, 1213.47, -1102.48, 24.6954, 0, 0),
(5, 2249.87, 28.194, 26.1204, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `plants`
--

CREATE TABLE `plants` (
  `id` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT 0,
  `time` int(11) NOT NULL DEFAULT 0,
  `posx` float NOT NULL DEFAULT 0,
  `posy` float NOT NULL DEFAULT 0,
  `posz` float NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `reg_id` int(10) UNSIGNED NOT NULL,
  `username` varchar(24) NOT NULL DEFAULT '',
  `ucp` varchar(22) NOT NULL,
  `adminname` varchar(24) NOT NULL DEFAULT 'None',
  `twittername` varchar(64) NOT NULL DEFAULT 'None',
  `ip` varchar(24) NOT NULL DEFAULT '',
  `email` varchar(40) NOT NULL DEFAULT 'None',
  `characterstory` int(11) NOT NULL DEFAULT 0,
  `admin` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `helper` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `servermod` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `eventmod` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `factionmod` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `familymod` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `level` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `levelup` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `vip` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `vip_time` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `gold` int(11) NOT NULL DEFAULT 0,
  `reg_date` varchar(30) NOT NULL DEFAULT '',
  `last_login` varchar(30) NOT NULL DEFAULT '',
  `money` int(11) NOT NULL DEFAULT 0,
  `redmoney` int(11) NOT NULL DEFAULT 0,
  `bmoney` int(11) NOT NULL DEFAULT 0,
  `brek` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `starterpack` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `phone` mediumint(8) UNSIGNED NOT NULL,
  `phonestatus` int(11) NOT NULL DEFAULT 0,
  `phonekuota` int(11) NOT NULL DEFAULT 0,
  `phonecredit` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `phonebook` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `twitter` int(11) NOT NULL DEFAULT 0,
  `twitterstatus` int(11) NOT NULL DEFAULT 0,
  `wt` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `hours` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `minutes` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `seconds` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `paycheck` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `skin` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `facskin` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `gender` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `age` varchar(30) NOT NULL DEFAULT '',
  `indoor` mediumint(9) NOT NULL DEFAULT -1,
  `inbiz` mediumint(9) NOT NULL DEFAULT -1,
  `inhouse` mediumint(9) NOT NULL DEFAULT -1,
  `infamily` mediumint(9) NOT NULL DEFAULT -1,
  `posx` float NOT NULL DEFAULT 0,
  `posy` float NOT NULL DEFAULT 0,
  `posz` float NOT NULL DEFAULT 0,
  `posa` float NOT NULL DEFAULT 0,
  `interior` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `world` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `health` float NOT NULL DEFAULT 100,
  `armour` float NOT NULL DEFAULT 0,
  `hunger` smallint(6) NOT NULL DEFAULT 100,
  `bladder` smallint(6) NOT NULL DEFAULT 100,
  `energy` smallint(6) NOT NULL DEFAULT 100,
  `sick` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `hospital` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `injured` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `duty` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `dutytime` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `faction` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `factionrank` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `factionlead` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `family` tinyint(4) NOT NULL DEFAULT -1,
  `familyrank` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `jail` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `jail_time` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `arrest` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `arrest_time` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `suspect` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `suspect_time` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ask_time` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `warn` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `job` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `job2` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `jobtime` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sidejobtime` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sidejob_mowertime` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sidejob_bustime` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sidejob_forkliftertime` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sidejob_sweepertime` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `exitjob` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxitime` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `robtime` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `myricous` mediumint(9) NOT NULL DEFAULT 0,
  `medicine` mediumint(9) NOT NULL DEFAULT 0,
  `medkit` mediumint(9) NOT NULL DEFAULT 0,
  `mask` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `helmet` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `snack` mediumint(9) NOT NULL DEFAULT 0,
  `sprunk` mediumint(9) NOT NULL DEFAULT 0,
  `gas` mediumint(9) NOT NULL DEFAULT 0,
  `bandage` mediumint(9) NOT NULL DEFAULT 0,
  `gps` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `material` mediumint(9) NOT NULL DEFAULT 0,
  `component` mediumint(9) NOT NULL DEFAULT 0,
  `food` mediumint(9) NOT NULL DEFAULT 0,
  `seed` mediumint(9) NOT NULL DEFAULT 0,
  `potato` mediumint(9) NOT NULL DEFAULT 0,
  `wheat` mediumint(9) NOT NULL DEFAULT 0,
  `orange` mediumint(9) NOT NULL DEFAULT 0,
  `price1` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `price2` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `price3` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `price4` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `marijuana` mediumint(9) NOT NULL DEFAULT 0,
  `plant` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `plant_time` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `fishtool` tinyint(4) NOT NULL DEFAULT 0,
  `fish` mediumint(9) NOT NULL DEFAULT 0,
  `worm` mediumint(9) NOT NULL DEFAULT 0,
  `idcard` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `idcard_time` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `drivelic` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `drivelic_time` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `weaponlic` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `weaponlic_time` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `hbemode` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `togpm` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `toglog` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `togads` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `togwt` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `Gun1` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun2` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun3` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun4` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun5` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun6` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun7` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun8` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun9` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun10` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun11` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun12` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun13` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo1` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo2` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo3` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo4` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo5` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo6` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo7` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo8` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo9` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo10` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo11` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo12` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo13` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `kepala` int(11) NOT NULL DEFAULT 0,
  `perut` int(11) NOT NULL DEFAULT 0,
  `lengankiri` int(11) NOT NULL DEFAULT 0,
  `lengankanan` int(11) NOT NULL DEFAULT 0,
  `kakikiri` int(11) NOT NULL DEFAULT 0,
  `kakikanan` int(11) NOT NULL DEFAULT 0,
  `kurir` int(11) NOT NULL DEFAULT 0,
  `sparepart` int(11) DEFAULT 0,
  `senter` int(11) NOT NULL DEFAULT 0,
  `booster` tinyint(3) NOT NULL DEFAULT 0,
  `boosttime` bigint(20) NOT NULL DEFAULT 0,
  `ayamhidup` mediumint(8) DEFAULT 0,
  `ayampotong` mediumint(8) NOT NULL DEFAULT 0,
  `ayamfillet` mediumint(8) NOT NULL DEFAULT 0,
  `lockpick` mediumint(8) NOT NULL DEFAULT 0,
  `robbiztime` int(11) NOT NULL DEFAULT 0,
  `robbanktime` int(11) NOT NULL DEFAULT 0,
  `robatmtime` int(11) NOT NULL DEFAULT 0,
  `paketborax` int(11) NOT NULL DEFAULT 0,
  `borax` mediumint(8) NOT NULL DEFAULT 0,
  `bpjs` tinyint(3) NOT NULL DEFAULT 0,
  `bpjs_time` bigint(20) NOT NULL DEFAULT 0,
  `penebang` tinyint(3) NOT NULL DEFAULT 0,
  `penebang_time` bigint(20) NOT NULL DEFAULT 0,
  `skck` tinyint(3) NOT NULL DEFAULT 0,
  `skck_time` bigint(20) NOT NULL DEFAULT 0,
  `licbiz` tinyint(3) NOT NULL DEFAULT 0,
  `licbiz_time` bigint(20) NOT NULL DEFAULT 0,
  `crack` mediumint(8) NOT NULL DEFAULT 0,
  `susu` mediumint(9) NOT NULL DEFAULT 0,
  `nasi` mediumint(9) NOT NULL DEFAULT 0,
  `burger` mediumint(9) NOT NULL DEFAULT 0,
  `kebab` mediumint(9) NOT NULL DEFAULT 0,
  `tikettol` int(11) NOT NULL DEFAULT 0,
  `divisi` int(11) NOT NULL,
  `aGoreng` int(11) NOT NULL,
  `menikah` varchar(25) NOT NULL DEFAULT 'None'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`reg_id`, `username`, `ucp`, `adminname`, `twittername`, `ip`, `email`, `characterstory`, `admin`, `helper`, `servermod`, `eventmod`, `factionmod`, `familymod`, `level`, `levelup`, `vip`, `vip_time`, `gold`, `reg_date`, `last_login`, `money`, `redmoney`, `bmoney`, `brek`, `starterpack`, `phone`, `phonestatus`, `phonekuota`, `phonecredit`, `phonebook`, `twitter`, `twitterstatus`, `wt`, `hours`, `minutes`, `seconds`, `paycheck`, `skin`, `facskin`, `gender`, `age`, `indoor`, `inbiz`, `inhouse`, `infamily`, `posx`, `posy`, `posz`, `posa`, `interior`, `world`, `health`, `armour`, `hunger`, `bladder`, `energy`, `sick`, `hospital`, `injured`, `duty`, `dutytime`, `faction`, `factionrank`, `factionlead`, `family`, `familyrank`, `jail`, `jail_time`, `arrest`, `arrest_time`, `suspect`, `suspect_time`, `ask_time`, `warn`, `job`, `job2`, `jobtime`, `sidejobtime`, `sidejob_mowertime`, `sidejob_bustime`, `sidejob_forkliftertime`, `sidejob_sweepertime`, `exitjob`, `taxitime`, `robtime`, `myricous`, `medicine`, `medkit`, `mask`, `helmet`, `snack`, `sprunk`, `gas`, `bandage`, `gps`, `material`, `component`, `food`, `seed`, `potato`, `wheat`, `orange`, `price1`, `price2`, `price3`, `price4`, `marijuana`, `plant`, `plant_time`, `fishtool`, `fish`, `worm`, `idcard`, `idcard_time`, `drivelic`, `drivelic_time`, `weaponlic`, `weaponlic_time`, `hbemode`, `togpm`, `toglog`, `togads`, `togwt`, `Gun1`, `Gun2`, `Gun3`, `Gun4`, `Gun5`, `Gun6`, `Gun7`, `Gun8`, `Gun9`, `Gun10`, `Gun11`, `Gun12`, `Gun13`, `Ammo1`, `Ammo2`, `Ammo3`, `Ammo4`, `Ammo5`, `Ammo6`, `Ammo7`, `Ammo8`, `Ammo9`, `Ammo10`, `Ammo11`, `Ammo12`, `Ammo13`, `kepala`, `perut`, `lengankiri`, `lengankanan`, `kakikiri`, `kakikanan`, `kurir`, `sparepart`, `senter`, `booster`, `boosttime`, `ayamhidup`, `ayampotong`, `ayamfillet`, `lockpick`, `robbiztime`, `robbanktime`, `robatmtime`, `paketborax`, `borax`, `bpjs`, `bpjs_time`, `penebang`, `penebang_time`, `skck`, `skck_time`, `licbiz`, `licbiz_time`, `crack`, `susu`, `nasi`, `burger`, `kebab`, `tikettol`, `divisi`, `aGoreng`, `menikah`) VALUES
(1, 'Emmilia_Charlotte', 'Arch', 'Knt', '', '255.255.255.255', 'None', 0, 6, 0, 0, 0, 0, 0, 100, 5, 0, 0, 0, '2022-06-03 04:51:09', '2022-07-07 15:39:07', 100000, 0, 200, 662149, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 13, 10, 18790, 240, 0, 2, '24/09/1996', -1, -1, -1, -1, 798.051, -1368.59, 13.3934, 351.905, 0, 0, 50, 0, 84, 100, 82, 0, 0, 0, 0, 0, 5, 13, 5, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 94, 98, 94, 84, 96, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 68, 0, 0, 'Jhono Yoo'),
(2, 'Alexandro_Desilva', 'Test', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2022-06-03 06:30:22', '2022-06-03 06:33:33', 250, 0, 200, 360229, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 56, 176, 299, 0, 1, '24/09/1992', -1, -1, -1, -1, 1759.81, -1855.6, 13.7141, 290.582, 0, 0, 97, 0, 99, 100, 99, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(3, 'Jhono_Yoo', 'Jhono', 'None', '', '36.81.186.169', 'None', 0, 6, 0, 0, 0, 0, 0, 5, 2, 0, 0, 0, '2022-06-03 06:30:28', '2022-06-11 04:52:08', 97000, 0, 200, 566664, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 31, 7351, 299, 0, 1, '20/12/1998', -1, 3, -1, -1, 1228.97, -1427.36, 13.8588, 222.667, 0, 0, 100, 0, 58, 100, 37, 0, 0, 0, 0, 0, 5, 13, 5, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 10, 9, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 59, 0, 0, 0, 0, 0, 0, 0, 100, 97, 100, 100, 97, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 15, 'Emmilia Charlotte'),
(4, 'Isac_Guillen', 'Isac', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2022-06-03 06:31:15', '2022-06-06 04:15:17', 250, 0, 200, 803017, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23, 45, 1425, 6, 0, 1, '16/03/1999', -1, -1, -1, -1, 1136.68, -1716.59, 13.9753, 331.154, 0, 0, 100, 0, 93, 100, 90, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 33, 0, 0, 0, 0, 0, 0, 0, 60, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(8, 'Andre_Kurniawan', 'Andre', 'Andre', '', '120.188.86.160', 'None', 0, 6, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2022-07-16 16:41:35', '2022-07-16 21:19:06', 1215, 0, 200, 476338, 1, 4851, 0, 0, 0, 0, 0, 0, 0, 0, 20, 27, 1227, 288, 0, 1, '10/09/2002', -1, -1, -1, -1, 1481.76, -1745.31, 13.8469, 3.87601, 0, 0, 95, 0, 94, 100, 93, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(9, 'Kenneth_William', 'ken', 'KenWilBoy', '', '120.188.87.91', 'None', 0, 8, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, '2022-09-22 23:38:40', '2022-09-23 01:28:03', 690, 0, 200, 270308, 1, 3648, 1, 9962000, 18, 1, 1, 0, 0, 1, 6, 20, 3980, 181, 0, 1, '23/12/2001', -1, -1, -1, -1, 1768.59, -1854.61, 20.7425, 238.04, 0, 0, 98, 0, 76, 100, 69, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(10, 'Aldi_Rizal', 'Aldi147', 'None', '', '255.255.255.255', 'aldirizalhermawan@gmail.com', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2022-09-23 00:32:02', '2022-09-23 01:30:10', 910, 0, 200, 265796, 1, 5426, 1, 10000000, 20, 1, 0, 0, 1, 0, 54, 23, 3263, 299, 0, 1, '08 08 2007', -1, -1, -1, -1, 1764.15, -1859.99, 13.8793, 46.5603, 0, 0, 50, 0, 49, 100, 48, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(11, 'Emmanuel_Benjamin', 'Nuel', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2022-09-23 00:33:15', '2022-09-23 01:30:00', 1100, 0, 200, 608477, 1, 9204, 1, 20000000, 40, 1, 0, 0, 1, 0, 53, 33, 3213, 7, 0, 1, '25/01/2000', -1, -1, -1, -1, 1762.96, -1856.58, 14.0837, 266.787, 0, 0, 98, 0, 80, 100, 75, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(12, 'Kiyux_Saja', 'heleh', 'HELEH', '', '36.90.61.110', 'None', 0, 8, 0, 0, 0, 0, 0, 1, 2, 3, 1679301737, 0, '2023-03-19 03:03:03', '2023-03-20 04:55:56', 10140, 0, 200, 855673, 1, 4963, 0, 10000000, 40, 1, 0, 0, 1, 2, 20, 23, 8423, 1, 0, 1, '20/02/2002', -1, -1, -1, -1, 1642.34, -2316.77, 13.6852, 269.252, 0, 0, 70, 0, 52, 100, 36, 0, 0, 0, 0, 0, 3, 13, 3, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(13, 'Yamaguchi_Valdis', 'Dhann', 'Valdis', '', '255.255.255.255', 'None', 0, 7, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, '2023-03-19 03:36:46', '2023-03-20 04:13:12', 9996500, 0, 1819598952, 289073, 0, 2258, 1, 11962000, 14, 1, 1, 0, 1, 5, 3, 37, 18217, 2, 295, 1, '08/10/2005', -1, -1, -1, -1, 960.318, -1830.78, 12.9007, 150.657, 0, 0, 98, 0, 90, 100, 67, 0, 0, 0, 0, 1235, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681823443, 1, 1681790134, 1, 1681789906, 1, 0, 0, 0, 0, 0, 8, 24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 203, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 90, 100, 90, 96, 93, 93, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1680566256, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(14, 'Revaldo_Adnan', 'Revaldo', 'None', '', '118.96.233.172', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, '2023-03-19 05:20:28', '2023-03-19 17:16:59', 975, 0, 1390, 766494, 1, 9539, 1, 9962000, 17, 1, 1, 0, 1, 3, 43, 44, 6088, 100, 0, 1, '02/07/2008', -1, -1, -1, -1, 915.635, -1294.22, 13.9107, 117.969, 0, 0, 50, 0, 42, 100, 9, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 1679266843, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 1, 120, 490, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681813389, 1, 1681810404, 1, 1681810277, 1, 0, 0, 0, 0, 1, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 6, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(15, 'Elcapano_Salvadore', 'Razzel', 'Razzel', '', '114.10.26.174', 'None', 0, 7, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, '2023-03-19 05:28:07', '2023-03-19 14:25:55', 9990000, 0, 200, 424696, 1, 8349, 0, 0, 0, 0, 0, 0, 0, 2, 51, 6, 10266, 170, 0, 1, '09/09/2000', 3, -1, -1, -1, -2063.23, 2659.37, 1499.58, 358.826, 5, 0, 50, 0, 43, 100, 40, 0, 0, 0, 0, 0, 2, 13, 2, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 1679253501, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681822648, 1, 1681822135, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 93, 100, 92, 95, 91, 93, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1680531564, 0, 0, 0, 0, 0, 49, 0, 0, 'None'),
(16, 'Firman_Parker', 'Firman', 'None', '', '116.206.30.54', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 05:37:59', '2023-03-19 06:58:07', 10252, 0, 200, 298809, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, 37, 1057, 2, 0, 1, '24/04/2000', 13, -1, -1, -1, -2691.26, 797.032, 1501.27, 285.362, 5, 5, 100, 0, 95, 100, 92, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(17, 'Ozann_Kimmy', 'Ozann', 'None', '', '125.166.124.116', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 05:38:21', '2023-03-19 22:18:10', 10165, 0, 200, 534701, 1, 7950, 1, 0, 0, 0, 0, 0, 0, 0, 26, 58, 1618, 5, 0, 1, '15/05/2005', -1, -1, -1, -1, 1821.39, -1609.16, 13.1844, 277.686, 0, 0, 98, 0, 92, 100, 90, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(18, 'Hanz_Einer', 'Hanz', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 3, 2, 0, 0, 0, '2023-03-19 05:41:18', '2023-03-19 23:33:52', 464815, 0, 200, 166599, 1, 5921, 1, 39962000, 20, 1, 1, 0, 0, 2, 44, 43, 9883, 2, 283, 1, '31/12/1993', -1, -1, -1, -1, 1553.38, -1674.9, 16.4953, 74.1772, 0, 0, 68, 97, 38, 100, 22, 0, 0, 0, 1, 4464, 1, 13, 1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681809123, 1, 1681828173, 1, 1681828271, 1, 0, 0, 0, 0, 1, 0, 0, 0, 29, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 200, 0, 0, 0, 0, 0, 0, 0, 0, 100, 96, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(19, 'Deris_Rustandi', 'Deriss', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 2, 5, 0, 0, 0, '2023-03-19 05:41:59', '2023-03-20 04:31:04', 7625, 0, 290, 588301, 1, 8606, 1, 19924000, 20, 0, 1, 0, 0, 6, 10, 2, 14966, 29, 0, 1, '27/12/2000', -1, 2, -1, -1, 1395.38, -1590.81, 13.6553, 239.161, 0, 2, 154, 0, 39, 100, 36, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1679302209, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681809148, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 95, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(20, 'Xeno_Oconner', 'Xeno', 'None', '', '103.184.50.102', 'None', 0, 8, 0, 0, 0, 0, 0, 2, 6, 0, 0, 0, '2023-03-19 05:50:27', '2023-03-20 04:33:43', 50000, 0, 200, 133132, 1, 8410, 0, 10000000, 0, 0, 0, 0, 0, 7, 11, 30, 22290, 22, 0, 1, '12/12/2000', -1, -1, -1, -1, 1831.93, -1846.62, 13.8781, 13.336, 0, 0, 91, 0, 0, 100, 0, 1, 0, 0, 0, 0, 2, 13, 2, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(21, 'Alex_Toretto', 'Alex', 'None', '', '103.145.181.154', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, '2023-03-19 05:52:27', '2023-03-20 04:13:35', 10150, 0, 0, 340932, 1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 12, 57, 7977, 100, 187, 1, '22/12/2005', -1, -1, -1, -1, 963.386, -1826.49, 13.6199, 335.796, 0, 0, 95, 97, 34, 100, 28, 0, 0, 0, 1, 1345, 4, 13, 4, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 43, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 600, 0, 0, 0, 100, 94, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(22, 'Yusuf_Rakax', 'Rakax', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 06:02:30', '2023-03-19 06:04:49', 250, 0, 200, 352230, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 19, 139, 2, 0, 1, '11/06/2001', -1, -1, -1, -1, 2361.65, -37.8971, 26.7844, 226.874, 0, 0, 100, 0, 100, 100, 99, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(23, 'Matthew_Zan', 'Metthew', 'None', '', '140.213.45.11', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, '2023-03-19 06:11:51', '2023-03-19 15:50:30', 1060, 0, 690, 225016, 0, 3355, 1, 10000000, 20, 0, 0, 0, 1, 4, 21, 29, 4459, 299, 300, 1, '11/12/2007', 0, -1, -1, -1, 111.623, 1066.9, -48.6141, 253.619, 5, 5, 58, 67, 1, 100, 0, 1, 0, 0, 1, 4459, 1, 4, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681798882, 1, 1681827719, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 29, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 175, 0, 0, 0, 0, 0, 0, 0, 0, 100, 97, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(24, 'Lil_Dominic', 'deden', 'None', '', '140.213.51.195', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 06:57:14', '2023-03-19 08:31:22', 9545, 0, 200, 756406, 1, 7539, 0, 0, 20, 1, 0, 0, 1, 0, 27, 29, 1649, 107, 0, 1, '05/06/2000', 0, -1, -1, -1, 105.051, 1070.27, -48.6141, 52.2112, 5, 5, 98, 0, 91, 100, 87, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(25, 'Dominic_Eduardo', 'Kucingmeow', 'None', '', '180.241.145.185', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, '2023-03-19 07:44:42', '2023-03-19 15:37:39', 998160, 0, 200, 717680, 1, 5595, 1, 10000000, 0, 0, 0, 0, 1, 1, 15, 18, 4518, 2, 0, 1, '11/10/2000', -1, -1, 80, -1, 1320.86, -883, 40.1781, 147.777, 0, 0, 88, 0, 73, 100, 66, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681807228, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 99, 99, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(26, 'Valconic_Luxury', 'Valconic', 'None', '', '120.188.6.90', 'None', 1, 0, 0, 0, 0, 0, 0, 2, 8, 0, 0, 0, '2023-03-19 08:00:09', '2023-03-19 18:45:39', 53366, 0, 2700, 928488, 1, 7008, 0, 10000000, 20, 1, 0, 0, 0, 9, 28, 22, 10281, 2, 0, 1, '15/08/1997', -1, -1, -1, -1, 1329.02, -1092.16, 27.63, 175.742, 0, 0, 45, 90, 44, 100, 43, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 1679263282, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 91, 0, 0, 0, 0, 0, 1, 1681807096, 1, 1681809547, 1, 1681809387, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 98, 92, 99, 99, 91, 0, 0, 0, 0, 0, 4, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 59, 0, 0, 'None'),
(27, 'Steven_Oconor', 'Steven', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 08:23:25', '2023-03-19 08:46:57', 10110, 0, 200, 137382, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 53, 953, 2, 0, 1, '08/02/2000', -1, -1, -1, -1, 455.753, 1157.91, 8.67385, 324.497, 0, 0, 100, 0, 95, 100, 93, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 1679236612, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681806519, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(28, 'Morgan_Kece', 'Nixon', 'None', '', '36.72.119.211', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 08:47:12', '2023-03-19 09:16:41', 9840, 0, 200, 464902, 1, 7245, 1, 10000000, 20, 1, 0, 0, 0, 0, 19, 25, 1165, 3, 0, 1, '2/4/1997', -1, -1, -1, -1, 1804.73, -1891.91, 13.7074, 210.56, 0, 0, 93, 0, 93, 100, 91, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681808412, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(29, 'Brian_Oconor', 'Steven', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 08:47:43', '2023-03-19 08:50:41', 10200, 0, 200, 432130, 1, 7158, 0, 10000000, 0, 0, 0, 0, 0, 0, 2, 58, 178, 299, 0, 1, '08/03/2000', -1, -1, -1, -1, 1527.97, -1706.38, 13.4627, 296.992, 0, 0, 100, 0, 99, 100, 99, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(30, 'AbdLah_Hasa', 'Nixon', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 08:49:51', '2023-03-19 08:52:41', 10250, 0, 200, 258684, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 50, 170, 1, 0, 1, '2/4/1997', -1, -1, -1, -1, 1682.74, -1859.92, 13.4771, 103.902, 0, 0, 100, 0, 99, 100, 99, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(31, 'Slamet_Netral', 'Homage', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, '2023-03-19 09:01:04', '2023-03-19 11:21:35', 3385, 0, 334, 404584, 1, 4778, 0, 10000000, 0, 1, 0, 0, 0, 1, 6, 33, 334, 299, 0, 1, '12/07/2005', -1, -1, -1, -1, 43.172, -1530.24, 5.6692, 187.074, 0, 0, 60, 0, 77, 100, 69, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1679240087, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681809138, 1, 1681810163, 0, 0, 1, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 85, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 'None'),
(32, 'Andika_Toretto', 'ItsMeGabxAya', 'ItsMeGabxAya', '', '125.162.211.163', 'None', 1, 5, 0, 0, 0, 0, 0, 10, 1, 0, 0, 0, '2023-03-19 09:28:14', '2023-03-19 13:29:15', 499950, 0, 500200, 136848, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 43, 16, 6196, 2, 295, 1, '01/01/1997', -1, -1, -1, -1, 1048.94, -1386.49, 13.9056, 30, 0, 0, 100, 98, 62, 100, 51, 0, 0, 0, 0, 746, 2, 13, 2, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681812526, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 29, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 195, 0, 0, 0, 0, 0, 0, 0, 0, 100, 85, 98, 99, 99, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(33, 'Ego_Syahroni', 'EgoHCRI', 'None', '', '103.144.175.135', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, '2023-03-19 09:35:00', '2023-03-20 04:27:13', 5450, 0, 520, 625896, 1, 4679, 0, 10000000, 0, 1, 0, 0, 0, 2, 56, 54, 831, 299, 0, 1, '17/01/1996', -1, -1, -1, -1, 1031.87, -1454.35, 13.8546, 336.22, 0, 0, 85, 0, 34, 100, 30, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681816450, 1, 1681814344, 1, 1681813875, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 97, 88, 86, 100, 100, 97, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(34, 'Mochy_Sugoi', 'Mochyi', 'None', '', '114.5.248.46', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 09:57:34', '2023-03-19 10:09:43', 10145, 0, 200, 124623, 1, 4601, 1, 9962000, 20, 1, 1, 0, 1, 0, 9, 49, 589, 299, 0, 1, '01/10/1989', -1, -1, -1, -1, 1715.73, -1591.68, 13.4404, 16.4195, 0, 0, 100, 0, 97, 100, 96, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(35, 'Jaze_Razerr', 'Zeee', 'None', '', '116.206.12.59', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 10:01:50', '2023-03-19 10:10:55', 10155, 0, 200, 763004, 1, 4006, 0, 0, 20, 0, 0, 0, 1, 0, 8, 0, 480, 2, 0, 1, '30/12/2000', -1, -1, -1, -1, 1844.43, -1870.98, 13.6828, 67.8174, 0, 0, 100, 0, 98, 100, 97, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(36, 'Alfredo_Distevano', 'Vano', 'None', '', '180.251.119.207', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 10:05:03', '2023-03-19 10:57:23', 9150, 0, 200, 310401, 1, 9150, 0, 10000000, 0, 0, 0, 0, 0, 0, 50, 26, 3026, 2, 0, 1, '21/08/2005', 13, -1, -1, -1, -2692.98, 797.025, 1501.27, 81.3121, 5, 5, 100, 0, 81, 100, 76, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681812850, 1, 1681813284, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(37, 'Opeet_Smith', 'Opeet', 'None', '', '140.213.13.135', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 10:49:16', '2023-03-19 10:57:26', 10150, 0, 200, 526289, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 37, 457, 2, 0, 1, '09/08/1998', -1, -1, -1, -1, 1628.16, -1736.81, 13.6828, 1.32913, 0, 0, 88, 0, 98, 100, 97, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681815219, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(38, 'Muhamad_Reyhan', 'Reyhan', 'None', '', '182.4.102.134', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 10:53:23', '2023-03-19 16:12:23', 5500, 0, 200, 135356, 1, 1412, 0, 10000000, 0, 0, 0, 0, 0, 0, 21, 43, 1303, 100, 0, 1, '28/02/2001', -1, -1, -1, -1, 1749.02, -1860.34, 13.8777, 348.591, 0, 0, 100, 0, 93, 100, 91, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681822357, 1, 1681822034, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(39, 'Franklin_Roosevelt', 'Franklin', 'franklin', '', '255.255.255.255', 'None', 0, 4, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 10:57:47', '2023-03-19 18:10:44', 9551, 0, 200, 973588, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 8, 1928, 299, 0, 1, '07/01/2000', -1, -1, -1, -1, 1833.2, -1683.1, 13.7823, 114.015, 0, 0, 90, 0, 88, 100, 85, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681841370, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(40, 'Isco_Smith', 'Opeet', 'None', '', '140.213.11.239', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, '2023-03-19 10:58:00', '2023-03-19 15:28:53', 8810, 0, 200, 245288, 1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 18, 2, 8282, 2, 0, 1, '09/08/1998', -1, -1, -1, -1, 1904.18, -1793.4, 13.8547, 27.1767, 0, 0, 94, 0, 51, 100, 19, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1679261047, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681816014, 1, 1681822130, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(41, 'Michael_Cellyn', 'aluker', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 12:10:40', '2023-03-19 12:20:26', 0, 0, 300, 120263, 0, 7021, 1, 10000000, 40, 0, 0, 0, 1, 0, 8, 35, 515, 2, 0, 1, '05/10/2000', 13, -1, -1, -1, -2670.79, 788.932, 1501.27, 197.859, 5, 5, 91, 0, 98, 100, 97, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681819965, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 97, 100, 96, 99, 96, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(45, 'Matheww_Zee', 'Matheww', 'None', '', '182.2.132.116', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 13:41:28', '2023-03-19 14:26:48', 9415, 0, 200, 468047, 1, 7361, 0, 0, 0, 0, 0, 0, 0, 0, 44, 32, 2672, 2, 0, 1, '26/07/1999', -1, -1, -1, -1, 2673.57, -1786.21, 12.1438, 200.71, 0, 0, 100, 0, 84, 100, 78, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681825782, 1, 1681827144, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(42, 'Rabbty_Olimpus', 'Rabbty', 'None', '', '140.213.134.98', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, '2023-03-19 12:47:48', '2023-03-19 23:19:00', 5999, 0, 200, 578116, 1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 33, 48, 9228, 100, 0, 1, '7/5/2001', -1, -1, -1, -1, 1390.59, -1871.41, 13.6828, 224.29, 0, 0, 77, 0, 42, 100, 18, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681822697, 1, 1681831022, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(43, 'Dario_Antonio', 'DikZz', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 13:14:13', '2023-03-19 15:04:18', 9535, 0, 200, 205517, 1, 3093, 1, 10000000, 18, 1, 0, 0, 0, 0, 38, 58, 2338, 2, 0, 1, '31/07/1998', -1, -1, -1, -1, 356.835, 965.659, 28.3082, 269.105, 0, 0, 159, 0, 86, 100, 67, 0, 0, 1, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 100, 0, 0, 0, 0, 0, 1679254591, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681824065, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 100, 98, 95, 97, 95, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(44, 'Andrew_Smith', 'Andrew', 'None', '', '112.215.219.184', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 13:32:59', '2023-03-20 04:34:23', 10060, 0, 200, 892416, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 47, 30, 2850, 6, 0, 1, '12/09/1987', -1, -1, -1, -1, 1489.6, -1733.55, 13.4679, 91.5307, 0, 0, 100, 0, 83, 100, 77, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1679303680, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681873875, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(46, 'Clario_Michael', 'Rahmat', 'None', '', '140.213.17.140', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, '2023-03-19 13:45:08', '2023-03-20 02:52:35', 9265, 0, 0, 379835, 1, 9845, 1, 11962000, 14, 1, 1, 0, 1, 2, 19, 32, 8372, 299, 0, 1, '23/03/2000', -1, -1, -1, -1, 1436.21, -1625.2, 13.5169, 64.4236, 0, 0, 50, 0, 39, 100, 36, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681826677, 1, 1681826304, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 49, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(47, 'Reza_Takashii', 'Morgan', 'None', '', '125.164.16.195', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 13:47:14', '2023-03-19 13:59:05', 10250, 0, 200, 369237, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 24, 624, 2, 0, 1, '12/03/2007', -1, -1, -1, -1, 60.7666, -1525.22, 5.03463, 2.54502, 0, 0, 100, 0, 97, 100, 96, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(48, 'John_Pardede', 'John', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, '2023-03-19 14:16:25', '2023-03-19 20:21:24', 46, 0, 0, 618709, 1, 1290, 1, 1962000, 14, 1, 1, 0, 0, 2, 34, 50, 3169, 299, 0, 1, '28/03/2000', -1, -1, -1, -1, 1922.51, -1790.34, 13.6828, 261.696, 0, 0, 16, 0, 45, 100, 45, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 1679265079, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681834821, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 79, 100, 74, 79, 77, 82, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 44, 0, 0, 'None'),
(49, 'Arif_Houston', 'Arif', 'None', '', '118.96.220.222', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, '2023-03-19 14:20:51', '2023-03-19 15:42:48', 9660, 0, 200, 534359, 1, 3811, 1, 10000000, 15, 0, 0, 0, 1, 1, 1, 57, 3717, 299, 0, 1, '12/01/2005', -1, -1, -1, -1, 1326.68, -1529.05, 13.6407, 1.59002, 0, 0, 100, 0, 78, 100, 72, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1679261221, 793, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681831499, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(50, 'Ibet_Jonat', 'ibet', 'None', '', '36.85.222.114', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, '2023-03-19 14:29:02', '2023-03-20 00:44:32', 10250, 0, 200, 443890, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 39, 4059, 2, 0, 1, '16/05/2010', -1, -1, -1, -1, 605.266, 663.662, 6.43613, 83.3312, 0, 0, 23, 0, 75, 100, 69, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(51, 'Matthes_Jackson', 'Matthews', 'None', '', '140.213.183.94', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 14:29:35', '2023-03-19 14:31:48', 10250, 0, 200, 796789, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 12, 132, 2, 0, 1, '1/1/2002', -1, -1, -1, -1, 1819.79, -1823.25, 13.4463, 265.638, 0, 0, 100, 0, 100, 100, 99, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(52, 'Nico_Zeyn', 'Nico', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 14:35:27', '2023-03-19 15:03:02', 9515, 0, 200, 820051, 1, 2885, 0, 0, 0, 0, 0, 0, 0, 0, 21, 5, 1265, 2, 0, 1, '7/10/1999', -1, -1, -1, -1, 1925.81, -1359.98, 15.4291, 116.489, 0, 0, 67, 0, 94, 100, 91, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681829817, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(53, 'Lil_Xie', 'Xieee', 'None', '', '182.2.68.249', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 14:37:43', '2023-03-19 16:14:36', 9535, 0, 200, 758857, 1, 8058, 0, 10000000, 20, 1, 0, 0, 1, 0, 25, 26, 1526, 29, 0, 1, '14/04/2003', -1, -1, -1, -1, 1791.11, -1060.57, 24.2609, 286.999, 0, 0, 100, 0, 92, 100, 90, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(54, 'Baby_Vits', 'Baby', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 14:57:48', '2023-03-19 15:13:43', 10250, 0, 200, 324610, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 38, 398, 41, 0, 2, '18/11/2000', -1, -1, -1, -1, 337.132, -1768.6, 5.30259, 46.5405, 0, 0, 93, 0, 99, 100, 97, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99, 100, 98, 100, 98, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(55, 'Fadhil_Ramadhan', 'Padil', 'None', '', '103.3.221.32', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, '2023-03-19 15:01:09', '2023-03-19 18:51:33', -8220, 0, 1070, 470967, 1, 3616, 0, 10000000, 20, 0, 0, 0, 1, 3, 11, 8, 440, 5, 0, 1, '17/08/1945', -1, -1, -1, -1, 1459.36, -1030.47, 23.9562, 274.169, 0, 0, 48, 0, 6, 100, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 1679265081, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681834840, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 'None'),
(56, 'Aditia_Abyaz', 'Adit', 'None', '', '182.0.210.217', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, '2023-03-19 16:27:20', '2023-03-19 19:09:30', 10000, 0, 200, 865893, 1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 40, 29, 9629, 7, 0, 1, '21/06/2002', -1, -1, -1, -1, 1821.05, -1801.66, 13.2387, 355.409, 0, 0, 100, 0, 38, 100, 22, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(57, 'Keiz_Occoner', 'Keiz', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 16:32:11', '2023-03-19 16:34:25', 10250, 0, 200, 508306, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 14, 134, 299, 0, 1, '16/07/1990', -1, -1, -1, -1, 1689.83, -1771.74, 13.4654, 268.72, 0, 0, 100, 0, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(58, 'Avraam_Revekka', 'Abah', 'None', '', '114.5.254.251', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 16:39:00', '2023-03-19 16:55:41', 10200, 0, 200, 317512, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 55, 955, 2, 0, 1, '01/01/2000', -1, -1, -1, -1, 980.125, -673.353, 122.276, 12.9707, 0, 0, 100, 0, 95, 100, 93, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681836273, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(59, 'Ipan_Hendry', 'Ipannn', 'None', '', '140.213.34.138', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 16:59:31', '2023-03-19 17:30:23', 7450, 0, 200, 484881, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 6, 1806, 2, 0, 1, '12/2/2002', -1, -1, -1, -1, 278.538, 918.533, 21.5998, 33.2242, 0, 0, 100, 0, 89, 100, 86, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 1679267722, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681837468, 1, 1681837817, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(63, 'Robert_Santoso', 'Ipannn', 'None', '', '140.213.34.138', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 17:50:28', '2023-03-19 18:13:44', 10100, 0, 200, 570183, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 6, 1326, 7, 0, 1, '12/2/2004', -1, -1, -1, -1, -81.088, -1206.25, 3.38751, 153.426, 0, 0, 100, 0, 92, 100, 90, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 1679270616, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681840376, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 'None'),
(60, 'Pras_Elpatron', 'PrasPatron', 'None', '', '103.151.15.227', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 17:02:04', '2023-03-19 18:07:00', -805, 0, 200, 795567, 1, 8049, 1, 10000000, 20, 1, 0, 0, 1, 0, 31, 24, 1884, 2, 0, 1, '20/08/2000', -1, -1, -1, -1, 1001.85, -940.016, 42.4797, 286.019, 0, 0, 100, 0, 89, 100, 34, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1679269538, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681837766, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 1, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 'None'),
(61, 'Ryuga_San', 'Channn', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 17:18:48', '2023-03-19 19:23:10', 5450, 0, 200, 652087, 1, 3919, 1, 9962000, 0, 0, 1, 0, 0, 0, 42, 47, 2567, 6, 0, 1, '14/03/2003', -1, -1, -1, -1, 1499.2, -1749.04, 15.7453, 16.4911, 0, 0, 100, 0, 85, 100, 81, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681844490, 1, 1681844794, 1, 1681844824, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(62, 'Gabriel_Zelensky', 'bumbles', 'BumbleS', '', '180.252.237.214', 'None', 0, 7, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 17:33:52', '2023-03-20 02:56:22', 250, 0, 200, 158595, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 7, 1207, 2, 0, 1, '25/05/1996', -1, -1, -1, -1, 1525.11, -1650.87, 14.3053, 33.2383, 0, 0, 159, 0, 94, 100, 91, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 80, 78, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(64, 'Monely_Atkinson', 'Monely', 'None', '', '112.215.235.136', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 17:55:10', '2023-03-19 18:16:11', 5380, 0, 200, 393911, 1, 8830, 0, 10000000, 20, 1, 0, 0, 1, 0, 20, 4, 1204, 6, 0, 1, '12/02/2000', -1, -1, -1, -1, -261.587, -2179.22, 29.2946, 218.088, 0, 0, 100, 0, 93, 100, 91, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681841544, 1, 1681841325, 1, 1681840946, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(65, 'Kei_Dominic', 'Dom', 'None', '', '125.160.112.66', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 18:22:15', '2023-03-19 18:47:17', 9795, 0, 200, 655593, 1, 5044, 0, 10000000, 20, 1, 0, 0, 1, 0, 23, 51, 1431, 2, 0, 1, '15/12/2002', -1, -1, -1, -1, 1497.48, -1746, 14.3058, 89.626, 0, 0, 100, 0, 92, 100, 89, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1679272388, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681842645, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(66, 'Rabbty_Rakha', 'Rabbty', 'e', '', '140.213.134.98', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 18:34:33', '2023-03-19 19:16:07', 10100, 0, 200, 555267, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 38, 54, 2334, 100, 0, 1, '10/7/2000', -1, -1, -1, -1, 2037.42, -2216.29, 13.8469, 65.5986, 0, 0, 95, 0, 86, 100, 82, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1235, 0, 0, 0, 0, 0, 1679274301, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681843159, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 'None'),
(67, 'Bob_Austin', 'BobAustin', 'None', '', '120.188.34.190', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 18:36:38', '2023-03-19 18:48:09', 10200, 0, 200, 903702, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 1, 661, 2, 0, 1, '25/12/2000', -1, -1, -1, -1, -78.6149, -1135.27, 1.37812, 237.849, 0, 0, 94, 0, 97, 100, 95, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681843294, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99, 100, 99, 99, 99, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None');
INSERT INTO `players` (`reg_id`, `username`, `ucp`, `adminname`, `twittername`, `ip`, `email`, `characterstory`, `admin`, `helper`, `servermod`, `eventmod`, `factionmod`, `familymod`, `level`, `levelup`, `vip`, `vip_time`, `gold`, `reg_date`, `last_login`, `money`, `redmoney`, `bmoney`, `brek`, `starterpack`, `phone`, `phonestatus`, `phonekuota`, `phonecredit`, `phonebook`, `twitter`, `twitterstatus`, `wt`, `hours`, `minutes`, `seconds`, `paycheck`, `skin`, `facskin`, `gender`, `age`, `indoor`, `inbiz`, `inhouse`, `infamily`, `posx`, `posy`, `posz`, `posa`, `interior`, `world`, `health`, `armour`, `hunger`, `bladder`, `energy`, `sick`, `hospital`, `injured`, `duty`, `dutytime`, `faction`, `factionrank`, `factionlead`, `family`, `familyrank`, `jail`, `jail_time`, `arrest`, `arrest_time`, `suspect`, `suspect_time`, `ask_time`, `warn`, `job`, `job2`, `jobtime`, `sidejobtime`, `sidejob_mowertime`, `sidejob_bustime`, `sidejob_forkliftertime`, `sidejob_sweepertime`, `exitjob`, `taxitime`, `robtime`, `myricous`, `medicine`, `medkit`, `mask`, `helmet`, `snack`, `sprunk`, `gas`, `bandage`, `gps`, `material`, `component`, `food`, `seed`, `potato`, `wheat`, `orange`, `price1`, `price2`, `price3`, `price4`, `marijuana`, `plant`, `plant_time`, `fishtool`, `fish`, `worm`, `idcard`, `idcard_time`, `drivelic`, `drivelic_time`, `weaponlic`, `weaponlic_time`, `hbemode`, `togpm`, `toglog`, `togads`, `togwt`, `Gun1`, `Gun2`, `Gun3`, `Gun4`, `Gun5`, `Gun6`, `Gun7`, `Gun8`, `Gun9`, `Gun10`, `Gun11`, `Gun12`, `Gun13`, `Ammo1`, `Ammo2`, `Ammo3`, `Ammo4`, `Ammo5`, `Ammo6`, `Ammo7`, `Ammo8`, `Ammo9`, `Ammo10`, `Ammo11`, `Ammo12`, `Ammo13`, `kepala`, `perut`, `lengankiri`, `lengankanan`, `kakikiri`, `kakikanan`, `kurir`, `sparepart`, `senter`, `booster`, `boosttime`, `ayamhidup`, `ayampotong`, `ayamfillet`, `lockpick`, `robbiztime`, `robbanktime`, `robatmtime`, `paketborax`, `borax`, `bpjs`, `bpjs_time`, `penebang`, `penebang_time`, `skck`, `skck_time`, `licbiz`, `licbiz_time`, `crack`, `susu`, `nasi`, `burger`, `kebab`, `tikettol`, `divisi`, `aGoreng`, `menikah`) VALUES
(75, 'Ibet_Jonath', 'ibet', 'None', '', '36.85.222.114', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-20 04:28:50', '2023-03-20 04:32:31', 2750, 0, 200, 666827, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 46, 166, 2, 0, 1, '16/05/2010', -1, -1, -1, -1, 1747.54, -1863.03, 13.8756, 257.062, 0, 0, 100, 0, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(68, 'Riyan_Jlc', 'Aril', 'None', '', '180.253.167.37', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 20:12:58', '2023-03-19 20:20:09', 250, 0, 200, 252292, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 360, 2, 0, 1, '15/04/1995', -1, -1, -1, -1, 1688.86, -1858.04, 13.6828, 160.681, 0, 0, 100, 0, 99, 100, 99, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(69, 'Den_Dvinzi', 'Dennn', 'None', '', '223.255.229.65', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, '2023-03-19 21:16:13', '2023-03-20 03:08:02', 2945, 0, 200, 763875, 1, 8716, 1, 10000000, 20, 1, 0, 0, 1, 3, 12, 36, 11556, 2, 0, 1, '15/04/1999', -1, -1, -1, -1, -883.192, -2818.79, 70.3374, 91.047, 0, 0, 95, 0, 90, 100, 69, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 1679302123, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681853189, 1, 1681859507, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 'None'),
(70, 'Shai_Morgan', 'Albet', 'None', '', '103.119.141.46', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 21:17:14', '2023-03-19 21:36:43', 10140, 0, 200, 156866, 1, 6068, 0, 0, 20, 1, 0, 0, 0, 0, 13, 16, 796, 3, 0, 1, '10/01/1999', -1, -1, -1, -1, 1522.69, -1636.89, 13.8469, 302.992, 0, 0, 100, 0, 96, 100, 94, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681853179, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(71, 'Forter_Takiwa', 'Forte', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-19 23:20:06', '2023-03-20 00:06:16', 10145, 0, 200, 867471, 1, 1404, 0, 10000000, 20, 1, 0, 0, 1, 0, 8, 27, 507, 2, 0, 1, '20/07/2000', -1, -1, -1, -1, 1324.77, -885.954, 39.8781, 237.101, 0, 0, 88, 0, 98, 100, 97, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 98, 100, 94, 94, 93, 92, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(72, 'Remon_Clausius', 'Remon', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-20 01:53:01', '2023-03-20 01:54:41', 10250, 0, 200, 539528, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 40, 100, 3, 0, 1, '15/04/1998', -1, -1, -1, -1, 1755.09, -1862.45, 13.8763, 231.992, 0, 0, 100, 0, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(73, 'Ibet_Jonats', 'ibet', 'None', '', '36.85.222.114', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-20 03:12:41', '2023-03-20 04:16:42', 8905, 0, 400, 793213, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 46, 706, 2, 0, 1, '16/05/2010', -1, -1, -1, -1, 2068.62, -1914.26, 13.8469, 266.976, 0, 0, 100, 0, 97, 100, 95, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1681877528, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None'),
(74, 'Fatwa_Ptez', 'Ptez', 'None', '', '255.255.255.255', 'None', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2023-03-20 03:17:26', '2023-03-20 03:19:31', 10250, 0, 200, 447173, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 5, 125, 1, 0, 1, '08/09/2000', -1, -1, -1, -1, 1802.35, -1856.55, 13.4932, 230.684, 0, 0, 100, 0, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None');

-- --------------------------------------------------------

--
-- Table structure for table `playerucp`
--

CREATE TABLE `playerucp` (
  `ID` int(11) NOT NULL,
  `ucp` varchar(22) NOT NULL,
  `verifycode` int(11) NOT NULL,
  `DiscordID` bigint(20) NOT NULL,
  `password` varchar(64) NOT NULL,
  `salt` varchar(16) NOT NULL,
  `extrac` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `playerucp`
--

INSERT INTO `playerucp` (`ID`, `ucp`, `verifycode`, `DiscordID`, `password`, `salt`, `extrac`) VALUES
(1, 'Arch', 2005, 0, 'BEFE027666A8F9F88AED9B695645B6304ACA88AB7B24085749904E7E6C6AA022', 's-q-Fo56JpF0zp>p', 0),
(2, 'Test', 2222, 0, 'BD370C8E7068C9EBF3C35BDEB504CC7D04F2448EBFEA1CB6682DACA8A814BFDB', 'xR@6!]+*-V(TdzOf', 0),
(3, 'Jhono', 2222, 0, '82E6FC85BB95E3479754D75EB2AD15F90B3A90267C83F6F06CB882DDD20D26C7', 'LM&tNQ.}83H7J>fU', 0),
(4, 'Isac', 2222, 0, 'B02180E6BDB74C6B538F8CCCEB4E98E87A2CDBBDC0D7F67D3E3DEF84B0D4636A', '+0UkUMSuBd^Nd3,*', 0),
(5, 'Andre', 862015, 966296159004020788, 'A956ADDF6B42520FCE2D887F31CF869C406F06590E1B568E1DD69B8ACF8DE433', '4=e!6Ke+GwyJunxy', 0),
(6, 'Cell', 382823, 755691723031576697, '', '', 0),
(7, 'ken', 191878, 853867613246849025, '6C7ACE17DE5E572FC0CCA6BF0D28CA0FF85FC5B5EF735E47B68AE040926B8697', '.MwYv\\Jo><xgzvW6', 0),
(8, 'Nuel', 515491, 968247948645388298, '7617A98E77ADA24EE8FD5F72B67CE479A4F5CFF6FE2B49D82746967F846E4516', 'O1<}?3Po>4eIpdE8', 0),
(9, 'Aldi147', 771684, 971049290002755594, 'CFFE0C5BB236F282270D2F409409E089668E82BDEBB53F90AEF8272E1405B06C', ':?t%OB.\\+nJ1e]=s', 0),
(10, 'heleh', 350971, 518740813283328002, '5B6DF30D7C9783C5C238C40EDEB4B676D2D537DB68F28C382C685455D9657ECF', '-!ff6mYVI{=`1aRu', 0),
(11, 'bumbles', 897031, 1023979725523275849, '3CF051A84EBFB029E3ED437CDD243ED21A2365A01A34A47C67BB5F272066A4EF', ';^Bk$StyyFig[LK?', 0),
(12, 'Dhann', 565412, 1017619619663577140, '8A6E2F5E4F86C93A944D74C1A499239480F952D8CA65B1A9D950D3387EB7DB04', 'd(:Z^#vd?pzk@%<i', 0),
(13, 'Metthew', 383699, 1079091677148491916, '73D892D10C8BB9C21F8D9AA4B269D4F46A3B2541E2B48F263B22BE2BCC341DA4', '6dBPM.}xp71,D!Ao', 0),
(14, 'Deriss', 941008, 1086871794360786984, 'CFDDFCC759C7D2300BF41BC29A05A3B691555657B6D972EC1DCB176E64545D58', 'r2IP`<)t%09Q+%]}', 0),
(15, 'RafiPutrawan', 285754, 1059304811260039169, '', '', 0),
(16, 'Kazuto', 672411, 770491672147656754, '', '', 0),
(17, 'Revaldo', 648761, 894559683866677268, '7C2F6E9FB542EFFC513467222F85111149E474794578C2FFCC941345C25BAD56', '35,-n|\'D,Au.ZB]k', 0),
(18, 'Ozann', 664184, 1086251626752385126, '04DF714611993C994DE04DF521375178ADD233AAED5419B358F30C53E9892F62', 'KgBHv!o4z5h1/<qa', 0),
(19, 'Alex', 178879, 1078311380794478693, '9C98465411A10ED463E96DF9D4BA190A03B15838D544A51CEBD14A638AD32DF7', '\'<od)m29k.4tG$,+', 0),
(20, 'Razzel', 766916, 1023393107804434552, '177426D5FB62367B0AF402CCC5EC169C382FFCD069ABB711E67C2D836FFCAAFC', 'YGs{h|{<A&}0nwS7', 0),
(21, 'Firman', 667745, 1013383081354342492, 'E33C0F97584D375359745C06824CD0D32608F6C3F2B379AA9CD1464F4E8D0C15', '5BC5n.\\pJBvm,p;J', 0),
(22, 'Hanz', 251368, 977601365259980830, '5AD4142BE64356FADFB6D07128D8D3E289E100AA94862A86420D5B43036E5890', 'Sm2o#6KG%lBj1ZNV', 0),
(23, 'Xeno', 915297, 1001084104542011513, 'EA7C1D439C25648CC7A45E409BCFFE8B9A125B7700D8866B03AEF17943ED9DCC', '3}wQB~0&Y4ePLVw^', 0),
(24, 'Wangsaf', 533424, 1035839002189762584, '', '', 0),
(25, 'Rakax', 414849, 1086142971738591232, '1916E7080462D803DB9DF876D2CE2E1807A62A8274C86426FBA95E9FF989F1AB', '$T~(~k>ulTM4Vt.N', 0),
(26, 'Nyxx', 856110, 1010895106276065290, '', '', 0),
(27, 'Nixon', 280395, 1073585831530467328, 'D185A488CF38E324BBAE54B8B066F12BD0BCCF9988A248AFBA796D788D5193AF', '=lU0;9}W7e_@cPPk', 0),
(28, 'deden', 797812, 1073166357467766806, '5FDA8814F8377E99E31E220ED4D5E3CEFF6E463AE4AADB2546CF0A8BD7F1156C', '8=s%=/o!<z!H2GP5', 0),
(29, 'Jhon', 987161, 1043537896612843621, '', '', 0),
(30, 'Kucingmeow', 872381, 874106234247192646, '92D2AF621585FCFD299D593C13639F5D770AB14ED5307836BBAFF2BF9890D4F8', '>nQ<Ws/f0S?!Jt)V', 0),
(31, 'Valconic', 782503, 1077302080659783701, 'C987D4F636200815264090BE55A99FE34E6DD2A5239E8774A8C2B72D154E47D8', '^uT^WEUciTWeWk]p', 0),
(32, 'Steven', 803813, 1085937452717457428, 'CAEEF12678E709DF23BC6BC91780C5D107051EB3E6D9C5A4188337BAFDE9B4F8', 'eh(l$%@MBAnh6|Eo', 0),
(33, 'Homage', 526448, 1010617378268254249, '625571F91D3F2C3C6BF331AFBC38A3883BAFE3B14A4DB281EB8064D6BCF14C0E', 'h4<r-}Pd(/sXB>$V', 0),
(34, 'ItsMeGabxAya', 736484, 984311839838064680, 'FC54B9320188F85412335429840D829B4D16B9F4096E2D18B2A58ED6EC94B6FE', 'y[o^#m|-=Hy?%,jZ', 0),
(35, 'EgoHCRI', 455412, 980611548835901491, '11943BFE221AD30D81E79BCC3860A56F36B68E6C4C1F22F08A9178AA8178B62D', '?RO?eX8V1~+q[b86', 0),
(36, 'Mochyi', 964171, 1086576803071656046, '4800BBC6CDD9BFFD953BA55B6C1D5AA9AB029FC394828169EFDFB1B012682937', 'g_,k77@7V1R_poaj', 0),
(37, 'Zeee', 785463, 1066792900773552298, 'D5E56E402D153D87BDB95A5AFD721DEBCA3AB2470331E2834E37A5D1C6DBF238', '%){;a!WUC\'o)\\p.G', 0),
(38, 'Vano', 895937, 1085393973192962078, '946927940FBA9424FE07B56E03B9F7882F4347C17B51224980929E7F029F63CA', 'iV\'y!V41$b4S~hc)', 0),
(39, 'Opeet', 852116, 994084848966836314, '3C5EC37F720C156A467B636D137D2E3CD1034D343511B16D99CB4F3B9D93987D', 'v/yU]>KtR1[O(q6)', 0),
(40, 'Reyhan', 883503, 1056517849138593832, 'A4B3B44C6EA05071C82CBD761674069138A5B15BD6ACAAF57775E4924809A77C', '\'^y-*H$Om1MNe]29', 0),
(41, 'Franklin', 230108, 986318840680050720, '3E8DF732E40C654426310F12D177D6CAAA28FF9BA9F248AFDBBEF9968BE31D2E', '8@UEg2|v\"Ho0ibs^', 0),
(42, 'Rahmat', 358132, 1085592295434363012, '2BEE22C5D841CD5993EA31DB9AC98123809F63C8EB9A6BB7DE969FC90AB68E4A', 'Z{Ahd^,({\"/j{tp5', 0),
(43, 'aluker', 704815, 709224832377552916, '60B6777019CAA7E3B6724E668BDA886892C71D9D70E6289EB7142E578B70B024', '\"BUz18EhI.NATN3z', 0),
(44, 'Rabbty', 888139, 1086207114277568564, '2F0FB597A13751CBB45161A27538DDCD79DB1091AF12DAAFDE8EABEEDB1214EB', '*|AkXL<xWJ#kvC-)', 0),
(45, 'Andrew', 598859, 1085898642730258482, '6820F36DB9F5B4CA25E01F8B58EF01E16672DB99CC90354D931103A7BC84BDFE', '68Q[\\fWqn;`=vLd\\', 0),
(46, 'sheetod', 399909, 1086811626491093092, '', '', 0),
(47, 'Jimmy', 367853, 763253337046777876, '', '', 0),
(48, 'DikZz', 649334, 718436637499064331, 'A08D5867D7C218206D167757858EE390199344CE20F8DCACE2420E6BE3942470', ':;daJ*a:oXOO5j-b', 0),
(49, 'Matheww', 756457, 1072634271547805877, '8898892B140C556D6EFCAD6247C276486587EB50E3621A7619CF8577DB95F398', 'zdJ*=ZXm^bL|aU0%', 0),
(50, 'Morgan', 316014, 1079285277702496377, '8372FDAB4D4C495B52FD60AC9D3FD6D92F7C01495FA1851A3620883267BA4C91', 'xFgqnzdCBhn\"hiyD', 0),
(51, 'John', 754716, 551654839730438175, '6ED1DA0ABE92F3C690C6F0203EA27079A6126BF972AE75DF72F2F9035AF52209', 'IVtynQI=us:T$KB1', 0),
(52, 'Arif', 179274, 970050660068384860, 'C1A8E31A94A3083DD47AB06133A9DFA9A7A8A0D6EA0767A34706F8E0D0DEEA47', '\\r#^UL@m~^8\'t4}O', 0),
(53, 'Rifky', 652195, 1010761832669138944, '', '', 0),
(54, 'Matthews', 656131, 1028924615566823486, 'B9457095A9B2611AD1F7BB9453739BF38DB4109B0F1B9FDCF52D4568EB6CC7E9', 's7qf|764zn4$mfU\\', 0),
(55, 'Ibet', 350204, 1060801286330654740, '6650EC13D80C4F9C6BD7E81961B2E7FA059752AFA8C42601E7B7650B25576F45', 'YgJi*gCKB\'y;>K=&', 0),
(56, 'Nico', 765419, 1018010474245263380, '7576D78021F67091E1A477438C45A21C2B6F7C06FD5A0BFF68396360867CF9B8', ';RO\\18=lpUqi^]q#', 0),
(57, 'Xieee', 953590, 1059482331452293262, 'B9686E7EBDAD3FFE4588CD8B33DAFA3DAD100F289D1E955E3B74711DAA191C46', 'T2(~LCJ8@%F4tm2I', 0),
(58, 'Baby', 558929, 767466349525467186, '9D18839F7BE05834516E1B75E73D3F5F38820FCAD12AFAE590E7A5C880935C64', 'r]%`.dx7mMoWo^}R', 0),
(59, 'Padil', 136205, 751350000784506991, '46357CC531EB02B076288BDE40FB9525DE13D317FB20403ABE722F7D6A529B4D', '^\\<#B+A*Z|d\'Q:VG', 0),
(60, 'Meiza', 607994, 795036042742857758, '', '', 0),
(61, 'Valdii', 966724, 923272481123483739, '', '', 0),
(62, 'Adit', 680621, 1085250859211960391, 'E685736E033EB52BAA4EAA6EB7723277E15F7DBAE22C2AD93520D5C449A76C05', '3I<:L@~h[a5Wq8$D', 0),
(63, 'Keiz', 400534, 1079643395103916152, 'ACDCAD66FB5CAB09CAAA8555CD426ADC0CB7677A1B37F22FD9AD11F20143F65E', 'p\\5TUYABv&?%t%5$', 0),
(64, 'Abah', 228587, 1040906839254106142, 'FB4ECBCDD6EDFA3F22BDE756ADDD013499A0C191CF027143382512E5DF0ED740', 'Zro\"]&CN6g1[`b)v', 0),
(65, 'PrasPatron', 505927, 1001195647963250688, '68331CE39924AF1C7E799F5C819DA852479792D3CA1C615DDBB1DD4B8E802B74', '9Y}dz}WPA<zNc8I7', 0),
(66, 'ipannn', 755749, 1086730873061249124, 'FB054B16B063B095372F25BB8CF7ED5AB14F96C2B078196E52DFDC49FA2A2CC7', '\")hV65pYUN9NhKU=', 0),
(67, 'Channn', 161185, 873005941505798156, 'A6F37927E2CACBF6D687D52323B186BDC9C0730A0B64D1805EF7428793E4E4D2', 'Mkx;KEtQzm*)ZVAc', 0),
(68, 'Monely', 357089, 1076905830634508418, '30D3965A79A181BD1DE02AA336CF58214A2AE844A4241A57B0F0A094A0DDDF83', '#59xg>O\'9Q-4c\'7u', 0),
(69, 'Dom', 363673, 894640259760005141, '641A4B9E83F4B897AF43FF14F9271BAD69BD09E91A338F4D0921951234BD57B9', ';I)Rw>E|lW]lw($/', 0),
(70, 'BobAustin', 316665, 1080090014312038480, '9AFD7A4BE170BE8B8CA0C4607E5A02BBDA15FAF6888E7AB9A29C25AE75EFEDCC', '#_1vt,0yyh8DTCq}', 0),
(71, 'Aril', 584508, 958709405208150096, '58075AB27703C1760BA400D29005DA2C8758DBFC8B4ADAA63D8AECD436E1BC49', '[ET\'`:qQZ#\"5(yj8', 0),
(72, 'Daffa', 852243, 1069148319743496253, '', '', 0),
(73, 'Dennn', 857487, 931254165907316737, 'E43CB92CCB4B7D0BC4DA8B92EE57CBCCD05A06D38D6C5844D507F2088E50D831', 'S\'++kzDqCY.Ewl1k', 0),
(74, 'Albet', 469016, 1078063482878046358, 'FE638087CBA67FCCD40729ADE3C88C35CC57A9038D70BBA5F008E41DF8D7841F', 'H0#rvIOUUb=bha#H', 0),
(75, 'Forte', 980396, 1084068738149646406, '15D97CE167179B5CD4B667083544517582E2B51BE4ACB84AE9597E2D7267FCC8', '!}5D4pvShO6#\"&V&', 0),
(76, 'Calvin', 693221, 1059022869503422464, '', '', 0),
(77, 'Remon', 669424, 1074586422851420181, '0E0A3B2ADE40EB5C447124F78BEB9F9F4BAAEAEDB7F54D457005BD821BB2F42A', 'QD*1*i@GclBFHEX3', 0),
(78, 'Ptez', 765574, 735228364973015171, 'F9438ACCEE337DBEBA17461786AD8FB9AACA1D2B3C65DD1C59A47E7ED05599F9', 'Y]TgI-Ez,/\"}#.-~', 0);

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `ID` int(11) NOT NULL,
  `Reporter` varchar(24) NOT NULL,
  `Reason` varchar(200) NOT NULL,
  `Date` varchar(30) NOT NULL,
  `Accepted` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `id` bigint(20) NOT NULL,
  `owner` int(11) DEFAULT 0,
  `info` varchar(46) DEFAULT '',
  `money` int(11) NOT NULL DEFAULT 0,
  `date` varchar(36) DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`id`, `owner`, `info`, `money`, `date`) VALUES
(0, 1, 'Sidejob(Sweeper)', 100, '2022-05-17 18:19:12'),
(0, 6, 'Sidejob(Sweeper)', 100, '2022-05-17 18:20:33'),
(0, 6, 'Job(Baggage)', 400, '2022-05-17 19:16:22'),
(0, 1, 'Sidejob(Sweeper)', 100, '2022-05-17 18:19:12'),
(0, 6, 'Sidejob(Sweeper)', 100, '2022-05-17 18:20:33'),
(0, 6, 'Job(Baggage)', 400, '2022-05-17 19:16:22'),
(0, 36, 'Sidejob(Bus)', 210, '2023-03-19 10:27:48'),
(0, 36, 'Sidejob(Sweeper)', 120, '2023-03-19 10:33:38'),
(0, 36, 'Sidejob(Bus)', 210, '2023-03-19 10:42:00'),
(0, 33, 'Sidejob(Bus)', 210, '2023-03-20 04:20:17'),
(0, 36, 'Sidejob(Sweeper)', 100, '2023-03-19 10:47:27'),
(0, 61, 'Sidejob(Sweeper)', 120, '2023-03-19 19:18:32'),
(0, 0, 'Sidejob(Bus)', 210, '2023-03-19 13:07:02'),
(0, 48, 'Sidejob(Forklift)', 440, '2023-03-19 18:04:21'),
(0, 66, 'Job(Baggage)', 400, '2023-03-19 19:13:42'),
(0, 48, 'Sidejob(Mower)', 90, '2023-03-19 18:14:26'),
(0, 48, 'Sidejob(Bus)', 210, '2023-03-19 18:24:05'),
(0, 61, 'Sidejob(Sweeper)', 100, '2023-03-19 19:12:47');

-- --------------------------------------------------------

--
-- Table structure for table `server`
--

CREATE TABLE `server` (
  `id` int(11) NOT NULL DEFAULT 0,
  `servermoney` int(11) NOT NULL DEFAULT 0,
  `material` int(11) NOT NULL DEFAULT 500,
  `materialprice` int(11) NOT NULL DEFAULT 10,
  `lumberprice` int(11) NOT NULL DEFAULT 800,
  `component` int(11) NOT NULL DEFAULT 500,
  `componentprice` int(11) NOT NULL DEFAULT 10,
  `metalprice` int(11) NOT NULL DEFAULT 500,
  `gasoil` int(11) NOT NULL DEFAULT 1000,
  `gasoilprice` int(11) NOT NULL DEFAULT 10,
  `coalprice` int(11) NOT NULL DEFAULT 500,
  `product` int(11) NOT NULL DEFAULT 500,
  `productprice` int(11) NOT NULL DEFAULT 20,
  `apotek` int(11) NOT NULL DEFAULT 500,
  `medicineprice` int(11) NOT NULL DEFAULT 300,
  `medkitprice` int(11) NOT NULL DEFAULT 500,
  `food` int(11) NOT NULL DEFAULT 500,
  `foodprice` int(11) NOT NULL DEFAULT 100,
  `seedprice` int(11) NOT NULL DEFAULT 10,
  `potatoprice` int(11) NOT NULL DEFAULT 10,
  `wheatprice` int(11) NOT NULL DEFAULT 10,
  `orangeprice` int(11) NOT NULL DEFAULT 10,
  `marijuana` int(11) NOT NULL DEFAULT 500,
  `marijuanaprice` int(11) NOT NULL DEFAULT 10,
  `fishprice` int(11) NOT NULL DEFAULT 100,
  `gstationprice` int(11) NOT NULL DEFAULT 100,
  `obatmyr` int(11) NOT NULL DEFAULT 0,
  `obatprice` int(11) NOT NULL DEFAULT 0,
  `crateforklift` int(11) NOT NULL DEFAULT 0,
  `cratekurir` int(11) NOT NULL DEFAULT 0,
  `paper` int(11) NOT NULL DEFAULT 0,
  `paperprice` int(11) NOT NULL DEFAULT 0,
  `hgschema` int(11) NOT NULL DEFAULT 0,
  `arschema` int(11) NOT NULL DEFAULT 0,
  `smgschema` int(11) NOT NULL DEFAULT 0,
  `hgprice` int(11) NOT NULL DEFAULT 70,
  `arprice` int(11) NOT NULL DEFAULT 220,
  `smgprice` int(11) NOT NULL DEFAULT 200,
  `crate_fish` int(11) NOT NULL DEFAULT 4000,
  `crate_compo` int(11) NOT NULL DEFAULT 5000,
  `crate_material` int(11) NOT NULL DEFAULT 1000,
  `fish_stock` int(11) NOT NULL DEFAULT 1000,
  `crack` int(11) NOT NULL DEFAULT 200,
  `crackprice` int(11) NOT NULL DEFAULT 100,
  `ayamfill` int(11) NOT NULL DEFAULT 400,
  `ayamfillprice` int(11) NOT NULL DEFAULT 80,
  `pedagang` mediumint(9) NOT NULL DEFAULT 5000
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `server`
--

INSERT INTO `server` (`id`, `servermoney`, `material`, `materialprice`, `lumberprice`, `component`, `componentprice`, `metalprice`, `gasoil`, `gasoilprice`, `coalprice`, `product`, `productprice`, `apotek`, `medicineprice`, `medkitprice`, `food`, `foodprice`, `seedprice`, `potatoprice`, `wheatprice`, `orangeprice`, `marijuana`, `marijuanaprice`, `fishprice`, `gstationprice`, `obatmyr`, `obatprice`, `crateforklift`, `cratekurir`, `paper`, `paperprice`, `hgschema`, `arschema`, `smgschema`, `hgprice`, `arprice`, `smgprice`, `crate_fish`, `crate_compo`, `crate_material`, `fish_stock`, `crack`, `crackprice`, `ayamfill`, `ayamfillprice`, `pedagang`) VALUES
(0, 1443160407, 0, 4, 80, 10, 2, 85, 264290, 3, 75, 29616, 8, 100000, 200, 300, 37, 2, 5, 10, 382, 100, 902, 30, 21, 200, 4995, 35, 99, 30, 200, 0, 0, 10, 5, 220, 70, 200, 1, 9995, 4000, 830, 183, 70, 1000, 134, 5000);

-- --------------------------------------------------------

--
-- Table structure for table `speedcameras`
--

CREATE TABLE `speedcameras` (
  `speedID` int(11) NOT NULL,
  `speedRange` float DEFAULT 0,
  `speedLimit` float DEFAULT 0,
  `speedX` float DEFAULT 0,
  `speedY` float DEFAULT 0,
  `speedZ` float DEFAULT 0,
  `speedAngle` float DEFAULT 0,
  `speeedX` float NOT NULL DEFAULT 0,
  `speeedY` float NOT NULL DEFAULT 0,
  `speeedZ` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `speedcameras`
--

INSERT INTO `speedcameras` (`speedID`, `speedRange`, `speedLimit`, `speedX`, `speedY`, `speedZ`, `speedAngle`, `speeedX`, `speeedY`, `speeedZ`) VALUES
(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1, 10, 90, 1350.01, -1417.63, 12.3468, 355.13, 0, 0, 0),
(2, 15, 100, 1369.77, -955.765, 33.1849, 172.215, 0, 0, 0),
(3, 30, 100, 34.9394, -664.113, 2.6137, 39.2421, 0, 0, 0),
(4, 0, 0, 1548.42, -1671.7, 12.3663, 0.676, 0, 0, 0),
(5, 0, 0, 1540.52, -1671.89, 12.3536, 97.7255, 0, 0, 0),
(6, 0, 0, 1541.89, -1672.1, 14.7547, 152.509, 0, 0, 0),
(7, 0, 0, 1462.77, -1037.26, 23.6562, 174.205, 0, 0, 0),
(8, 0, 0, 1472.67, -1040.68, 23.8281, 176.096, 0, 0, 0),
(9, 0, 0, 806.933, -1367.03, 13.5469, 273.984, 0, 0, 0),
(10, 0, 0, 0, 0, 0, 805.885, -1370.01, 13.5481, 0),
(11, 0, 0, 0, 0, 0, 1816.34, -1849.79, 13.414, 0),
(12, 0, 0, 0, 0, 0, 1765.33, -1859.03, 13.414, 0),
(13, 0, 0, 0, 0, 0, 329.372, -1785.01, 4.8534, 0),
(14, 0, 0, 0, 0, 0, 1746.7, -1846.7, 13.5772, 0);

-- --------------------------------------------------------

--
-- Table structure for table `storage`
--

CREATE TABLE `storage` (
  `ID` int(11) NOT NULL,
  `owner` varchar(50) NOT NULL DEFAULT 'None',
  `price` int(11) NOT NULL DEFAULT 500000,
  `posx` float DEFAULT 0,
  `posy` float DEFAULT 0,
  `posz` float DEFAULT 0,
  `money` int(11) NOT NULL DEFAULT 0,
  `material` int(11) NOT NULL DEFAULT 0,
  `component` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `toys`
--

CREATE TABLE `toys` (
  `Id` int(11) NOT NULL,
  `Owner` varchar(40) NOT NULL DEFAULT '',
  `Slot0_Model` int(11) NOT NULL DEFAULT 0,
  `Slot0_Bone` int(11) NOT NULL DEFAULT 0,
  `Slot0_Status` int(11) NOT NULL DEFAULT 0,
  `Slot0_XPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_YPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_ZPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_XRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_YRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_ZRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_XScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_YScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_ZScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_Model` int(11) NOT NULL DEFAULT 0,
  `Slot1_Bone` int(11) NOT NULL DEFAULT 0,
  `Slot1_Status` int(11) NOT NULL DEFAULT 0,
  `Slot1_XPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_YPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_ZPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_XRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_YRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_ZRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_XScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_YScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_ZScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_Model` int(11) NOT NULL DEFAULT 0,
  `Slot2_Bone` int(11) NOT NULL DEFAULT 0,
  `Slot2_Status` int(11) NOT NULL DEFAULT 0,
  `Slot2_XPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_YPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_ZPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_XRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_YRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_ZRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_XScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_YScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_ZScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_Model` int(11) NOT NULL DEFAULT 0,
  `Slot3_Bone` int(11) NOT NULL DEFAULT 0,
  `Slot3_Status` int(11) NOT NULL DEFAULT 0,
  `Slot3_XPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_YPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_ZPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_XRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_YRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_ZRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_XScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_YScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_ZScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_Model` int(11) NOT NULL DEFAULT 0,
  `Slot4_Bone` int(11) NOT NULL DEFAULT 0,
  `Slot4_Status` int(11) NOT NULL DEFAULT 0,
  `Slot4_XPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_YPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_ZPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_XRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_YRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_ZRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_XScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_YScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_ZScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_Model` int(11) NOT NULL DEFAULT 0,
  `Slot5_Bone` int(11) NOT NULL DEFAULT 0,
  `Slot5_Status` int(11) NOT NULL DEFAULT 0,
  `Slot5_XPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_YPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_ZPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_XRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_YRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_ZRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_XScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_YScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_ZScale` float(20,3) NOT NULL DEFAULT 0.000
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `toys`
--

INSERT INTO `toys` (`Id`, `Owner`, `Slot0_Model`, `Slot0_Bone`, `Slot0_Status`, `Slot0_XPos`, `Slot0_YPos`, `Slot0_ZPos`, `Slot0_XRot`, `Slot0_YRot`, `Slot0_ZRot`, `Slot0_XScale`, `Slot0_YScale`, `Slot0_ZScale`, `Slot1_Model`, `Slot1_Bone`, `Slot1_Status`, `Slot1_XPos`, `Slot1_YPos`, `Slot1_ZPos`, `Slot1_XRot`, `Slot1_YRot`, `Slot1_ZRot`, `Slot1_XScale`, `Slot1_YScale`, `Slot1_ZScale`, `Slot2_Model`, `Slot2_Bone`, `Slot2_Status`, `Slot2_XPos`, `Slot2_YPos`, `Slot2_ZPos`, `Slot2_XRot`, `Slot2_YRot`, `Slot2_ZRot`, `Slot2_XScale`, `Slot2_YScale`, `Slot2_ZScale`, `Slot3_Model`, `Slot3_Bone`, `Slot3_Status`, `Slot3_XPos`, `Slot3_YPos`, `Slot3_ZPos`, `Slot3_XRot`, `Slot3_YRot`, `Slot3_ZRot`, `Slot3_XScale`, `Slot3_YScale`, `Slot3_ZScale`, `Slot4_Model`, `Slot4_Bone`, `Slot4_Status`, `Slot4_XPos`, `Slot4_YPos`, `Slot4_ZPos`, `Slot4_XRot`, `Slot4_YRot`, `Slot4_ZRot`, `Slot4_XScale`, `Slot4_YScale`, `Slot4_ZScale`, `Slot5_Model`, `Slot5_Bone`, `Slot5_Status`, `Slot5_XPos`, `Slot5_YPos`, `Slot5_ZPos`, `Slot5_XRot`, `Slot5_YRot`, `Slot5_ZRot`, `Slot5_XScale`, `Slot5_YScale`, `Slot5_ZScale`) VALUES
(0, 'Lovic_Hug', 11745, 2, 1, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 1.000, 1.000, 1.000, 0, 1, 1, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 1.000, 1.000, 1.000, 0, 1, 1, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 1.000, 1.000, 1.000, 0, 1, 1, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 1.000, 1.000, 1.000, 0, 0, 0, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0, 0, 0, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000),
(0, 'Lil_Dominic', 11745, 1, 1, 0.017, -0.119, 0.000, 0.002, 32.000, 272.000, 0.600, 2.300, 1.000, 0, 1, 1, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 1.000, 1.000, 1.000, 0, 1, 1, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 1.000, 1.000, 1.000, 19029, 2, 1, 0.079, 0.050, 0.000, -100.000, 100.000, 190.000, 1.000, 1.000, 1.000, 0, 0, 0, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0, 0, 0, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000),
(0, 'Lil_Xie', 0, 1, 1, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 1.000, 1.000, 1.000, 0, 1, 1, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 1.000, 1.000, 1.000, 0, 1, 1, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 1.000, 1.000, 1.000, 0, 1, 1, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 1.000, 1.000, 1.000, 0, 0, 0, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0, 0, 0, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000);

-- --------------------------------------------------------

--
-- Table structure for table `trees`
--

CREATE TABLE `trees` (
  `id` int(11) NOT NULL,
  `posx` float DEFAULT NULL,
  `posy` float DEFAULT NULL,
  `posz` float DEFAULT NULL,
  `posrx` float DEFAULT NULL,
  `posry` float DEFAULT NULL,
  `posrz` float DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `trees`
--

INSERT INTO `trees` (`id`, `posx`, `posy`, `posz`, `posrx`, `posry`, `posrz`) VALUES
(0, -523.63, -2247.73, 34.5218, 0, 0, 0),
(1, -623.954, -2261.36, 23.9413, 0, 0, 0),
(2, -628.714, -2394, 29.5843, 0, 0, 0),
(3, -735.625, -2254.4, 27.5423, 0, 0, 0),
(4, -657.756, -2140.98, 24.2563, 0, 0, 0),
(5, -654.44, -2074.7, 25.9842, 0, 0, 0),
(6, -546.637, -1999.71, 48.0892, 0, 0, 0),
(7, -731.541, -2189.38, 34.526, 0, 0, 0),
(8, -732.679, -2200.2, 34.5699, 0, 0, 0),
(9, -739.308, -2193.72, 34.6548, 0, 0, 0),
(10, -865.874, -2199.14, 29.0169, 0, 0, 0),
(11, -814.336, -2247.82, 37.77, 0, 0, 0),
(12, -878.67, -2367.51, 68.2969, 0, 0, 0),
(13, -861.714, -2381.68, 69.0388, 0, 0, 0),
(14, -972.936, -2322.47, 62.7628, 0, 0, 0),
(15, -1043.86, -2303.47, 55.4699, 0, 0, 0),
(16, -979.795, -2391.9, 70.2428, 0, 0, 0),
(17, -928.635, -2531.78, 114.824, 0, 0, 0),
(18, -928.943, -2555.48, 114.897, 0, 0, 0),
(19, -889.914, -2502.48, 110.088, 0, 0, 0),
(20, -874.672, -2612.06, 95.074, 0, 0, 0),
(21, -622.4, -2263.39, 23.9615, 0, 0, 0),
(22, -552.445, -2272.94, 28.3696, 0, 0, 0),
(23, -1065.08, -2548.24, 68.1407, 0, 0, 0),
(24, -744.504, -2441.61, 65.1923, 0, 0, 0),
(25, -818.597, -2657.71, 91.0869, 0, 0, 0),
(26, -734.419, -2690.28, 86.7166, 0, 0, 0),
(27, -686.676, -2630.36, 82.9661, 0, 0, 0),
(28, -707.708, -2695.28, 91.3966, 0, 0, 0),
(29, -757.89, -2538.72, 90.0414, 0, 0, 0),
(30, -748.443, -2509.77, 81.1096, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `id` int(10) UNSIGNED NOT NULL,
  `owner` int(11) NOT NULL,
  `model` int(11) NOT NULL DEFAULT 0,
  `color1` int(11) NOT NULL DEFAULT 0,
  `color2` int(11) NOT NULL DEFAULT 0,
  `paintjob` int(11) NOT NULL DEFAULT -1,
  `neon` int(11) NOT NULL DEFAULT 0,
  `locked` int(11) NOT NULL DEFAULT 0,
  `insu` int(11) NOT NULL DEFAULT 1,
  `claim` int(11) NOT NULL DEFAULT 0,
  `claim_time` bigint(20) NOT NULL DEFAULT 0,
  `plate` varchar(50) NOT NULL DEFAULT 'None',
  `plate_time` bigint(20) NOT NULL DEFAULT 0,
  `ticket` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `price` int(11) NOT NULL DEFAULT 200000,
  `health` float NOT NULL DEFAULT 1000,
  `fuel` int(11) NOT NULL DEFAULT 1000,
  `x` float NOT NULL DEFAULT 0,
  `y` float NOT NULL DEFAULT 0,
  `z` float NOT NULL DEFAULT 0,
  `a` float NOT NULL DEFAULT 0,
  `interior` int(11) NOT NULL DEFAULT 0,
  `vw` int(11) NOT NULL DEFAULT 0,
  `damage0` int(11) NOT NULL DEFAULT 0,
  `damage1` int(11) NOT NULL DEFAULT 0,
  `damage2` int(11) NOT NULL DEFAULT 0,
  `damage3` int(11) NOT NULL DEFAULT 0,
  `mod0` int(11) NOT NULL DEFAULT 0,
  `mod1` int(11) NOT NULL DEFAULT 0,
  `mod2` int(11) NOT NULL DEFAULT 0,
  `mod3` int(11) NOT NULL DEFAULT 0,
  `mod4` int(11) NOT NULL DEFAULT 0,
  `mod5` int(11) NOT NULL DEFAULT 0,
  `mod6` int(11) NOT NULL DEFAULT 0,
  `mod7` int(11) NOT NULL DEFAULT 0,
  `mod8` int(11) NOT NULL DEFAULT 0,
  `mod9` int(11) NOT NULL DEFAULT 0,
  `mod10` int(11) NOT NULL DEFAULT 0,
  `mod11` int(11) NOT NULL DEFAULT 0,
  `mod12` int(11) NOT NULL DEFAULT 0,
  `mod13` int(11) NOT NULL DEFAULT 0,
  `mod14` int(11) NOT NULL DEFAULT 0,
  `mod15` int(11) NOT NULL DEFAULT 0,
  `mod16` int(11) NOT NULL DEFAULT 0,
  `lumber` int(11) NOT NULL DEFAULT -1,
  `metal` int(11) NOT NULL DEFAULT 0,
  `coal` int(11) NOT NULL DEFAULT 0,
  `product` int(11) NOT NULL DEFAULT 0,
  `gasoil` int(11) NOT NULL DEFAULT 0,
  `box` int(11) NOT NULL DEFAULT 0,
  `rental` bigint(20) NOT NULL DEFAULT 0,
  `park` int(11) NOT NULL DEFAULT -1,
  `broken` tinyint(1) NOT NULL DEFAULT 0,
  `trunk` int(11) NOT NULL DEFAULT 1,
  `money` int(11) NOT NULL DEFAULT 0,
  `redmoney` int(11) NOT NULL DEFAULT 0,
  `snack` int(11) NOT NULL DEFAULT 0,
  `sprunk` int(11) NOT NULL DEFAULT 0,
  `medicine` int(11) NOT NULL DEFAULT 0,
  `medkit` int(11) NOT NULL DEFAULT 0,
  `bandage` int(11) NOT NULL DEFAULT 0,
  `seed` int(11) NOT NULL DEFAULT 0,
  `material` int(11) NOT NULL DEFAULT 0,
  `component` int(11) NOT NULL DEFAULT 0,
  `marijuana` int(11) NOT NULL DEFAULT 0,
  `weapon1` int(11) DEFAULT 0,
  `ammo1` int(11) DEFAULT 0,
  `weapon2` int(11) DEFAULT 0,
  `ammo2` int(11) DEFAULT 0,
  `weapon3` int(11) DEFAULT 0,
  `ammo3` int(11) DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`id`, `owner`, `model`, `color1`, `color2`, `paintjob`, `neon`, `locked`, `insu`, `claim`, `claim_time`, `plate`, `plate_time`, `ticket`, `price`, `health`, `fuel`, `x`, `y`, `z`, `a`, `interior`, `vw`, `damage0`, `damage1`, `damage2`, `damage3`, `mod0`, `mod1`, `mod2`, `mod3`, `mod4`, `mod5`, `mod6`, `mod7`, `mod8`, `mod9`, `mod10`, `mod11`, `mod12`, `mod13`, `mod14`, `mod15`, `mod16`, `lumber`, `metal`, `coal`, `product`, `gasoil`, `box`, `rental`, `park`, `broken`, `trunk`, `money`, `redmoney`, `snack`, `sprunk`, `medicine`, `medkit`, `bandage`, `seed`, `material`, `component`, `marijuana`, `weapon1`, `ammo1`, `weapon2`, `ammo2`, `weapon3`, `ammo3`) VALUES
(1, 3, 560, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 14000, 2000, 1000, 1819.64, -1860.7, 14.4141, 199.641, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 5, 468, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 3500, 2000, 970, 1778.58, -1855.89, 13.3818, 272.4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(4, 7, 468, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 3500, 2000, 1000, 1822, -1846.26, 13.2616, 310.663, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(5, 8, 468, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 3500, 1976.4, 805, 1478.37, -1739.78, 13.7151, 229.424, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(6, 9, 468, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 3500, 2000, 820, 1741.69, -1859.52, 13.2459, 191.451, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(7, 10, 481, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50, 2000, 1000, 1740.36, -1856.33, 13.0232, 77.8799, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1663951479, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(8, 11, 468, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 3500, 1863.28, 370, 1543.75, -1675.76, 13.4232, 299.351, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(9, 10, 468, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 3500, 1899.78, 550, 1545.52, -1674.64, 13.4287, 220.795, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(10, 12, 424, 1, 1, -1, 0, 0, 1, 0, 0, 'None', 0, 0, 200000, 993.438, 1000, 1484.48, -1032.69, 24.2478, 358.258, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(11, 12, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1342.28, 895, 2114.6, -1775.97, 14.2717, 209.695, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(12, 14, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 988.245, 160, 1139.24, -1288.07, 13.4319, 276.069, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(13, 17, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1857.34, 925, 1824.71, -1840.28, 13.4933, 333.417, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(14, 16, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1684.05, 640, 1463.72, -1034, 23.5352, 264.209, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15, 18, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1091.85, 0, 918.648, -1293.56, 13.6551, 261.164, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(16, 20, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1468.08, 0, 1320.17, -918.837, 37.7, 3.03831, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(17, 21, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1843.92, 865, 1248.55, -2033.98, 61.4643, 275.161, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(18, 16, 467, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, -1, 2000, 1000, 1309.36, -870.703, 39.7344, 359.99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(19, 16, 481, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, -1, 2000, 1000, 1309.36, -870.703, 39.7344, 359.99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(20, 17, 481, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50, 1944.02, 1000, 1821.39, -1609.16, 12.9844, 109.609, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679295063, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(21, 24, 424, 1, 1, -1, 0, 1, 3, 0, 0, 'NoHave', 0, 0, 50000, 1410.23, 835, 1535.48, -1672.74, 13.2637, 1.15331, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(23, 15, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1978.6, 685, 2236.84, -1661.06, 16.6698, 306.153, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(24, 25, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1439.02, 775, 1885.67, -1833.31, 4.59673, 236.431, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(58, 26, 426, 0, 0, -1, 0, 0, 3, 0, 0, 'GI-1471', 1680530666, 0, -1, 1936.27, 985, 1320.11, -862.351, 40.2202, 94.9865, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(26, 27, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 2000, 1000, 1750.24, -1862.6, 13.7761, 230.001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(27, 28, 424, 1, 1, -1, 0, 1, 3, 0, 0, 'NoHave', 0, 0, 50000, 1949, 910, 1804.95, -1890.14, 13.303, 94.0661, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(28, 29, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 2000, 955, 1527.97, -1706.38, 13.2627, 182.724, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(29, 30, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1924.58, 955, 1682.74, -1859.92, 13.2771, 188.715, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(30, 31, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 2000, 580, 1792.34, -1902.26, 13.2743, 110.137, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(31, 31, 481, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50, 1934.07, 1000, 1183.44, -1327.74, 13.2885, 94.8623, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679303453, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(32, 19, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 350, 505, 1188.53, -1408.59, 13.1965, 99.9588, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(33, 32, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 769.411, 415, 1833.93, -1554.03, 13.2796, 345.362, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(34, 33, 481, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50, 1911.27, 1000, 2372.95, -1897.66, 13.3896, 127.255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679305000, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(35, 15, 478, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, -1, 1948.41, 925, 1327.4, -868.008, 39.8863, 91.8472, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679306227, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(36, 15, 455, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, -1, 1957.22, 790, 324.516, 878.805, 21.2446, 86.2475, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679306391, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(37, 34, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1955.54, 925, 1715.73, -1591.68, 13.2404, 161.476, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(38, 26, 455, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, -1, 760.23, 850, 341.581, 1029.5, 30.0725, 303.253, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679306513, -1, 127, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(39, 35, 424, 1, 1, -1, 0, 1, 3, 0, 0, 'NoHave', 0, 0, 50000, 1748.26, 910, 1829.65, -1847.05, 13.4558, 308.78, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(40, 36, 424, 1, 1, -1, 0, 1, 3, 0, 0, 'NoHave', 0, 0, 50000, 1709.14, 790, 1496.54, -1024.32, 23.6787, 355.908, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(41, 33, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 620, 0, 1668.42, -1478.51, 13.8604, 326.51, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(42, 33, 481, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50, 2000, 1000, 1705.25, -1559.23, 13.8403, 6.24741, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679307744, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(68, 26, 498, 0, 0, -1, 0, 1, 3, 0, 0, 'NoHave', 0, 0, -1, 1761.44, 490, 1471.81, -1743.1, 13.7044, 90.8796, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 150, 0, 0, 1679323813, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(44, 37, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 2000, 1000, 1750.4, -1862.34, 13.5606, 251.226, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(45, 37, 481, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50, 2000, 1000, 1628.94, -1734.25, 12.9946, 203.682, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679309481, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(46, 38, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 350, 1000, 1750.37, -1862.39, 13.5226, 260.213, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(47, 40, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'GI-7058', 1680520095, 0, 50000, 1660, 100, 1903.02, -1792.13, 13.4359, 167.251, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(48, 40, 481, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50, 1926.35, 1000, 923.978, -1297.95, 13.8997, 330.347, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679310327, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(49, 39, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 2000, 700, 1754.46, -1849.12, 13.4469, 14.7203, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(50, 31, 420, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, -1, 1431.1, 730, 65.4616, -1526.8, 4.77733, 94.1829, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679310512, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(51, 19, 481, 0, 0, -1, 0, 0, 1, 0, 0, 'None', 0, 0, 50, 966.428, 1000, 1830.84, -1652.25, 14.666, 241.161, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679314907, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(52, 42, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 2000, 1000, 1312.24, -1702.14, 13.9672, 0.001978, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(53, 43, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1710.4, 985, 1320.7, -863.517, 39.5569, 91.2155, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(54, 43, 455, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, -1, 1891.67, 745, 321.791, 941.737, 21.325, 89.3498, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679318906, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(55, 44, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1054.28, 805, 1489.6, -1733.55, 13.2679, 91.5319, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(59, 45, 424, 1, 1, -1, 0, 1, 3, 0, 0, 'NoHave', 0, 0, 50000, 1360.83, 595, 2669.46, -1725.67, 10.189, 156.894, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(60, 46, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1447, 0, 1274.67, -1331.16, 13.2478, 209.061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(61, 47, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1760.98, 805, 60.7666, -1525.22, 4.83463, 335.661, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(62, 48, 424, 1, 1, -1, 0, 0, 2, 1, 0, 'NoHave', 0, 0, 50000, 1727.58, 910, 1831.34, -1845.28, 13.7993, 22.0706, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(63, 49, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1408.74, 310, 1320.99, -864.526, 39.5583, 53.4043, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(64, 51, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1946.4, 985, 1819.79, -1823.25, 13.2463, 357.829, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(65, 50, 424, 1, 1, -1, 0, 1, 3, 0, 0, 'NoHave', 0, 0, 50000, 350, 355, 605.266, 663.662, 4.87865, 336.146, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(66, 52, 424, 1, 1, -1, 0, 1, 3, 0, 0, 'NoHave', 0, 0, 50000, 1980.41, 955, 1690.74, -1532.62, 13.4276, 354.717, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(67, 53, 424, 1, 1, -1, 0, 1, 3, 0, 0, 'NoHave', 0, 0, 50000, 1963, 910, 1788.93, -1060.94, 23.8423, 177.153, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(69, 55, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 350, 700, 57.5315, -1532.93, 5.12879, 169.819, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(70, 54, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1982.52, 970, 337.132, -1768.6, 5.10259, 352.193, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(71, 49, 420, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, -1, 1521.37, 460, 1326.68, -1529.05, 13.4407, 159.62, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679325435, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(72, 42, 419, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 3500, 1483.44, 0, 1389.85, -1873.11, 13.2806, 224.29, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(73, 56, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1986.68, 0, 1739.48, -1855.05, 13.2733, 80.1642, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(74, 56, 481, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50, 1996, 1000, 1485.97, -1726.99, 13.1804, 83.8922, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679329842, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(75, 57, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1921.48, 985, 1689.83, -1771.74, 13.2654, 0.637703, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(77, 14, 420, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, -1, 698.398, 40, 935.253, -1238.94, 16.409, 356.913, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679330069, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(78, 56, 462, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 200, 2000, 0, 1828.3, -1842.71, 13.2787, 296.307, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679330363, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(79, 58, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1578.48, 685, 976.648, -668.741, 121.025, 136.221, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(80, 48, 422, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, -1, 1568.48, 715, 1922.67, -1792.01, 13.4645, 261.727, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679331592, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(81, 59, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 2000, 1000, 1749.62, -1862.24, 13.5094, 249.554, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(82, 59, 481, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50, 1978.64, 1000, 278.33, 920.589, 21.4355, 13.5097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679331678, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(83, 60, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1580.93, 1000, 1002.87, -941.471, 41.968, 286.019, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(84, 48, 420, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, -1, 1820, 1000, 1318.86, -862.943, 39.6566, 56.6138, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(85, 63, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 300, 715, -83.607, -1215.45, 2.98144, 253.594, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(86, 64, 424, 1, 1, -1, 0, 1, 3, 0, 0, 'NoHave', 0, 0, 50000, 1988.9, 925, -289.281, -2163.2, 28.5152, 289.126, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(87, 39, 483, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, -1, 1666.44, 895, 1829.99, -1685.67, 13.6322, 317.201, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(88, 65, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1825.29, 505, 1829.48, -1779.66, 13.4468, 248.75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(89, 61, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1825.99, 550, 1296.35, -1877.69, 14.1263, 179.249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(90, 66, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1568.99, 205, 1824.48, -1807.55, 13.278, 189.547, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(91, 67, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 2000, 1000, 1749.3, -1862.14, 13.4584, 255.921, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(92, 70, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1972.56, 805, 2063.17, -1911.13, 13.5273, 50.1281, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(93, 69, 424, 1, 1, -1, 0, 1, 3, 0, 0, 'NoHave', 0, 0, 50000, 1750, 0, -1900.83, -903.626, 45.0051, 173.856, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(94, 71, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 1922.73, 895, 1308.7, -862.137, 39.4583, 131.226, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(95, 72, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 2000, 1000, 1749.72, -1862.79, 13.6759, 274.192, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(96, 69, 481, 0, 0, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50, 2000, 1000, -883.192, -2818.79, 70.1374, 319.706, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1679366231, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(97, 73, 424, 1, 1, -1, 0, 1, 3, 0, 0, 'NoHave', 0, 0, 50000, 1677.45, 940, 2062.14, -1909.57, 13.4268, 48.303, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(98, 74, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 2000, 985, 1802.35, -1856.55, 13.2932, 265.728, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(99, 73, 400, 0, 0, -1, 0, 0, 1, 0, 0, 'None', 0, 0, 5500, 1000, 1000, 1309.36, -870.703, 39.7344, 359.99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(100, 75, 424, 1, 1, -1, 0, 0, 3, 0, 0, 'NoHave', 0, 0, 50000, 2000, 970, 1749.3, -1861.95, 13.5568, 84.5983, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `vending`
--

CREATE TABLE `vending` (
  `ID` int(11) NOT NULL,
  `owner` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '-',
  `ownerid` int(11) NOT NULL,
  `name` varchar(60) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'Vending Machine',
  `price` int(11) NOT NULL DEFAULT 1,
  `locked` int(11) NOT NULL DEFAULT 0,
  `money` int(11) NOT NULL DEFAULT 0,
  `stock` int(11) NOT NULL DEFAULT 50,
  `posx` float NOT NULL,
  `posy` float NOT NULL DEFAULT 0,
  `posz` float NOT NULL DEFAULT 0,
  `posa` float NOT NULL DEFAULT 0,
  `posrx` float NOT NULL DEFAULT 0,
  `posry` float NOT NULL DEFAULT 0,
  `posrz` float NOT NULL DEFAULT 0,
  `restock` tinyint(4) NOT NULL DEFAULT 0,
  `vprice0` int(11) NOT NULL DEFAULT 0,
  `vprice1` int(11) NOT NULL DEFAULT 0,
  `vprice2` int(11) NOT NULL DEFAULT 0,
  `vprice3` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vouchers`
--

CREATE TABLE `vouchers` (
  `id` int(11) NOT NULL,
  `code` int(11) NOT NULL DEFAULT 0,
  `vip` int(11) NOT NULL DEFAULT 0,
  `vip_time` int(11) NOT NULL DEFAULT 0,
  `money` int(11) NOT NULL DEFAULT 0,
  `gold` int(11) NOT NULL DEFAULT 0,
  `admin` varchar(16) NOT NULL DEFAULT 'None',
  `donature` varchar(16) NOT NULL DEFAULT 'None',
  `claim` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vstorage`
--

CREATE TABLE `vstorage` (
  `ID` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `money` int(11) NOT NULL DEFAULT 0,
  `redmoney` int(11) NOT NULL DEFAULT 0,
  `snack` int(11) NOT NULL DEFAULT 0,
  `sprunk` int(11) NOT NULL DEFAULT 0,
  `medicine` int(11) NOT NULL DEFAULT 0,
  `medkit` int(11) NOT NULL DEFAULT 0,
  `bandage` int(11) NOT NULL DEFAULT 0,
  `seed` int(11) NOT NULL DEFAULT 0,
  `material` int(11) NOT NULL DEFAULT 0,
  `marijuana` int(11) NOT NULL DEFAULT 0,
  `component` int(11) NOT NULL DEFAULT 0,
  `weapon1` int(11) DEFAULT 0,
  `ammo1` int(11) DEFAULT 0,
  `weapon2` int(11) DEFAULT 0,
  `ammo2` int(11) DEFAULT 0,
  `weapon3` int(11) DEFAULT 0,
  `ammo3` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `weaponsettings`
--

CREATE TABLE `weaponsettings` (
  `Owner` int(11) NOT NULL,
  `WeaponID` tinyint(4) NOT NULL,
  `PosX` float DEFAULT -0.116,
  `PosY` float DEFAULT 0.189,
  `PosZ` float DEFAULT 0.088,
  `RotX` float DEFAULT 0,
  `RotY` float DEFAULT 44.5,
  `RotZ` float DEFAULT 0,
  `Bone` tinyint(4) NOT NULL DEFAULT 1,
  `Hidden` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `weaponsettings`
--

INSERT INTO `weaponsettings` (`Owner`, `WeaponID`, `PosX`, `PosY`, `PosZ`, `RotX`, `RotY`, `RotZ`, `Bone`, `Hidden`) VALUES
(4, 31, -0.116, 0.189, 0.088, 0, 44.5, 0, 15, 0);

-- --------------------------------------------------------

--
-- Table structure for table `workshop`
--

CREATE TABLE `workshop` (
  `id` int(11) NOT NULL,
  `owner` varchar(25) NOT NULL DEFAULT '-',
  `ownerid` int(11) NOT NULL,
  `posx` float NOT NULL DEFAULT 0,
  `posy` float NOT NULL DEFAULT 0,
  `posz` float NOT NULL DEFAULT 0,
  `component` int(11) NOT NULL DEFAULT 0,
  `material` int(11) NOT NULL DEFAULT 0,
  `money` int(11) NOT NULL DEFAULT 0,
  `name` varchar(26) NOT NULL DEFAULT '-',
  `status` int(11) NOT NULL DEFAULT 0,
  `price` int(11) NOT NULL DEFAULT 0,
  `employe0` varchar(25) NOT NULL DEFAULT '-',
  `employe1` varchar(25) NOT NULL DEFAULT '-',
  `employe2` varchar(25) NOT NULL DEFAULT '-'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `workshop`
--

INSERT INTO `workshop` (`id`, `owner`, `ownerid`, `posx`, `posy`, `posz`, `component`, `material`, `money`, `name`, `status`, `price`, `employe0`, `employe1`, `employe2`) VALUES
(0, 'Clairo_Stevano', 2, -907.751, 1527.05, 26.4516, 0, 0, 0, 'Clairo Company', 1, 1000000000, '-', '-', '-'),
(1, '-', 0, 2434.78, 111.134, 26.4776, 0, 0, 0, '-', 0, 1000000000, '-', '-', '-');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actor`
--
ALTER TABLE `actor`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `atms`
--
ALTER TABLE `atms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banneds`
--
ALTER TABLE `banneds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bisnis`
--
ALTER TABLE `bisnis`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`contactID`);

--
-- Indexes for table `doors`
--
ALTER TABLE `doors`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `gates`
--
ALTER TABLE `gates`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `gstations`
--
ALTER TABLE `gstations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `houses`
--
ALTER TABLE `houses`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `lockers`
--
ALTER TABLE `lockers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loglogin`
--
ALTER TABLE `loglogin`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `ores`
--
ALTER TABLE `ores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plants`
--
ALTER TABLE `plants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`reg_id`);

--
-- Indexes for table `playerucp`
--
ALTER TABLE `playerucp`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `server`
--
ALTER TABLE `server`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `speedcameras`
--
ALTER TABLE `speedcameras`
  ADD PRIMARY KEY (`speedID`);

--
-- Indexes for table `storage`
--
ALTER TABLE `storage`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `trees`
--
ALTER TABLE `trees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vending`
--
ALTER TABLE `vending`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `vouchers`
--
ALTER TABLE `vouchers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vstorage`
--
ALTER TABLE `vstorage`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `weaponsettings`
--
ALTER TABLE `weaponsettings`
  ADD PRIMARY KEY (`Owner`,`WeaponID`),
  ADD UNIQUE KEY `Owner` (`Owner`,`WeaponID`);

--
-- Indexes for table `workshop`
--
ALTER TABLE `workshop`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banneds`
--
ALTER TABLE `banneds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `contactID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `loglogin`
--
ALTER TABLE `loglogin`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=616;

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `reg_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `playerucp`
--
ALTER TABLE `playerucp`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `vstorage`
--
ALTER TABLE `vstorage`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
