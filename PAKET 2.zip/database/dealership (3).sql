-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Mar 2023 pada 16.32
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `isrp`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `dealership`
--

CREATE TABLE `dealership` (
  `ID` int(11) NOT NULL,
  `owner` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '-',
  `ownerid` int(11) NOT NULL,
  `name` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'Dealership',
  `price` int(11) NOT NULL DEFAULT 1,
  `type` int(11) NOT NULL DEFAULT 1,
  `locked` int(11) NOT NULL DEFAULT 1,
  `money` int(11) NOT NULL DEFAULT 0,
  `stock` int(11) NOT NULL DEFAULT 100,
  `posx` float NOT NULL DEFAULT 0,
  `posy` float NOT NULL DEFAULT 0,
  `posz` float NOT NULL DEFAULT 0,
  `posa` float NOT NULL DEFAULT 0,
  `pointx` float DEFAULT 0,
  `pointy` float DEFAULT 0,
  `pointz` float DEFAULT 0,
  `restock` tinyint(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `dealership`
--

INSERT INTO `dealership` (`ID`, `owner`, `ownerid`, `name`, `price`, `type`, `locked`, `money`, `stock`, `posx`, `posy`, `posz`, `posa`, `pointx`, `pointy`, `pointz`, `restock`) VALUES
(0, 'Kiyux_Saja', -1, 'Verdant Bluffs', 50000, 1, 1, 0, 50, 1610.88, -1893.75, 13.5469, 74.3668, 1619.28, -1894.42, 13.5492, 0),
(1, '-', 0, 'Mulholland', 60000, 2, 1, 0, 0, 1324.69, -885.625, 39.5781, 267.991, 1308, -870.343, 39.5781, 0),
(2, '-', 0, 'Jefferson', 60000, 3, 1, 0, 0, 2139.6, -1192.07, 23.9922, 101.072, 2160.87, -1192.54, 23.8204, 0),
(3, '-', 0, 'Jefferson', 60000, 4, 1, 0, 0, 2139.42, -1176.57, 23.9922, 78.9195, 2161.44, -1177.81, 23.8168, 0),
(4, '-', 0, 'Rodeo', 70000, 5, 1, 0, 0, 557.453, -1293.28, 17.2482, 178.779, 545.887, -1287.91, 17.2482, 0);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `dealership`
--
ALTER TABLE `dealership`
  ADD PRIMARY KEY (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
